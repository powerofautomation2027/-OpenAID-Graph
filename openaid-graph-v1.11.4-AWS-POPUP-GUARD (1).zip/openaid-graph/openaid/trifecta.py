"""Lethal Trifecta analyzer — automated, fleet-wide prompt-injection exposure.

Simon Willison's "lethal trifecta" (2025) says an agent is structurally
exploitable by indirect prompt injection when it simultaneously has:

    A. PRIVATE DATA      — it can read data an attacker wants
    B. UNTRUSTED CONTENT — it ingests content an attacker can author
    C. EXTERNAL COMMS    — it can send data somewhere an attacker receives

CSA's 2026 research note recommends every agent get an explicit "trifecta
audit" before production. Doing that by hand, per agent, across Copilot
Studio + Foundry + MCP, is exactly what nobody automates — so OpenAID does it
from the descriptors it already discovers, and then answers the question the
audit leaves open: WHICH SINGLE LEG IS CHEAPEST TO CUT?

Breaking any one leg breaks the chain. The analyzer ranks the three legs by
"cut cost" (how much agent capability is lost) and recommends the cheapest.
"""
from __future__ import annotations

# --- signal vocabularies ----------------------------------------------------
# Resources/tools that constitute PRIVATE DATA access
_PRIVATE = (
    "crm", "dataverse", "sql", "cosmos", "sharepoint", "onedrive", "drive",
    "mail", "email", "outlook", "exchange", "graph", "table", "database", "db",
    "storage", "blob", "s3", "bucket", "file", "document", "knowledge",
    "salesforce", "servicenow", "workday", "sap", "hr", "patient", "ehr",
    "customer", "contact", "invoice", "payment", "card", "ledger", "secret",
    "vault", "keyvault",
)
# Sources an ATTACKER can author into
_UNTRUSTED = (
    "web", "browse", "search", "url", "http", "scrape", "rss", "news",
    "email", "mail", "inbox", "ticket", "case", "issue", "form", "upload",
    "attachment", "comment", "review", "feedback", "chat", "teams", "slack",
    "social", "public", "anonymous", "guest", "portal", "widget", "mcp",
)
# Ways data can LEAVE
_EXFIL = (
    "send", "post", "publish", "webhook", "http", "api", "mail", "email",
    "sms", "message", "notify", "teams", "slack", "connector", "flow",
    "power automate", "outbound", "export", "share", "upload", "create",
    "write", "update",
)

_LEG_LABEL = {
    "private_data": "Private data access",
    "untrusted_content": "Untrusted content exposure",
    "external_comms": "External communication",
}

# How disruptive it is to remove each leg (lower = cheaper to cut).
# Untrusted content is usually the cheapest: gate the ingestion channel or
# require auth. Private data is usually the reason the agent exists.
_CUT_COST = {"untrusted_content": 1, "external_comms": 2, "private_data": 3}

_CUT_ADVICE = {
    "untrusted_content": (
        "Close the injection entry point: require authentication on the agent, "
        "disable open web/file ingestion, or route untrusted sources through a "
        "quarantined summarizer sub-agent that holds no private-data scopes."),
    "external_comms": (
        "Remove the exfiltration vector: drop outbound connectors (mail, HTTP, "
        "webhook, Power Automate) or put a human approval gate on any send/post "
        "action so injected instructions cannot complete the loop."),
    "private_data": (
        "Shrink the prize: scope this agent down to the minimum records it "
        "needs, or split private-data reads into a separate agent that never "
        "touches untrusted content."),
}


def _hay(d: dict) -> str:
    """Flatten every capability signal on a descriptor into one search string."""
    parts = []
    for e in d.get("entitlements", []) or []:
        parts.append(str(e.get("resource", "")))
        parts.extend(str(a) for a in e.get("actions", []) or [])
    for ep in d.get("endpoints", []) or []:
        parts.append(str(ep if isinstance(ep, str) else ep.get("url", "")))
    for l in d.get("links", []) or []:
        parts.append(f"{l.get('rel','')} {l.get('label','')} {l.get('target','')}")
    ident = d.get("identity", {}) or {}
    parts.append(str(ident.get("auth", "")))
    parts.append(str(ident.get("kind", "")))
    rh = d.get("risk_hints", {}) or {}
    if rh.get("anonymous"):
        parts.append("anonymous public")
    for k in ("agent_type", "platform"):
        parts.append(str((d.get("agent") or {}).get(k, "")))
    return " ".join(parts).lower()


def _hits(hay: str, vocab: tuple) -> list[str]:
    return sorted({w for w in vocab if w in hay})


def analyze_agent(d: dict) -> dict:
    """Classify one descriptor's three legs, with evidence."""
    hay = _hay(d)
    rh = d.get("risk_hints", {}) or {}
    sensitive = any((e.get("sensitive") for e in d.get("entitlements", []) or []))

    priv = _hits(hay, _PRIVATE)
    untrusted = _hits(hay, _UNTRUSTED)
    exfil = _hits(hay, _EXFIL)

    # anonymous agents are, by definition, fed by untrusted humans
    if rh.get("anonymous"):
        untrusted = sorted(set(untrusted) | {"anonymous"})
    # Foundry's Browser Automation tool drives a real browser — that is the
    # purest possible untrusted-content channel, plus an egress path.
    if rh.get("browser_automation") or "browser_automation" in str(rh.get("risky_tools", "")):
        untrusted = sorted(set(untrusted) | {"browser-automation"})
        exfil = sorted(set(exfil) | {"browser-automation"})
    # MCP servers are a classic mixed source: untrusted content AND egress
    if any((l.get("rel") == "calls_mcp") for l in d.get("links", []) or []):
        untrusted = sorted(set(untrusted) | {"mcp"})
        exfil = sorted(set(exfil) | {"mcp"})
    if sensitive:
        priv = sorted(set(priv) | {"sensitive-flagged"})

    legs = {
        "private_data": {"present": bool(priv), "evidence": priv[:6]},
        "untrusted_content": {"present": bool(untrusted), "evidence": untrusted[:6]},
        "external_comms": {"present": bool(exfil), "evidence": exfil[:6]},
    }
    present = [k for k, v in legs.items() if v["present"]]
    n = len(present)
    status = ("exploitable" if n == 3 else
              "one_away" if n == 2 else
              "limited" if n == 1 else "contained")

    rec = None
    if n == 3:
        cheapest = min(present, key=lambda k: _CUT_COST[k])
        rec = {"cut": cheapest, "label": _LEG_LABEL[cheapest],
               "advice": _CUT_ADVICE[cheapest]}
    elif n == 2:
        missing = [k for k in legs if k not in present][0]
        rec = {"watch": missing, "label": _LEG_LABEL[missing],
               "advice": (f"One capability away from exploitable — adding "
                          f"{_LEG_LABEL[missing].lower()} to this agent would "
                          f"complete the trifecta. Treat as a change-control gate.")}

    return {
        "id": d.get("id", ""),
        "name": d.get("name", "?"),
        "platform": (d.get("agent") or {}).get("platform", ""),
        "agent_type": (d.get("agent") or {}).get("agent_type", ""),
        "environment": (d.get("scope") or {}).get("environment", "")
                       or (d.get("scope") or {}).get("project", ""),
        "portal_url": (d.get("scope") or {}).get("portal_url", ""),
        "legs": legs,
        "legs_present": present,
        "leg_count": n,
        "status": status,
        "sensitive": sensitive,
        "recommendation": rec,
    }


def analyze_fleet(descriptors: list[dict]) -> dict:
    """Fleet-wide trifecta audit — the thing security teams are told to do by
    hand for every agent, done automatically for the whole estate."""
    rows = [analyze_agent(d) for d in descriptors
            if (d.get("agent") or {}).get("platform")]
    exploitable = [r for r in rows if r["status"] == "exploitable"]
    one_away = [r for r in rows if r["status"] == "one_away"]

    # which single leg, cut across the fleet, defuses the most agents?
    cut_wins: dict[str, int] = {}
    for r in exploitable:
        for leg in r["legs_present"]:
            cut_wins[leg] = cut_wins.get(leg, 0) + 1
    fleet_cut = None
    if cut_wins:
        # prefer the cheapest leg among those with the widest effect
        best = max(cut_wins.values())
        candidates = [k for k, v in cut_wins.items() if v == best]
        leg = min(candidates, key=lambda k: _CUT_COST[k])
        fleet_cut = {"leg": leg, "label": _LEG_LABEL[leg], "defuses": cut_wins[leg],
                     "advice": _CUT_ADVICE[leg]}

    pct = round(100 * len(exploitable) / len(rows)) if rows else 0
    rows.sort(key=lambda r: (-r["leg_count"], not r["sensitive"], r["name"].lower()))
    return {
        "agents": rows,
        "totals": {"analyzed": len(rows), "exploitable": len(exploitable),
                   "one_away": len(one_away),
                   "contained": len(rows) - len(exploitable) - len(one_away),
                   "exploitable_pct": pct},
        "fleet_cut": fleet_cut,
        "leg_labels": _LEG_LABEL,
        "benchmark": {"csa_2026_exploitable_pct": 98,
                      "note": "CSA's 2026 agent study found 98% of evaluated "
                              "agents carried all three trifecta conditions."},
    }

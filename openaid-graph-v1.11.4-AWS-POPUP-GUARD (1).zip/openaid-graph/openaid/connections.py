"""Per-platform connection store, set from the GUI.

Microsoft platforms (Azure subs, Power Platform, Foundry) authenticate via the
interactive device-code sign-in in ``auth.py``. The *other* platforms (GCP, AWS,
Cisco/Webex, Salesforce, ServiceNow, UiPath) are connected here by pasting a
bearer token (and, where needed, an instance URL) into the Connections tab.

Everything is in-memory (single-admin tool). Tokens set here override env vars.
"""
from __future__ import annotations

import os

# platform -> {"token": str, "url": str}
_conns: dict[str, dict] = {}

PLATFORMS = [
    {"id": "microsoft", "name": "Microsoft (Azure, Power Platform, Foundry)", "kind": "signin",
     "note": "Azure subscriptions, all Power Platform environments, Copilot Studio, Azure AI Foundry."},
    {"id": "gcp", "name": "Google Cloud (Vertex AI, Agentspace)", "kind": "token",
     "note": "Paste a GCP OAuth access token (gcloud auth print-access-token)."},
    {"id": "aws", "name": "AWS (Bedrock + AgentCore)", "kind": "token_url",
     "note": "Paste a session token / signed credentials for the Bedrock control plane.", "hint": "Paste ACCESS_KEY_ID:SECRET_ACCESS_KEY (SigV4 \u2014 lists classic Bedrock Agents AND AgentCore harnesses/runtimes) or a Bedrock API key (classic agents only). Region goes in the URL field, e.g. us-east-1."},
    {"id": "webex", "name": "Cisco Webex", "kind": "token",
     "note": "Paste a Webex admin/service-app access token."},
    {"id": "salesforce", "name": "Salesforce (Agentforce)", "kind": "token_url",
     "note": "Paste an OAuth token and your instance URL (https://x.my.salesforce.com)."},
    {"id": "servicenow", "name": "ServiceNow (Now Assist)", "kind": "token_url",
     "note": "Paste an OAuth token and your instance (https://x.service-now.com)."},
    {"id": "uipath", "name": "UiPath (RPA robots)", "kind": "token_url",
     "note": "Paste an Orchestrator token and base URL."},
    {"id": "n8n", "name": "n8n (AI agent workflows)", "kind": "token_url",
     "hint": "Self-hosted or cloud n8n: base URL (e.g. https://n8n.example.com) + an API key from Settings > n8n API. AI-agent workflows (LangChain/agent nodes) are tagged; plain automations are listed too."},
    {"id": "openai", "name": "OpenAI (Assistants, GPTs)", "kind": "token",
     "note": "Paste an OpenAI API key (sk-...)."},
    {"id": "anthropic", "name": "Anthropic (Claude agents)", "kind": "token",
     "note": "Paste an Anthropic API key."},
    {"id": "slack", "name": "Slack (AI apps & bots)", "kind": "token",
     "note": "Paste a Slack bot/user token (xoxb-/xoxp-)."},
    {"id": "github", "name": "GitHub (Copilot, Actions agents)", "kind": "token",
     "note": "Paste a GitHub PAT (repo + read:org)."},
    {"id": "atlassian", "name": "Atlassian (Jira/Confluence agents)", "kind": "token_url",
     "note": "Paste an API token and your site URL (https://x.atlassian.net)."},
    {"id": "zendesk", "name": "Zendesk (AI agents)", "kind": "token_url",
     "note": "Paste an API token and subdomain URL (https://x.zendesk.com)."},
    {"id": "okta", "name": "Okta (agent service identities)", "kind": "token_url",
     "note": "Paste an API token and your Okta org URL."},
    {"id": "datadog", "name": "Datadog (agent telemetry)", "kind": "token",
     "note": "Paste an API key to correlate agent runtime signals."},
    {"id": "pagerduty", "name": "PagerDuty (agent incidents)", "kind": "token",
     "note": "Paste an API token to link agents to incident history."},
    {"id": "notion", "name": "Notion (AI connectors)", "kind": "token",
     "note": "Paste an internal integration token."},
]


def set_connection(platform: str, token: str = "", url: str = "") -> dict:
    if platform == "aws":
        token = _clean_aws_token(token)
    _conns[platform] = {"token": token or "", "url": url or ""}
    return {"ok": True, "platform": platform, "connected": bool(token)}


def active_connections() -> dict:
    """platform -> {token,url} for every signed-in third party, including any
    supplied by environment variables so a deploy can pre-seed them."""
    out = {}
    for pid, v in _conns.items():
        if pid.startswith("ms_") or not v.get("token"):
            continue
        out[pid] = {"token": v.get("token", ""), "url": v.get("url", "")}
    for p in PLATFORMS:
        pid = p["id"]
        if pid in out or pid == "microsoft":
            continue
        tok = os.getenv(f"OPENAID_{pid.upper()}_TOKEN", "")
        if tok:
            out[pid] = {"token": tok,
                        "url": os.getenv(f"OPENAID_{pid.upper()}_URL", "")}
    return out


def clear_connection(platform: str) -> dict:
    _conns.pop(platform, None)
    return {"ok": True, "platform": platform}


def token_for(platform: str) -> str:
    return _conns.get(platform, {}).get("token", "") or os.getenv(f"OPENAID_{platform.upper()}_TOKEN", "")


def ms_token(resource: str) -> str:
    """Pasted Microsoft resource token (arm/bap/dataverse/foundry), if set.
    Lets discovery run without app-registration consent — the user pastes tokens
    from `az account get-access-token --resource <resource>`."""
    return _conns.get(f"ms_{resource}", {}).get("token", "")


def ms_url(resource: str) -> str:
    """Pasted org URL that accompanies a Microsoft token (e.g. the Dataverse
    org the dataverse token is for)."""
    return _conns.get(f"ms_{resource}", {}).get("url", "")


def any_ms_token() -> bool:
    return any(_conns.get(f"ms_{r}", {}).get("token") for r in ("arm", "bap", "dataverse", "foundry"))


def url_for(platform: str, env_key: str = "") -> str:
    u = _conns.get(platform, {}).get("url", "")
    if u:
        return u
    return os.getenv(env_key, "") if env_key else ""


def status(auth_mod=None) -> dict:
    """Report connect state per platform (for the Connections tab)."""
    signed_in = bool(auth_mod and auth_mod.status().get("signed_in"))
    out = []
    for p in PLATFORMS:
        if p["id"] == "microsoft":
            connected = signed_in
            detail = (auth_mod.status().get("account", "") if auth_mod else "")
        else:
            connected = bool(_conns.get(p["id"], {}).get("token"))
            detail = _conns.get(p["id"], {}).get("url", "")
        out.append({**p, "connected": connected, "detail": detail})
    return {"platforms": out}


# ---- live token validation (popup "Validate & connect") ---------------------
_VALIDATORS = {
    "gcp": lambda url: ("GET", "https://cloudresourcemanager.googleapis.com/v1/projects?pageSize=1"),
    "webex": lambda url: ("GET", "https://webexapis.com/v1/people/me"),
    "salesforce": lambda url: ("GET", f"{url.rstrip('/')}/services/data"),
    "servicenow": lambda url: ("GET", f"{url.rstrip('/')}/api/now/table/sys_user?sysparm_limit=1"),
    "uipath": lambda url: ("GET", f"{url.rstrip('/')}/odata/Users?$top=1"),
    "openai": lambda url: ("GET", "https://api.openai.com/v1/models"),
    "anthropic": lambda url: ("GET", "https://api.anthropic.com/v1/models"),
    "slack": lambda url: ("GET", "https://slack.com/api/auth.test"),
    "n8n": lambda url: ("GET", (url or "").rstrip("/") + "/api/v1/workflows?limit=1"),
    "github": lambda url: ("GET", "https://api.github.com/user"),
    "atlassian": lambda url: ("GET", f"{url.rstrip('/')}/rest/api/3/myself"),
    "zendesk": lambda url: ("GET", f"{url.rstrip('/')}/api/v2/users/me.json"),
    "okta": lambda url: ("GET", f"{url.rstrip('/')}/api/v1/users/me"),
    "datadog": lambda url: ("GET", "https://api.datadoghq.com/api/v1/validate"),
    "pagerduty": lambda url: ("GET", "https://api.pagerduty.com/users?limit=1"),
    "notion": lambda url: ("GET", "https://api.notion.com/v1/users?page_size=1"),
}


def _clean_aws_token(token: str) -> str:
    """People paste what the console gives them — full export lines, quotes,
    trailing newlines. Normalize before judging the credential."""
    t = (token or "").strip().strip("'\"")
    for pfx in ("export AWS_BEARER_TOKEN_BEDROCK=", "AWS_BEARER_TOKEN_BEDROCK=",
                "set AWS_BEARER_TOKEN_BEDROCK="):
        if t.startswith(pfx):
            t = t[len(pfx):].strip().strip("'\"")
    return "".join(t.split())   # kill embedded whitespace/newlines


def _validate_aws(token: str, url: str, fetch) -> dict:
    """AWS validation hits the surface the credential can actually reach:
    ACCESS:SECRET -> SigV4 ListAgentRuntimes on the AgentCore control plane;
    a Bedrock API key -> bearer against classic bedrock-agent, with a warning
    that AgentCore harnesses stay invisible to bearer keys."""
    from .collectors.aws_sigv4 import parse_credentials, sigv4_headers
    token = _clean_aws_token(token)
    region = (url or "us-east-1").strip() or "us-east-1"
    creds = parse_credentials(token)
    if creds:
        ak, sk, st = creds
        vurl = (f"https://bedrock-agentcore-control.{region}.amazonaws.com"
                f"/runtimes/?maxResults=1")
        hdr = sigv4_headers("POST", vurl, service="bedrock-agentcore",
                            region=region, access_key=ak, secret_key=sk,
                            session_token=st)
        try:
            fetch("POST", vurl, headers=hdr)
            return {"ok": True,
                    "detail": f"SigV4 verified against AgentCore in {region} "
                              "(classic + AgentCore agents will list)"}
        except Exception as e:  # noqa: BLE001
            return {"ok": False,
                    "detail": f"SigV4 rejected by AgentCore in {region}: "
                              f"{str(e)[:160]} — check key, permissions "
                              "(bedrock-agentcore:ListAgentRuntimes), and region"}
    # Bedrock API keys ("bedrock-api-key-...") authenticate CORE Bedrock ops
    # only — they cannot call the agent control planes (ListAgents 403s, and
    # AgentCore needs SigV4). Probe a surface the key actually supports so
    # the verdict is truthful, then say exactly what is missing.
    if token.strip().startswith("bedrock-api-key-"):
        vurl = f"https://bedrock.{region}.amazonaws.com/foundation-models"
        try:
            fetch("GET", vurl, headers={"Authorization": f"Bearer {token}"})
            return {"ok": False,
                    "detail": "This is a Bedrock API key — it authenticates "
                              "core Bedrock, but CANNOT list agents (classic "
                              "ListAgents is denied and AgentCore requires "
                              "SigV4). Paste ACCESS_KEY_ID:SECRET_ACCESS_KEY "
                              "instead (IAM > Security credentials > Create "
                              "access key)."}
        except Exception as e:  # noqa: BLE001
            return {"ok": False,
                    "detail": f"Bedrock API key rejected in {region}: "
                              f"{str(e)[:140]} — and API keys can't list "
                              "agents anyway; paste ACCESS_KEY:SECRET"}
    vurl = f"https://bedrock-agent.{region}.amazonaws.com/agents/"
    try:
        fetch("GET", vurl, headers={"Authorization": f"Bearer {token}"})
        return {"ok": True,
                "detail": "Bearer verified against classic Bedrock agents in "
                          f"{region}. WARNING: AgentCore harnesses will NOT "
                          "list with a bearer credential — paste "
                          "ACCESS_KEY_ID:SECRET_ACCESS_KEY for full coverage"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False,
                "detail": f"credential rejected: {str(e)[:140]} — paste "
                          "ACCESS_KEY_ID:SECRET_ACCESS_KEY from IAM > "
                          "Security credentials > Create access key"}


def validate(platform: str, token: str, url: str, fetch) -> dict:
    """Make ONE cheap real API call with the pasted token so the popup can say
    'connected' truthfully."""
    if platform == "aws":
        return _validate_aws(token, url, fetch)
    if platform not in _VALIDATORS:
        return {"ok": bool(token), "detail": "saved (no live validation for this platform)"}
    if platform in ("salesforce", "servicenow", "uipath", "n8n") and not url:
        return {"ok": False, "detail": "instance URL required"}
    method, vurl = _VALIDATORS[platform](url or "")
    # per-platform auth header (n8n uses its own key header, not Bearer)
    hdr = ({"X-N8N-API-KEY": token} if platform == "n8n"
           else {"Authorization": f"Bearer {token}"})
    try:
        fetch(method, vurl, headers=hdr)
        return {"ok": True, "detail": "token verified against live API"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "detail": f"validation failed: {str(e)[:200]}"}


# popup metadata: where to GET a token + branding, per platform
CONNECT_GUIDE = {
    "microsoft": {"name": "Microsoft", "color": "#6c8cff", "device_flow": True,
                  "steps": ["Click 'Open Microsoft sign-in' — a code is shown here.",
                            "Enter the code on the Microsoft page and approve.",
                            "This window closes itself when sign-in completes."]},
    "gcp": {"name": "Google Cloud", "color": "#e8c268", "token_url": "https://console.cloud.google.com/",
            "cmd": "gcloud auth print-access-token",
            "steps": ["Open Cloud Shell (button below) or a local terminal.",
                      "Run the command shown and copy the token.",
                      "Paste it here and Validate & connect."]},
    "aws": {"name": "AWS", "color": "#e0a458",
            "token_url": "https://console.aws.amazon.com/cloudshell/home",
            "cmd": ("aws configure export-credentials --format process | "
                    "python3 -c \"import json,sys;d=json.load(sys.stdin);"
                    "print(d['AccessKeyId']+':'+d['SecretAccessKey']+':'"
                    "+d.get('SessionToken',''))\""),
            "steps": [
                "Open CloudShell — the [>_] icon in the AWS console footer (button below opens it).",
                "Run the one-liner below. It prints ONE line: ACCESS:SECRET:SESSION — copy it.",
                "Paste that line here, region in the second field (us-east-1), Validate & connect. (Long-lived alternative: IAM > Security credentials > Create access key, pasted as ACCESS_KEY_ID:SECRET_ACCESS_KEY.)",
                "Do NOT use Bedrock > API keys — a 'bedrock-api-key-...' has no secret inside and can never list agents."]},
    "webex": {"name": "Cisco Webex", "color": "#7bd88f", "token_url": "https://developer.webex.com/docs/getting-started",
              "steps": ["Open the Webex developer portal (button below) and sign in.",
                        "Copy your personal access token (or a service-app token).",
                        "Paste it here and Validate & connect."]},
    "salesforce": {"name": "Salesforce", "color": "#6fb7ff", "token_url": "https://login.salesforce.com/",
                   "needs_url": True,
                   "steps": ["Sign in to Salesforce (button below).",
                             "Get an OAuth access token (e.g. `sf org display --json` -> accessToken).",
                             "Paste token + your instance URL, then Validate & connect."]},
    "servicenow": {"name": "ServiceNow", "color": "#8fd88f", "token_url": "https://developer.servicenow.com/",
                   "needs_url": True,
                   "steps": ["Sign in to your ServiceNow instance.",
                             "Create/copy an OAuth token (System OAuth > tokens).",
                             "Paste token + instance URL, then Validate & connect."]},
    "uipath": {"name": "UiPath", "color": "#ff8f6f", "token_url": "https://cloud.uipath.com/",
               "needs_url": True,
               "steps": ["Sign in to UiPath Cloud (button below).",
                         "Admin > API Access — copy a token for Orchestrator.",
                         "Paste token + Orchestrator URL, then Validate & connect."]},
    "openai": {"name": "OpenAI", "color": "#10a37f", "token_url": "https://platform.openai.com/api-keys",
               "steps": ["Open the OpenAI API keys page (button below).",
                         "Create a key and copy it.",
                         "Paste it here and Validate & connect."]},
    "anthropic": {"name": "Anthropic", "color": "#d97757", "token_url": "https://console.anthropic.com/settings/keys",
                  "steps": ["Open the Anthropic console keys page (button below).",
                            "Create an API key and copy it.",
                            "Paste it here and Validate & connect."]},
    "n8n": {"name": "n8n", "color": "#ea4b71", "token_url": "https://docs.n8n.io/api/authentication/"},
    "slack": {"name": "Slack", "color": "#4a154b", "token_url": "https://api.slack.com/apps",
              "steps": ["Open your Slack app's OAuth page (button below).",
                        "Copy a Bot or User OAuth token (xoxb-/xoxp-).",
                        "Paste it here and Validate & connect."]},
    "github": {"name": "GitHub", "color": "#6e5494", "token_url": "https://github.com/settings/tokens",
               "steps": ["Open GitHub token settings (button below).",
                         "Generate a PAT with repo + read:org and copy it.",
                         "Paste it here and Validate & connect."]},
    "atlassian": {"name": "Atlassian", "color": "#0052cc", "token_url": "https://id.atlassian.com/manage-profile/security/api-tokens",
                  "needs_url": True,
                  "steps": ["Open Atlassian API tokens (button below) and create one.",
                            "Paste the token + your site URL (https://x.atlassian.net).",
                            "Validate & connect."]},
    "zendesk": {"name": "Zendesk", "color": "#03363d", "token_url": "https://www.zendesk.com/",
                "needs_url": True,
                "steps": ["Admin Center > Apps and integrations > APIs > Zendesk API.",
                          "Create an API token; paste it + your subdomain URL.",
                          "Validate & connect."]},
    "okta": {"name": "Okta", "color": "#007dc1", "token_url": "https://www.okta.com/",
             "needs_url": True,
             "steps": ["Okta admin > Security > API > Tokens > Create token.",
                       "Paste the token and your org URL (https://x.okta.com).",
                       "Validate & connect."]},
    "datadog": {"name": "Datadog", "color": "#632ca6",
                "token_url": "https://app.datadoghq.com/organization-settings/api-keys",
                "steps": ["Open Datadog API keys (button below).",
                          "Copy an API key.", "Paste it here and Validate & connect."]},
    "pagerduty": {"name": "PagerDuty", "color": "#06ac38",
                  "token_url": "https://support.pagerduty.com/main/docs/api-access-keys",
                  "steps": ["PagerDuty > Integrations > API Access Keys.",
                            "Create a read-only key.", "Paste it and Validate & connect."]},
    "notion": {"name": "Notion", "color": "#111111",
               "token_url": "https://www.notion.so/my-integrations",
               "steps": ["Open Notion integrations (button below).",
                         "Create an internal integration and copy its token.",
                         "Paste it here and Validate & connect."]},
}

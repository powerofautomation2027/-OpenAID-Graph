"""Global search — one box across every dataset in the console.

Operators asked the same thing repeatedly: "I know the agent name, just take me
to everything about it." This indexes agents, findings, hierarchy links, MCP
servers and subscriptions into one ranked result set with a jump target.
"""
from __future__ import annotations


def _hit(q: str, *fields) -> int:
    """Score: exact match beats prefix beats substring."""
    q = q.lower().strip()
    if not q:
        return 0
    best = 0
    for f in fields:
        s = str(f or "").lower()
        if not s:
            continue
        if s == q:
            best = max(best, 100)
        elif s.startswith(q):
            best = max(best, 70)
        elif q in s:
            best = max(best, 40)
    return best


def search(query: str, inventory: dict | None = None,
           findings: list | None = None, hierarchies: list | None = None,
           limit: int = 25) -> dict:
    inv = inventory or {}
    out = []

    for a in inv.get("agents", []) or []:
        s = _hit(query, a.get("name"), a.get("platform"), a.get("environment"),
                 a.get("native_id"), a.get("identity"))
        if s:
            out.append({"score": s, "kind": "agent", "title": a.get("name", "?"),
                        "subtitle": f"{a.get('platform','')} · {a.get('environment','')}",
                        "tab": "agents", "id": a.get("id", ""),
                        "portal_url": a.get("portal_url", ""),
                        "badge": ("anonymous" if a.get("anonymous") else "")})

    for f in findings or []:
        s = _hit(query, f.get("title"), f.get("rule"), f.get("subject"), f.get("detail"))
        if s:
            out.append({"score": s - 5, "kind": "finding",
                        "title": f.get("title", f.get("rule", "?")),
                        "subtitle": f"{f.get('severity','')} · {f.get('rule','')}",
                        "tab": "findings", "id": f.get("agent_id", ""),
                        "badge": f.get("severity", "")})

    for h in hierarchies or []:
        for c in h.get("children", []) or []:
            s = _hit(query, c.get("name"), h.get("parent_name"))
            if s:
                out.append({"score": s - 10, "kind": "relationship",
                            "title": f"{c.get('name','?')}",
                            "subtitle": f"{c.get('type','')} of {h.get('parent_name','')}",
                            "tab": "hierarchy", "id": c.get("id", ""),
                            "portal_url": c.get("portal_url", ""),
                            "badge": c.get("type", "")})

    for m in inv.get("mcp_servers", []) or []:
        s = _hit(query, m.get("url"), m.get("name"))
        if s:
            out.append({"score": s - 10, "kind": "mcp_server",
                        "title": m.get("name") or m.get("url", "?"),
                        "subtitle": f"{m.get('callers',0)} caller(s)",
                        "tab": "mcp", "id": m.get("url", ""),
                        "badge": m.get("auth", "")})

    for sub in inv.get("subscriptions", []) or []:
        s = _hit(query, sub.get("name"), sub.get("id"))
        if s:
            out.append({"score": s - 15, "kind": "subscription",
                        "title": sub.get("name", "?"),
                        "subtitle": f"{sub.get('agents',0)} agent(s)",
                        "tab": "environments", "id": sub.get("id", ""),
                        "portal_url": sub.get("portal_url", ""), "badge": ""})

    out.sort(key=lambda r: (-r["score"], r["kind"], r["title"].lower()))
    kinds: dict = {}
    for r in out:
        kinds[r["kind"]] = kinds.get(r["kind"], 0) + 1
    return {"query": query, "results": out[:limit],
            "totals": {"matches": len(out), "by_kind": kinds}}

"""Graph-aware risk rules. These only exist because we now have a graph.

Each rule returns zero or more findings. A finding is::

    {"rule": id, "severity": band, "title": str, "subject": node_id|None,
     "detail": str, "evidence": {...}}

The v0.1 rules scored a single descriptor in isolation. These score *relations*
— which is the whole point of building the graph.
"""
from __future__ import annotations


def evaluate(graph, blasts, pivots) -> list[dict]:
    findings = []
    findings += _critical_blast(blasts)
    findings += _cross_platform_pivot(pivots)
    findings += _shared_mcp_no_auth(graph)
    findings += _rpa_with_ai_reach(graph)
    findings += _unresolved_mcp_calls(graph)
    findings += _identity_fan_in(graph)
    findings += _privilege_non_inheritance(graph)
    findings += _connected_agent_reuse(graph)
    findings += _delegation_depth(graph)
    findings += _anonymous_parent_children(graph)
    findings += _unresolved_child_agent(graph)
    return findings


def _critical_blast(blasts) -> list[dict]:
    out = []
    for b in blasts:
        if b["severity"] in ("critical", "high") and b["reachable_total"] > 0:
            out.append({
                "rule": "OAID-G001", "severity": b["severity"],
                "title": f"High blast radius from {b['origin_name']}",
                "subject": b["origin"],
                "detail": (f"Compromise reaches {b['reachable_total']} nodes, "
                           f"{len(b['sensitive_resources'])} sensitive stores, "
                           f"pivoting to {', '.join(b['cross_platform']) or 'no other'} platform(s)."),
                "evidence": {"score": b["score"], "sensitive": b["sensitive_resources"],
                             "cross_platform": b["cross_platform"]},
            })
    return out


def _cross_platform_pivot(pivots) -> list[dict]:
    return [{
        "rule": "OAID-G002", "severity": "high",
        "title": f"Cross-platform pivot through shared MCP: {p['mcp']}",
        "subject": None,
        "detail": f"{p['mcp']} is reachable from {', '.join(p['shared_by'])} — "
                  "one compromised platform can drive tools on the others.",
        "evidence": p,
    } for p in pivots]


def _shared_mcp_no_auth(graph) -> list[dict]:
    out = []
    for n in graph.nodes.values():
        if n.kind != "mcp_server":
            continue
        callers = graph.inn.get(n.id, [])
        auth = n.meta.get("risk_hints", {}).get("auth_declared", "unknown")
        pub = n.meta.get("risk_hints", {}).get("public_ingress")
        if len(callers) >= 1 and (auth in ("unknown", "none", "") or pub):
            out.append({
                "rule": "OAID-G003", "severity": "high" if pub else "medium",
                "title": f"MCP server with weak/unknown auth invoked by agents: {n.name}",
                "subject": n.id,
                "detail": f"{len(callers)} caller(s); declared auth '{auth}', "
                          f"public ingress={bool(pub)}.",
                "evidence": {"callers": len(callers), "auth": auth, "public": bool(pub)},
            })
    return out


def _rpa_with_ai_reach(graph) -> list[dict]:
    """An RPA robot (holds real desktop creds) reachable from an AI agent is a
    classic under-appreciated escalation: prompt -> agent -> robot -> ERP."""
    out = []
    for n in graph.nodes.values():
        if n.kind != "rpa_robot":
            continue
        ai_callers = [e for e in graph.inn.get(n.id, [])
                      if graph.nodes.get(e.src) and graph.nodes[e.src].kind == "agent"]
        if ai_callers:
            out.append({
                "rule": "OAID-G004", "severity": "high",
                "title": f"AI agent can drive RPA robot with stored credentials: {n.name}",
                "subject": n.id,
                "detail": f"{len(ai_callers)} AI agent(s) reach this robot; "
                          f"robot holds {n.meta.get('risk_hints', {}).get('credential_assets', '?')} credential asset(s).",
                "evidence": {"ai_callers": len(ai_callers)},
            })
    return out


def _unresolved_mcp_calls(graph) -> list[dict]:
    out = []
    for n in graph.nodes.values():
        if n.kind == "mcp_server" and n.meta.get("unresolved"):
            out.append({
                "rule": "OAID-G005", "severity": "medium",
                "title": f"Agent calls an MCP endpoint not in inventory: {n.name}",
                "subject": n.id,
                "detail": "The target MCP server was referenced by an agent but never "
                          "discovered — a governance blind spot by definition.",
                "evidence": {"endpoint": n.name},
            })
    return out


def _identity_fan_in(graph) -> list[dict]:
    """One identity (SA / user / role) that many agents authenticate as = single
    point of compromise across the fleet."""
    out = []
    for n in graph.nodes.values():
        if n.kind != "identity":
            continue
        users = [e for e in graph.inn.get(n.id, []) if e.rel == "authenticates_as"]
        if len(users) >= 3:
            out.append({
                "rule": "OAID-G006", "severity": "medium",
                "title": f"Shared identity used by {len(users)} agents: {n.name}",
                "subject": n.id,
                "detail": "Many agents share one principal; compromising it compromises all of them.",
                "evidence": {"agent_count": len(users)},
            })
    return out


# ---- hierarchy-aware rules (parent -> child / connected agents) ------------
from openaid.graph.trust_graph import HIERARCHY  # noqa: E402


def _children_of(graph, node_id):
    return [graph.nodes[e.dst] for e in graph.out.get(node_id, [])
            if e.rel in HIERARCHY and e.dst in graph.nodes]


def _agent_resources(graph, node_id):
    return {e.dst for e in graph.out.get(node_id, [])
            if graph.nodes.get(e.dst) and graph.nodes[e.dst].kind == "resource"}


def _privilege_non_inheritance(graph) -> list[dict]:
    """Foundry/Copilot connected agents get their OWN identity — permissions do
    not inherit from the parent. Flag a child whose OWN sensitive access exceeds
    the parent's OWN access: the parent operator may not realize the child holds
    reach they themselves were never granted. Compares direct entitlements (not
    transitive) — since delegation is traversable, transitive reach would always
    fold the child's access into the parent's and hide the gap."""
    out = []
    for n in graph.nodes.values():
        if n.kind != "agent":
            continue
        kids = _children_of(graph, n.id)
        if not kids:
            continue
        parent_sensitive = {graph.nodes[r].name for r in _agent_resources(graph, n.id)
                            if graph.nodes[r].meta.get("sensitive")}
        for c in kids:
            child_sensitive = {graph.nodes[r].name for r in _agent_resources(graph, c.id)
                              if graph.nodes[r].meta.get("sensitive")}
            extra = child_sensitive - parent_sensitive
            if extra:
                out.append({
                    "rule": "OAID-G007", "severity": "high",
                    "title": f"Child agent out-privileges its parent: {c.name}",
                    "subject": c.id,
                    "detail": (f"'{c.name}' (under '{n.name}') directly holds sensitive access the parent "
                               f"does not: {', '.join(sorted(extra))}. "
                               "Connected/child agents carry their own identity — permissions don't inherit."),
                    "evidence": {"parent": n.name, "extra_sensitive": sorted(extra)},
                })
    return out


def _connected_agent_reuse(graph) -> list[dict]:
    """A connected agent reused by multiple parents is a shared blast surface:
    compromising it, or any one parent, exposes all the others."""
    out = []
    for n in graph.nodes.values():
        if n.kind != "agent":
            continue
        parents = [e.src for e in graph.inn.get(n.id, []) if e.rel in HIERARCHY]
        if len(parents) >= 2:
            pnames = [graph.nodes[p].name for p in parents if p in graph.nodes]
            out.append({
                "rule": "OAID-G008", "severity": "medium",
                "title": f"Connected agent reused by {len(parents)} parents: {n.name}",
                "subject": n.id,
                "detail": f"Shared by {', '.join(pnames)}. One compromised parent (or this agent) "
                          "reaches across every parent that reuses it.",
                "evidence": {"parents": pnames},
            })
    return out


def _delegation_depth(graph, max_depth=2) -> list[dict]:
    """Foundry caps connected-agent depth at 2 (parent -> subagent, no deeper).
    A discovered chain deeper than that is a misconfiguration or an unexpected
    orchestration path worth surfacing."""
    out = []
    def depth(node_id, seen):
        kids = [e.dst for e in graph.out.get(node_id, []) if e.rel in HIERARCHY]
        best = 0
        for k in kids:
            if k in seen:
                continue
            best = max(best, 1 + depth(k, seen | {k}))
        return best
    roots = [n for n in graph.nodes.values()
             if n.kind == "agent" and not any(e.rel in HIERARCHY for e in graph.inn.get(n.id, []))]
    for r in roots:
        d = depth(r.id, {r.id})
        if d > max_depth:
            out.append({
                "rule": "OAID-G009", "severity": "medium",
                "title": f"Delegation chain deeper than allowed: {r.name} (depth {d})",
                "subject": r.id,
                "detail": f"Connected-agent depth is capped at {max_depth}; this tree is {d} deep. "
                          "Deep chains add latency, blur governance, and may hit tool-call-depth errors.",
                "evidence": {"depth": d, "limit": max_depth},
            })
    return out


def _anonymous_parent_children(graph) -> list[dict]:
    """An anonymously-authenticated parent agent that delegates to children is a
    front door: unauthenticated input drives the whole subtree."""
    out = []
    for n in graph.nodes.values():
        if n.kind != "agent":
            continue
        if not n.meta.get("risk_hints", {}).get("anonymous"):
            continue
        kids = _children_of(graph, n.id)
        if kids:
            out.append({
                "rule": "OAID-G010", "severity": "high",
                "title": f"Anonymous parent drives {len(kids)} child agent(s): {n.name}",
                "subject": n.id,
                "detail": f"'{n.name}' accepts anonymous input and delegates to "
                          f"{', '.join(c.name for c in kids)}. Unauthenticated prompts reach the whole subtree.",
                "evidence": {"children": [c.name for c in kids]},
            })
    return out


def _unresolved_child_agent(graph) -> list[dict]:
    """A parent references a child/connected agent that wasn't discovered in the
    environment — a governance blind spot in the multi-agent tree."""
    out = []
    for n in graph.nodes.values():
        if n.kind == "agent" and n.meta.get("synthetic") and n.meta.get("parent"):
            parent = graph.nodes.get(n.meta["parent"])
            out.append({
                "rule": "OAID-G011", "severity": "medium",
                "title": f"Undiscovered child agent referenced: {n.name}",
                "subject": n.id,
                "detail": (f"'{parent.name if parent else '?'}' delegates to '{n.name}', which was not "
                           "found in the inventory — its identity and reach are unknown."),
                "evidence": {"child_kind": n.meta.get("child_kind", "")},
            })
    return out

"""Usage analytics — sessions per Copilot agent + token usage per Foundry account.

Data sources (best available without per-agent billing APIs):
* Copilot Studio: Dataverse `conversationtranscripts`, grouped per bot over the
  last 7 days (each transcript = one session with that agent).
* Azure AI Foundry / Azure OpenAI: Azure Monitor `TokenTransaction` metric per
  Cognitive Services account over the last 7 days (token usage is metered at
  the account level, attributed to the agents in that account).
"""
from __future__ import annotations

import datetime as _dt


def _utcnow():
    return _dt.datetime.now(_dt.timezone.utc)

ARM = "https://management.azure.com"


def aggregate(copilot_rows: list[dict], foundry_rows: list[dict],
              agents: list[dict], user_rows: list[dict] | None = None) -> dict:
    """Pure aggregation so it is unit-testable.
    copilot_rows: [{bot_id, sessions}], foundry_rows: [{account, tokens, subscription}]
    agents: inventory agent rows (id/native_id/name/environment/platform)."""
    user_rows = user_rows or []
    by_native = {a.get("native_id", ""): a for a in agents}
    top_agents = []
    for r in sorted(copilot_rows, key=lambda x: -x.get("sessions", 0)):
        a = by_native.get(r.get("bot_id", ""), {})
        top_agents.append({
            "name": a.get("name") or r.get("bot_id", "?"),
            "environment": a.get("environment", ""),
            "platform": "copilot_studio",
            "sessions": r.get("sessions", 0),
            "portal_url": a.get("portal_url", ""),
        })
    env_sessions: dict[str, int] = {}
    for t in top_agents:
        k = t["environment"] or "?"
        env_sessions[k] = env_sessions.get(k, 0) + t["sessions"]

    # token usage by environment: map each Foundry account's tokens onto the
    # environment(s) of the agents that live in that subscription.
    acct_env: dict[str, str] = {}
    for a in agents:
        if a.get("platform") in ("azure_foundry", "azure_openai"):
            acct_env.setdefault(a.get("subscription_name", "") or a.get("environment", ""),
                                a.get("environment", "") or a.get("project", ""))
    env_tokens: dict[str, int] = {}
    for r in foundry_rows:
        env = r.get("environment") or acct_env.get(r.get("subscription", ""), r.get("account", "?"))
        env_tokens[env] = env_tokens.get(env, 0) + r.get("tokens", 0)

    environments = []
    all_envs = set(env_sessions) | set(env_tokens)
    for e in all_envs:
        environments.append({"environment": e,
                             "sessions": env_sessions.get(e, 0),
                             "tokens": env_tokens.get(e, 0)})
    environments.sort(key=lambda x: -(x["sessions"] + x["tokens"]))

    top_users = sorted(user_rows, key=lambda x: -x.get("sessions", 0))[:15] if user_rows else []

    foundry = sorted(foundry_rows, key=lambda x: -x.get("tokens", 0))
    total_sessions = sum(t["sessions"] for t in top_agents)
    total_tokens = sum(f.get("tokens", 0) for f in foundry_rows)
    return {"top_agents": top_agents[:15], "environments": environments,
            "foundry_tokens": foundry[:15], "top_users": top_users,
            "totals": {"sessions": total_sessions, "tokens": total_tokens,
                       "agents": len(top_agents), "environments": len(all_envs)},
            "window": "last 7 days"}


def copilot_sessions(fetch, org_url: str, dv_token: str) -> list[dict]:
    """Sessions per bot in one environment, last 7 days."""
    since = (_utcnow() - _dt.timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
    hdr = {"Authorization": f"Bearer {dv_token}", "Accept": "application/json",
           "OData-MaxVersion": "4.0", "OData-Version": "4.0"}
    url = (f"{org_url.rstrip('/')}/api/data/v9.2/conversationtranscripts"
           f"?$select=_bot_conversationtranscriptid_value,createdon"
           f"&$filter=createdon ge {since}&$top=5000")
    j = fetch("GET", url, headers=hdr) or {}
    counts: dict[str, int] = {}
    for row in j.get("value", []):
        b = (row.get("_bot_conversationtranscriptid_value") or "").lower()
        if b:
            counts[b] = counts.get(b, 0) + 1
    return [{"bot_id": k, "sessions": v} for k, v in counts.items()]


def foundry_tokens(fetch, arm_token: str, account_ids: list[dict]) -> list[dict]:
    """TokenTransaction (7d total) per Cognitive Services account via Azure
    Monitor. account_ids: [{id, name, subscription}]."""
    end = _utcnow()
    start = end - _dt.timedelta(days=7)
    ts = f"{start:%Y-%m-%dT%H:%M:%SZ}/{end:%Y-%m-%dT%H:%M:%SZ}"
    hdr = {"Authorization": f"Bearer {arm_token}"}
    out = []
    for acct in account_ids:
        url = (f"{ARM}{acct['id']}/providers/microsoft.insights/metrics"
               f"?metricnames=TokenTransaction&timespan={ts}"
               f"&interval=P1D&aggregation=Total&api-version=2023-10-01")
        try:
            j = fetch("GET", url, headers=hdr) or {}
        except Exception:
            continue
        total = 0
        for m in j.get("value", []):
            for series in m.get("timeseries", []):
                for pt in series.get("data", []):
                    total += int(pt.get("total") or 0)
        out.append({"account": acct.get("name", "?"), "tokens": total,
                    "subscription": acct.get("subscription", "")})
    return out


def copilot_users(fetch, org_url: str, dv_token: str) -> list[dict]:
    """Highest-usage users: count conversation transcripts per initiating user
    across the environment, last 7 days (best-effort — falls back silently if
    the createdby field isn't populated)."""
    since = (_utcnow() - _dt.timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
    hdr = {"Authorization": f"Bearer {dv_token}", "Accept": "application/json",
           "OData-MaxVersion": "4.0", "OData-Version": "4.0",
           "Prefer": 'odata.include-annotations="OData.Community.Display.V1.FormattedValue"'}
    url = (f"{org_url.rstrip('/')}/api/data/v9.2/conversationtranscripts"
           f"?$select=_createdby_value,createdon"
           f"&$filter=createdon ge {since}&$top=5000")
    try:
        j = fetch("GET", url, headers=hdr) or {}
    except Exception:
        return []
    counts: dict[str, dict] = {}
    for row in j.get("value", []):
        uid = row.get("_createdby_value") or ""
        name = row.get("_createdby_value@OData.Community.Display.V1.FormattedValue") or uid
        if not uid:
            continue
        c = counts.setdefault(uid, {"user": name, "sessions": 0})
        c["sessions"] += 1
    return list(counts.values())

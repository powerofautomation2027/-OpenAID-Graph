"""Copilot Studio collector — agents plus their child and connected agents.

Reliability-first: the top priority is that agents actually LIST. Earlier we
requested a Dataverse column that doesn't exist, which 400s the whole query and
returns zero agents. This version:

* selects only columns that exist on the ``bot`` entity,
* sends the Dataverse OData headers Dataverse expects,
* lists agents first, then best-effort discovers child/connected agents from the
  ``botcomponent`` table — a failure there never hides the agents.

Copilot Studio multi-agent shapes:
  * child agents     — embedded, share the parent's tools/knowledge
  * connected agents — independent, delegated to; own identity
Both are surfaced as ``delegates_to`` / ``connects_to`` links so the graph
nests them under the main agent.

Config: OPENAID_DATAVERSE_URLS (comma list) or resolved from environment
enumeration. Token supplied by caller (Dataverse-audience).
"""
from __future__ import annotations

import os
import re
from urllib.parse import quote

from ._shared import _stable_id, build_descriptor, http_json, report, skip

API = "/api/data/v9.2"
DV_HEADERS = {
    "Accept": "application/json",
    "OData-MaxVersion": "4.0",
    "OData-Version": "4.0",
}


def _get(fetch, base, hdr, path):
    return http_json(fetch, "GET", f"{base}{API}/{path}", headers=hdr) or {}


def _anon(mode) -> bool:
    # authenticationmode option set: 1 == "No authentication" in Copilot Studio
    return str(mode) in ("1", "noauthentication", "none")


INVENTORY_URL = ("https://api.powerplatform.com/resourcequery/resources/query"
                 "?api-version=2024-10-01")


def _inventory_agent_ids(fetch, pp_token: str) -> dict:
    """GROUND TRUTH from Microsoft's own tenant inventory (GA, 2024-10-01):
    POST resourcequery with KQL returns every Copilot Studio / Agent Builder
    agent; the `name` field is THE agent id the portal addresses. We key it by
    (environmentId, schemaName) and (environmentId, displayName) and put this
    id in the /copilots/{id}/details slot — no more deriving portal identity
    from the Dataverse botid, which can differ and bounces to home when it
    does. Any failure returns {} and the derived candidates still apply."""
    if not pp_token:
        return {}
    body = {"TableName": "PowerPlatformResources", "Clauses": [
        {"$type": "where", "FieldName": "type", "Operator": "==",
         "Values": ["'microsoft.copilotstudio/agents'"]},
        {"$type": "project", "FieldList": [
            "name", "properties.displayName", "properties.environmentId",
            "properties.schemaName"]},
        {"$type": "take", "TakeCount": 1000}]}
    try:
        j = http_json(fetch, "POST", INVENTORY_URL,
                      headers={"Authorization": f"Bearer {pp_token}",
                               "Content-Type": "application/json"},
                      json=body) or {}
    except Exception:
        return {}
    out: dict = {}
    for row in (j.get("data") or j.get("value") or []):
        props = row.get("properties") or {}
        aid = str(row.get("name", "")).strip()
        env = str(props.get("environmentId", "")).strip().lower()
        if not (aid and env):
            continue
        for k in (str(props.get("schemaName", "")).strip().lower(),
                  str(props.get("displayName", "")).strip().lower()):
            if k:
                out[(env, k)] = aid
    return out


def collect(fetch, token: str | None = None, dataverse_urls: list[str] | None = None,
            env_index: dict | None = None, pp_token: str = "") -> dict:
    urls = dataverse_urls or [u for u in os.getenv("OPENAID_DATAVERSE_URLS", "").split(",") if u]
    if not urls:
        return skip("copilot_environment", "OPENAID_DATAVERSE_URLS not set")
    if not token:
        return skip("copilot_environment", "no Dataverse token (sign in / grant Dataverse consent)")

    hdr = {"Authorization": f"Bearer {token}", **DV_HEADERS}
    env_index = env_index or {}
    docs, scopes, errors = [], [], []
    # Microsoft's own tenant inventory: (envId, schema/display) -> portal agent id
    inv_ids = _inventory_agent_ids(fetch, pp_token)

    for base in urls:
        base = base.rstrip("/")
        # 1) list agents (bots) — SAFE select of columns that exist
        try:
            data = _get(fetch, base, hdr,
                        "bots?$select=botid,name,schemaname,authenticationmode,createdon,modifiedon,statecode,_ownerid_value")
            bots = data.get("value", [])
        except Exception as e:  # noqa: BLE001
            errors.append({"scope": base, "surface": "bots", "error": str(e)})
            scopes.append({"kind": "copilot_environment", "id": base, "status": "error"})
            continue

        # 2) child/connected components. Try TWO sources, because either can be
        # blocked or empty in a given org:
        #   (a) $expand on the bot record (works when the separate botcomponents
        #       table read is restricted)
        #   (b) a direct botcomponents query
        # Connected/child agents appear as references to another bot's schema
        # name inside the component payload, so we detect by *reference*.
        comps_by_bot: dict[str, list] = {}
        # The relationship is `botcomponent_parent_bot` (bot -> its components).
        # Using the wrong relationship name makes Dataverse return the bots with
        # no components at all — silently zero children.
        for rel in ("botcomponent_parent_bot", "bot_botcomponent"):
            try:
                exp = _get(fetch, base, hdr,
                           f"bots?$select=botid&$expand={rel}("
                           "$select=botcomponentid,name,schemaname,componenttype,data)")
                for b in exp.get("value", []):
                    kids = b.get(rel) or []
                    if kids:
                        comps_by_bot.setdefault(b.get("botid"), []).extend(kids)
                if comps_by_bot:
                    break
            except Exception as e:  # noqa: BLE001
                errors.append({"scope": base, "surface": f"expand:{rel}", "error": str(e)[:200]})
        if not comps_by_bot:
            try:
                comp = _get(fetch, base, hdr,
                            "botcomponents?$select=botcomponentid,name,schemaname,"
                            "componenttype,_parentbotid_value,data")
                for c in comp.get("value", []):
                    pid = c.get("_parentbotid_value")
                    if pid:
                        comps_by_bot.setdefault(pid, []).append(c)
            except Exception as e:  # noqa: BLE001
                errors.append({"scope": base, "surface": "botcomponents", "error": str(e)})
                try:
                    comp = _get(fetch, base, hdr,
                                "botcomponents?$select=botcomponentid,name,schemaname,"
                                "componenttype,_parentbotid_value")
                    for c in comp.get("value", []):
                        pid = c.get("_parentbotid_value")
                        if pid:
                            comps_by_bot.setdefault(pid, []).append(c)
                except Exception:
                    pass

        id_by = {b.get("botid"): b for b in bots}
        # Match ONLY on schemaname (namespaced, e.g. cr123_myAgent) — never on
        # the display name. Matching free-text names caused every component whose
        # YAML merely contained a common word (e.g. an agent literally named
        # "Agent") to register as a child of every other agent.
        schema_to_bot = {b.get("schemaname"): b for b in bots
                         if b.get("schemaname") and len(str(b.get("schemaname"))) >= 4}
        guid_to_bot = {b.get("botid", "").lower(): b for b in bots if b.get("botid")}
        env_meta = env_index.get(base) or {}
        env_id = env_meta.get("id") or ""

        def _portal_candidates(botid: str) -> list:
            """Copilot Studio now ships TWO agent experiences (classic and new)
            on different routes, and Microsoft does not publish the deep-link
            path. So we emit ORDERED CANDIDATES and let the app's resolver land
            the user: new experience, classic experience, then the environment
            home (which always works and lists the agents)."""
            b = id_by.get(botid) or {}
            schema = b.get("schemaname") or botid
            if not env_id:
                return ["https://copilotstudio.microsoft.com/"]
            # GROUND TRUTH override: the tenant Inventory API's agent id is
            # what the portal actually addresses. When it differs from the
            # Dataverse botid, the botid-built URL is the one bouncing to
            # home — the inventory id goes FIRST.
            _envl = str(env_id).strip().lower()
            inv_id = (inv_ids.get((_envl, str(schema).strip().lower()))
                      or inv_ids.get((_envl, str(b.get("name", "")).strip().lower()))
                      or "")
            # PROVEN from a live portal URL:
            #   copilotstudio.microsoft.com/environments/Default-{tenantId}/home
            # The DEFAULT environment is addressed as "Default-{tenantId}",
            # not as the BAP environment GUID — and agents in the DEFAULT env
            # silently bounce to the Copilot Studio home page when addressed
            # by the GUID. For default environments the Default- root goes
            # FIRST; for named environments the GUID root goes first.
            import os as _os
            tid = env_meta.get("tenant_id", "") or _os.environ.get("OPENAID_TENANT_ID", "")
            guid_root = f"https://copilotstudio.microsoft.com/environments/{env_id}"
            roots = [guid_root]
            if tid and not str(env_id).lower().startswith("default-"):
                dflt_root = f"https://copilotstudio.microsoft.com/environments/Default-{tid}"
                # BAP outage resilience: when environments come from
                # globaldisco (no is_default flag), the FriendlyName still
                # says "(default)" — infer from it so default-env agents keep
                # Default-first addressing even with BAP down.
                _is_dflt = (env_meta.get("is_default")
                            or "default" in str(env_meta.get("name", "")).lower())
                if _is_dflt:
                    roots = [dflt_root, guid_root]
                else:
                    roots.append(dflt_root)
            root = roots[0]
            # GROUNDED: Microsoft's own Power Platform API addresses an agent as
            #   /copilotstudio/environments/{EnvironmentId}/bots/{BotId}
            # i.e. the BOT ID GUID — NOT the schema name. A schema-name URL
            # returns "Looks like that link is broken". GUID forms go first.
            # VERIFIED WORKING against a live tenant:
            #   /environments/{bapEnvGuid}/bots/{botId}/overview
            # The BAP environment GUID (not Default-{tenantId}) and the BOT ID
            # (not the schema name, not /agents/). The portal silently redirects
            # any invalid path to the environment home, which is exactly what a
            # wrong guess looked like. Proven form goes FIRST.
            # CANONICAL (2026): Microsoft's own agent metadata emits
            #   /environments/{envId}/copilots/{botId}/details
            # (deepLinkUrl in copilotStudioMetadata). This is the current
            # portal shape — it goes FIRST. The previously-proven
            # /bots/{botId}/overview stays as the immediate fallback for
            # tenants still on the classic experience.
            out = []
            # ORDER MATTERS — LEARNED THE HARD WAY: the Dataverse botid form
            # was CONFIRMED WORKING in this live tenant. The Inventory API's
            # agent id is a different identifier space and is NOT guaranteed
            # to be the portal slug — when it led the list it broke working
            # links. It stays as a LATE fallback only, never the primary.
            for r in roots:
                for u in (f"{r}/copilots/{botid}/details",
                          f"{r}/bots/{botid}/overview",
                          f"{r}/bots/{botid}",
                          f"{r}/agents/{botid}/overview",
                          f"{r}/bots/{schema}/overview"):
                    if u not in out:
                        out.append(u)
            if inv_id and inv_id != botid:
                for r in roots:
                    u = f"{r}/copilots/{inv_id}/details"
                    if u not in out:
                        out.append(u)
            out += [f"{r}/home" for r in roots]
            return out

        def _portal(botid: str) -> str:
            # GROUNDED IN THE COPILOT STUDIO URL SCHEME: the maker portal opens
            # an agent by its ENVIRONMENT id + the agent's SCHEMA NAME, not the
            # raw bot GUID:
            #   https://copilotstudio.microsoft.com/environments/{envId}/bots/{schemaName}/overview
            # Using the bot GUID (what we did before) lands on a "not found"
            # page. Fall back to the GUID only if we somehow lack a schema name.
            if env_id:
                # canonical current portal shape (matches Microsoft's own
                # deepLinkUrl metadata): /copilots/{botId}/details
                return (f"https://copilotstudio.microsoft.com/environments/"
                        f"{env_id}/copilots/{botid}/details")
            return "https://copilotstudio.microsoft.com/"

        def _desc_id(botid: str) -> str:
            # Link targets MUST be descriptor ids (oaid:...) — raw botids never
            # match a graph node and silently render as synthetic duplicates.
            return _stable_id("copilot_studio", botid)

        for bot in bots:
            links = []
            seen_targets = set()
            for c in comps_by_bot.get(bot["botid"], []):
                blob = " ".join(str(c.get(k, "")) for k in ("schemaname", "name", "data"))
                low = blob.lower()

                # (1) TRUE CHILD AGENTS: botcomponents whose YAML is an
                # AgentDialog triggered by OnToolSelected. They are NOT bots,
                # so schema-name matching can never find them — this was the
                # reason Child/Connected showed 0.
                if ("agentdialog" in low and "ontoolselected" in low):
                    tkey = f"child:{c.get('botcomponentid')}"
                    if tkey not in seen_targets:
                        seen_targets.add(tkey)
                        links.append({"rel": "delegates_to", "target": tkey,
                                      "kind": "child",
                                      "label": c.get("name") or c.get("schemaname") or "child agent"})
                    continue

                # (2) MCP / external tool references are NOT child agents
                if "invokeexternalagenttaskaction" in low or "mcp" in low:
                    for murl in re.findall(r"https?://[^\s\"']+", blob):
                        if murl not in seen_targets:
                            seen_targets.add(murl)
                            links.append({"rel": "calls_mcp", "target": murl})
                    continue

                # (3) CONNECTED AGENTS by explicit invoke marker + GUID ref
                is_connected_marker = ("invokeconnectedagent" in low
                                       or "connectedagent" in low
                                       or "invokeagenttaskaction" in low)
                matched = False
                for g in re.findall(
                        r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
                        r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", blob):
                    other = guid_to_bot.get(g.lower())
                    if not other or other["botid"] == bot["botid"]:
                        continue
                    tkey = _desc_id(other["botid"])
                    if tkey in seen_targets:
                        continue
                    seen_targets.add(tkey)
                    links.append({"rel": "connects_to", "target": tkey,
                                  "kind": "connected",
                                  "label": other.get("name") or g})
                    matched = True

                # (4) CONNECTED AGENTS by another bot's SCHEMA name
                for key, other in schema_to_bot.items():
                    if other["botid"] == bot["botid"]:
                        continue
                    if re.search(rf"(?<![A-Za-z0-9_]){re.escape(key)}(?![A-Za-z0-9_])", blob):
                        tkey = _desc_id(other["botid"])
                        if tkey in seen_targets:
                            continue
                        seen_targets.add(tkey)
                        links.append({"rel": "connects_to", "target": tkey,
                                      "kind": "connected",
                                      "label": other.get("name") or key})
                        matched = True
                if is_connected_marker and not matched:
                    # marker present but target not resolvable to a bot in this
                    # env (cross-env / Foundry / M365 SDK agent) — still show it
                    tkey = f"connected:{c.get('botcomponentid')}"
                    if tkey not in seen_targets:
                        seen_targets.add(tkey)
                        links.append({"rel": "connects_to", "target": tkey,
                                      "kind": "connected",
                                      "label": c.get("name") or "connected agent"})
            anon = _anon(bot.get("authenticationmode"))
            docs.append(build_descriptor(
                platform="copilot_studio",
                agent_type="copilot_studio_agent",
                name=bot.get("name", bot.get("schemaname", "?")),
                native_id=bot["botid"],
                scope={"kind": "copilot_environment", "dataverse": base,
                       "environment": env_meta.get("name") or base,
                       "environment_id": env_id,
                       "schema_name": bot.get("schemaname", ""),
                       "portal_url": _portal(bot["botid"]),
                       "portal_candidates": _portal_candidates(bot["botid"])},
                identity={"kind": "copilot_agent",
                          "auth": "anonymous" if anon else "authenticated"},
                links=links,
                risk_hints={"anonymous": anon,
                            "created_on": bot.get("createdon", ""),
                            "modified_on": bot.get("modifiedon", ""),
                            "statecode": bot.get("statecode"),
                            "owner_id": bot.get("_ownerid_value", ""),
                            "child_count": sum(1 for l in links if l["rel"] == "delegates_to"),
                            "connected_count": sum(1 for l in links if l["rel"] == "connects_to"),
                            "portal_url": _portal(bot["botid"])},
                raw={"botid": bot["botid"], "schemaname": bot.get("schemaname", "")},
            ))
        scopes.append({"kind": "copilot_environment", "id": base, "status": "read", "agents": len(bots)})

    return report(docs, scopes, errors)

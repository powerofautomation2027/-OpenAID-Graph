"""Azure AI Foundry Agent Service collector — main agents + connected subagents.

Foundry connected agents let a primary agent delegate to purpose-built
subagents. Two facts from the Foundry docs drive the risk model here:

* Each *published* connected agent gets its **own Agent Identity** — permissions
  do NOT inherit from the parent's development identity. So a subagent can hold
  broader (or narrower) access than the parent that calls it. That mismatch is a
  finding, not a footnote.
* Connected agents have a **max depth of 2** — a parent has subagent siblings,
  but subagents can't have their own subagents. A discovered chain deeper than
  that signals a misconfiguration.

Reads agents from the Foundry project data plane. Each agent's ``tools`` array
contains ``connected_agent`` tool entries naming the subagents; we emit a
``delegates_to`` link so the hierarchy renders under the main agent.

Config: OPENAID_FOUNDRY_ENDPOINTS (comma list of project endpoints). Token from
caller. API version defaults to the multi-agent preview.
"""
from __future__ import annotations

import base64
import uuid

import os

from ._shared import _stable_id, build_descriptor, http_json, report, skip

APIV = "2025-11-15-preview"

# ALL Foundry agent surfaces, swept per project endpoint. Microsoft Foundry now
# hosts several agent TYPES, on different routes:
#   * classic Agent Service agents .... /agents?api-version=v1 (GA 2025-05-01)
#   * Prompt Agents + Hosted Agents ... /agents?api-version=2025-11-15-preview
#       (hosted agents are container-backed; need the preview feature header)
#   * legacy Assistants-protocol ...... /assistants?api-version=<preview>
#   * Azure OpenAI Assistants ......... {account}/openai/assistants (per
#       account, not per project — swept once per account, deduped)
# Every surface is tried; results are merged and deduped by agent id/name so a
# resource that answers on several routes doesn't double-count.
_HOSTED_HDR = {"Foundry-Features": "HostedAgents=V1Preview"}
# GROUNDED IN DOCS: on Foundry projects, "agents" list at
#   GET {endpoint}/assistants?api-version=v1     (also GA 2025-05-01,
#   preview 2025-05-15-preview) — the resource is literally named
#   "assistants" in the REST path even though the product says agents.
# The /agents path is the NEWER surface (prompt/hosted/workflow agents,
# preview needs the HostedAgents feature header). Sweep BOTH families,
# every version; merge + dedupe.
_SURFACES = (
    # NEW Foundry Agents service first — the classic Assistants API retires
    # 2026-08-26, and agents created in the new portal list ONLY here.
    ("agents?api-version=v1", "agent", None),
    ("agents?api-version=2025-05-01", "agent", None),
    ("agents?api-version=2025-11-15-preview", "agent", None),
    (f"agents?api-version={APIV}", "agent", _HOSTED_HDR),
    ("assistants?api-version=v1", "assistant", None),
    ("assistants?api-version=2025-05-01", "assistant", None),
    ("assistants?api-version=2025-05-15-preview", "assistant", None),
    (f"assistants?api-version={APIV}", "assistant", None),
)


# Foundry hosted agents can be built on external SDKs — surface which one, so
# an Anthropic-SDK or OpenAI-SDK agent is visible as such in the inventory.
_FRAMEWORKS = {"anthropic": "anthropic_agent_sdk", "claude": "anthropic_agent_sdk",
               "openai-agents": "openai_agents_sdk", "langgraph": "langgraph",
               "agent-framework": "microsoft_agent_framework",
               "copilot": "github_copilot_sdk"}

# tools introduced by recent Foundry waves that materially change risk
_HIGH_RISK_TOOLS = {
    "browser_automation": "Drives a real browser — ingests fully untrusted web content.",
    "code_interpreter": "Executes generated code.",
    "mcp": "Trusts tool definitions served by an MCP endpoint.",
    "openapi": "Calls arbitrary external APIs.",
    "bing_grounding": "Ingests live web results.",
    "azure_function": "Invokes custom compute.",
}


def framework_of(item: dict) -> str:
    blob = " ".join(str(x).lower() for x in
                    (item.get("definition", {}) or {}).values()) + " " + \
           str(item.get("framework", "")).lower()
    for k, v in _FRAMEWORKS.items():
        if k in blob:
            return v
    return ""


def risky_tools(item: dict) -> list:
    out = []
    for t in item.get("tools", []) or []:
        ttype = str(t.get("type", "")).lower()
        for k in _HIGH_RISK_TOOLS:
            if k in ttype:
                out.append(k)
    return sorted(set(out))


def encode_sub(subscription_id: str) -> str:
    """Foundry's New ("nextgen") portal addresses a subscription as the
    base64url of the GUID's RAW BIG-ENDIAN BYTES, unpadded.

        a9307114-91f9-4e69-ab19-3fec0b52ef70 -> qTBxFJH5TmmrGT_sC1LvcA

    Verified byte-for-byte against a live portal URL. Note this is NOT the
    .NET little-endian Guid.ToByteArray() order, which yields a different
    string and a broken link.
    """
    try:
        u = uuid.UUID(str(subscription_id))
    except Exception:  # noqa: BLE001
        return ""
    return base64.urlsafe_b64encode(u.bytes).decode().rstrip("=")


def nextgen_url(subscription_id: str, resource_group: str, account: str,
                project: str, agent_name: str = "", tenant_id: str = "") -> str:
    """Build a New Foundry portal link:

    https://ai.azure.com/nextgen/r/{encSub},{rg},,{account},{project}
        /build/agents/{agentName}/build?tid={tenantId}

    The empty 4th slot is present in the live portal URL and is preserved.
    """
    enc = encode_sub(subscription_id)
    if not (enc and resource_group and account and project):
        return ""
    root = (f"https://ai.azure.com/nextgen/r/"
            f"{enc},{resource_group},,{account},{project}")
    path = f"/build/agents/{agent_name}/build" if agent_name else "/build/agents"
    tid = f"?tid={tenant_id}" if tenant_id else ""
    return f"{root}{path}{tid}"


def parse_arm_id(arm_id: str) -> dict:
    """Pull subscription / resource group / account name out of an ARM id."""
    parts = [p for p in str(arm_id or "").split("/") if p]
    out = {"subscription": "", "resource_group": "", "account": ""}
    for i, p in enumerate(parts):
        low = p.lower()
        if low == "subscriptions" and i + 1 < len(parts):
            out["subscription"] = parts[i + 1]
        elif low == "resourcegroups" and i + 1 < len(parts):
            out["resource_group"] = parts[i + 1]
        elif low == "accounts" and i + 1 < len(parts):
            out["account"] = parts[i + 1]
    return out


def _classify(item: dict, surface: str) -> str:
    """Map a raw item to an OpenAID agent_type."""
    definition = item.get("definition") or {}
    kind = str(definition.get("kind") or item.get("kind") or "").lower()
    if "hosted" in kind:
        return "foundry_hosted_agent"
    if "prompt" in kind:
        return "foundry_prompt_agent"
    if "workflow" in kind:
        return "foundry_workflow_agent"
    if surface == "assistant":
        # project /assistants IS the GA agents list — classify as foundry_agent
        return "foundry_agent"
    return "foundry_agent"


XRAY: list = []   # per-run trace of every endpoint x surface attempt


def _agents(fetch, endpoint, hdr):
    """Sweep every surface; return [(item, agent_type)], deduped, and never let
    one dead route hide agents that another route returns. Every attempt is
    traced into XRAY so a silent zero-agent outcome explains itself."""
    found: dict[str, tuple] = {}
    last = None
    hit_any = False
    for path, surface, extra in _SURFACES:
        url = f"{endpoint.rstrip('/')}/{path}"
        h = {**hdr, **(extra or {})}
        try:
            j = http_json(fetch, "GET", url, headers=h) or {}
        except Exception as e:  # noqa: BLE001
            last = e
            XRAY.append({"endpoint": endpoint, "surface": path,
                         "result": f"ERROR: {str(e)[:160]}"})
            continue
        n = len(j.get("value", j.get("data", [])) or [])
        XRAY.append({"endpoint": endpoint, "surface": path,
                     "result": f"OK: {n} item(s)"})
        hit_any = True
        for item in j.get("value", j.get("data", [])) or []:
            key = str(item.get("id") or item.get("name") or "")
            if not key:
                continue
            atype = _classify(item, surface)
            prev = found.get(key)
            # specific types beat the generic classification
            if prev is None or (prev[1] in ("foundry_agent", "foundry_assistant")
                                and atype not in ("foundry_agent", "foundry_assistant")):
                found[key] = (item, atype)
    if not hit_any and last:
        raise last
    return list(found.values())


def _aoai_assistants(fetch, account_base: str, hdr):
    """Azure OpenAI Assistants live on the ACCOUNT, not the project:
    {account}/openai/assistants?api-version=2025-04-01-preview
    (token audience https://cognitiveservices.azure.com)."""
    last = None
    for ver in ("2025-04-01-preview", "2024-05-01-preview"):
        url = f"{account_base.rstrip('/')}/openai/assistants?api-version={ver}"
        try:
            j = http_json(fetch, "GET", url, headers=hdr) or {}
        except Exception as e:  # noqa: BLE001
            last = e
            continue
        items = j.get("data", j.get("value", [])) or []
        if items:
            return items
    if last:
        raise last
    return []


def _connected_from_tools(agent: dict) -> list[dict]:
    """Both payload shapes: {"type":"connected_agent","connected_agent":{...}}
    and camelCase variants. Returns [{"id","name"}]."""
    out = []
    for t in agent.get("tools", []) or []:
        ttype = str(t.get("type", "")).lower()
        if "connected_agent" not in ttype and "connectedagent" not in ttype:
            continue
        ca = t.get("connected_agent") or t.get("connectedAgent") or {}
        out.append({"id": ca.get("id") or ca.get("agent_id") or "",
                    "name": ca.get("name") or ""})
    return out


def collect(fetch, token: str | None = None, endpoints: list[str] | None = None,
            ep_meta: dict | None = None, cogsvc_token: str | None = None) -> dict:
    eps = endpoints or [e for e in os.getenv("OPENAID_FOUNDRY_ENDPOINTS", "").split(",") if e]
    if not eps:
        return skip("foundry_project", "OPENAID_FOUNDRY_ENDPOINTS not set")
    hdr = {"Authorization": f"Bearer {token}"} if token else {}
    # The account-level Azure OpenAI data plane (/openai/assistants) does NOT
    # accept the ai.azure.com-audience token — it needs the Cognitive Services
    # audience. Silent 401s here made AOAI-type agents invisible.
    aoai_hdr = ({"Authorization": f"Bearer {cogsvc_token}"} if cogsvc_token else hdr)
    ep_meta = ep_meta or {}
    XRAY.clear()
    docs, scopes, errors = [], [], []
    known_all: set[str] = set()
    extra_eps: list[str] = []
    for ep in list(eps):
        try:
            agents = _agents(fetch, ep, hdr)
        except Exception as e:  # noqa: BLE001
            # The project name may be a guess (ARM listed no projects, so the
            # account name was used). Ask the DATA PLANE for the real project
            # list and queue those endpoints instead of erroring out.
            base = ep.split("/api/projects")[0].rstrip("/")
            recovered = False
            for ver in ("v1", "2025-05-01", "2025-11-15-preview"):
                try:
                    j = http_json(fetch, "GET",
                                  f"{base}/api/projects?api-version={ver}",
                                  headers=hdr) or {}
                except Exception:
                    continue
                for proj in j.get("value", []) or []:
                    pname = str(proj.get("name", "")).split("/")[-1]
                    if not pname:
                        continue
                    nep = f"{base}/api/projects/{pname}"
                    if nep not in eps and nep not in extra_eps:
                        extra_eps.append(nep)
                        ep_meta.setdefault(nep, dict(ep_meta.get(ep) or {}, project=pname))
                        recovered = True
                if recovered:
                    break
            if not recovered:
                errors.append({"scope": ep, "surface": "agents", "error": str(e)})
                scopes.append({"kind": "foundry_project", "id": ep, "status": "error"})
            continue
        meta = ep_meta.get(ep) or {}

        def _portal(agent_id: str) -> str:
            arm_id, proj = meta.get("arm_id", ""), meta.get("project", "")
            # GROUNDED IN FOUNDRY PORTAL OUTPUT: the agents playground opens at
            #   https://ai.azure.com/build/agents/{agentId}/build?wsid={armId}/projects/{proj}
            # (the old /resource/agents/{id}?wsid= form does not resolve).
            if arm_id and proj:
                return _portal_candidates(agent_id)[0]
            return "https://ai.azure.com/"

        def _portal_candidates(agent_id: str, agent_name: str = "",
                               version: str = "1") -> list:
            """GROUNDED in Foundry's own azd deploy output:
                https://ai.azure.com/.../build/agents/{agentName}/build?version=1
            The playground addresses an agent by its NAME and a VERSION — not by
            the assistant id. Id-addressed forms are kept as fallbacks for older
            resources."""
            arm_id, proj = meta.get("arm_id", ""), meta.get("project", "")
            if not (arm_id and proj):
                return ["https://ai.azure.com/"]
            from urllib.parse import quote as _q
            a = parse_arm_id(arm_id)
            tid = meta.get("tenant_id", "")
            key = agent_name or agent_id   # classic wsid forms accept either
            out = []
            # PRIMARY: New Foundry ("nextgen") — PROVEN byte-for-byte against a
            # live URL from this very tenant:
            #   /nextgen/r/{encSub},{rg},,{account},{project}
            #       /build/agents/{agentNAME}/build?tid={tenant}
            # The portal addresses agents by NAME. When an agent has no name,
            # NEVER put the assistant id in the name slot (that bounces to the
            # portal home) — go to the project's agents LIST instead, where the
            # agent is one click away in the right project.
            ng_name = (nextgen_url(a["subscription"], a["resource_group"],
                                   a["account"], proj, _q(str(agent_name)), tid)
                       if agent_name else "")
            ng_list = nextgen_url(a["subscription"], a["resource_group"],
                                  a["account"], proj, "", tid)
            if agent_name and ng_name:
                # PLAYGROUND first (the section operators actually want),
                # sibling route of the proven /build page; build page next.
                ng_play = ng_name.replace(f"/build/agents/{_q(str(agent_name))}/build",
                                          f"/build/agents/{_q(str(agent_name))}/playground")
                out.append(ng_play)
                out.append(ng_play.replace("/nextgen/r/", "/r/"))
                out.append(ng_name)
                out.append(ng_name.replace("/nextgen/r/", "/r/"))
            if ng_list:
                out.append(ng_list)
                out.append(ng_list.replace("/nextgen/r/", "/r/"))
            # LATE fallback: some tenants' portal slug is the assistant id
            # (auto-named agents). After the list forms so a bad guess can
            # never precede a guaranteed-good project page.
            if agent_id and agent_id != agent_name:
                ng_id = nextgen_url(a["subscription"], a["resource_group"],
                                    a["account"], proj, _q(str(agent_id)), tid)
                if ng_id:
                    out.append(ng_id)
            # FALLBACKS: classic wsid-addressed forms for older portals
            wsid = f"{arm_id}/projects/{proj}"
            out += [f"https://ai.azure.com/build/agents/{key}/build"
                    f"?wsid={wsid}&version={version or '1'}",
                    f"https://ai.azure.com/build/agents/{key}/build?wsid={wsid}",
                    f"https://ai.azure.com/build/agents?wsid={wsid}",
                    f"https://ai.azure.com/build/overview?wsid={wsid}"]
            return out

        typed = agents  # [(item, agent_type)]
        agents = [t[0] for t in typed]
        atype_by_id = {str(a.get("id") or a.get("name")): t for a, t in typed}
        id_by_name = {a.get("name", a.get("id")): a.get("id") for a in agents}
        known_ids = {a.get("id") for a in agents}
        known_all.update(str(k) for k in known_ids if k)
        for a in agents:
            connected = _connected_from_tools(a)
            links = []
            for ca in connected:
                raw = ca.get("id") or id_by_name.get(ca.get("name", ""))
                label = ca.get("name") or raw or "?"
                if raw and raw in known_ids:
                    # descriptor id, NOT the raw agent id — raw ids never match
                    # a graph node and render as synthetic duplicates.
                    tgt = _stable_id("azure_foundry", raw)
                else:
                    tgt = f"foundry:subagent:{label}"
                links.append({"rel": "connects_to", "target": tgt,
                              "kind": "connected", "label": label})
            # subagent's own identity edge, when the platform exposes it
            ident = a.get("metadata", {}).get("agent_identity") or a.get("agent_identity")
            if ident:
                links.append({"rel": "authenticates_as", "target": f"entra:{ident}"})
            docs.append(build_descriptor(
                platform="azure_foundry",
                agent_type=atype_by_id.get(str(a.get("id") or a.get("name")), "foundry_agent"),
                name=a.get("name", a.get("id", "?")),
                native_id=a.get("id", ""),
                scope={"kind": "foundry_project", "endpoint": ep,
                       "project": meta.get("project", ""),
                       "arm_id": meta.get("arm_id", ""),
                       "subscription": meta.get("subscription_id", ""),
                       "subscription_name": meta.get("subscription_name", ""),
                       "portal_url": _portal_candidates(
                           a.get("id", ""), a.get("name", ""),
                           str(a.get("version", "1")))[0],
                       "portal_candidates": _portal_candidates(
                           a.get("id", ""), a.get("name", ""),
                           str(a.get("version", "1")))},
                identity={"kind": "foundry_agent_identity", "principal": ident or ""},
                entitlements=[{"resource": f"foundry:model:{a.get('model', '?')}", "actions": ["invoke"]}],
                links=links,
                risk_hints={"connected_count": len(connected),
                            "has_own_identity": bool(ident),
                            "model": a.get("model", ""),
                            "framework": framework_of(a),
                            "risky_tools": ",".join(risky_tools(a)),
                            "browser_automation": "browser_automation" in risky_tools(a),
                            "version": str(a.get("version", "")),
                            "portal_url": ((_portal_candidates(
                                a.get("id", ""), a.get("name", ""),
                                str(a.get("version", "1"))) or
                                ["https://ai.azure.com/"])[0])},
                raw={"id": a.get("id", ""), "model": a.get("model", "")},
            ))
        by_type: dict[str, int] = {}
        for _a, t in typed:
            by_type[t] = by_type.get(t, 0) + 1
        scopes.append({"kind": "foundry_project", "id": ep, "status": "read",
                       "agents": len(agents), "agent_types": by_type})

    # ---- second pass: endpoints recovered from data-plane project listing ---
    for ep in extra_eps:
        try:
            agents = _agents(fetch, ep, hdr)
        except Exception as e:  # noqa: BLE001
            errors.append({"scope": ep, "surface": "agents", "error": str(e)})
            scopes.append({"kind": "foundry_project", "id": ep, "status": "error"})
            continue
        meta = ep_meta.get(ep) or {}

        def _portal2(agent_id: str) -> str:
            arm_id, proj = meta.get("arm_id", ""), meta.get("project", "")
            # GROUNDED IN FOUNDRY PORTAL OUTPUT: the agents playground opens at
            #   https://ai.azure.com/build/agents/{agentId}/build?wsid={armId}/projects/{proj}
            # (the old /resource/agents/{id}?wsid= form does not resolve).
            if arm_id and proj and agent_id:
                return (f"https://ai.azure.com/build/agents/{agent_id}/build"
                        f"?wsid={arm_id}/projects/{proj}")
            if arm_id and proj:
                return f"https://ai.azure.com/build/overview?wsid={arm_id}/projects/{proj}"
            return "https://ai.azure.com/"

        typed = agents
        agents = [t[0] for t in typed]
        atype_by_id2 = {str(a.get("id") or a.get("name")): t for a, t in typed}
        known_all.update(str(a.get("id")) for a in agents if a.get("id"))
        for a in agents:
            docs.append(build_descriptor(
                platform="azure_foundry",
                agent_type=atype_by_id2.get(str(a.get("id") or a.get("name")), "foundry_agent"),
                name=a.get("name", a.get("id", "?")),
                native_id=a.get("id", "") or str(a.get("name", "")),
                scope={"kind": "foundry_project", "endpoint": ep,
                       "project": meta.get("project", ""),
                       "subscription": meta.get("subscription_id", ""),
                       "subscription_name": meta.get("subscription_name", ""),
                       "portal_url": _portal2(a.get("id", ""))},
                identity={"kind": "foundry_agent_identity", "principal": ""},
                entitlements=[{"resource": f"foundry:model:{a.get('model', '?')}",
                               "actions": ["invoke"]}],
                links=[],
                risk_hints={"model": a.get("model", ""),
                            "portal_url": _portal2(a.get("id", ""))},
                raw={"id": a.get("id", "")},
            ))
        scopes.append({"kind": "foundry_project", "id": ep, "status": "read",
                       "agents": len(agents), "recovered": True})
        eps = list(eps) + [ep]

    # ---- Azure OpenAI Assistants: swept once per ACCOUNT (deduped) ----------
    seen_accounts: set[str] = set()
    for ep in eps:
        # project endpoint looks like https://acct.services.ai.azure.com/api/projects/p
        base = ep.split("/api/projects")[0].rstrip("/")
        meta = ep_meta.get(ep) or {}
        if not base or base in seen_accounts:
            continue
        seen_accounts.add(base)
        assistants = []
        # AOAI assistants may answer on the services.ai host OR only on the
        # legacy account host (cognitiveservices/openai) — try both.
        for cand in (base, meta.get("aoai_base", "")):
            if not cand:
                continue
            try:
                assistants = _aoai_assistants(fetch, cand, aoai_hdr)
            except Exception:
                continue
            if assistants:
                break
        if not assistants:
            continue
        for a in assistants:
            aid = str(a.get("id") or a.get("name") or "")
            if not aid or aid in known_all:
                continue
            known_all.add(aid)
            docs.append(build_descriptor(
                platform="azure_openai",
                agent_type="openai_assistant",
                name=a.get("name") or aid,
                native_id=aid,
                scope={"kind": "foundry_project", "endpoint": base,
                       "subscription": meta.get("subscription_id", ""),
                       "subscription_name": meta.get("subscription_name", ""),
                       "arm_id": meta.get("arm_id", ""),
                       "portal_url": (f"https://ai.azure.com/resource/overview?wsid={meta.get('arm_id')}"
                                      if meta.get("arm_id") else "https://oai.azure.com/")},
                identity={"kind": "aoai_assistant"},
                entitlements=[{"resource": f"foundry:model:{a.get('model', '?')}",
                               "actions": ["invoke"]}],
                links=[],
                risk_hints={"model": a.get("model", "")},
                raw={"id": aid, "model": a.get("model", "")},
            ))
        if assistants:
            scopes.append({"kind": "foundry_project", "id": f"{base} (AOAI assistants)",
                           "status": "read", "agents": len(assistants)})
    return report(docs, scopes, errors)

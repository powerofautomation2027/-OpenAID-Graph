"""Enumerate ALL Power Platform environments, then Copilot agents in each.

Two-stage discovery so the app lists every environment (not just ones the
operator pinned):

1. BAP admin API lists every environment in the tenant, with its Dataverse
   instance URL.
2. Each environment's Dataverse is then read for Copilot Studio agents (handled
   by ``copilot_studio.collect`` given the resolved URLs).

Returns environment descriptors AND the resolved Dataverse URL list so the
orchestrator can feed them into the Copilot collector.

Config: token supplied by caller (BAP-scoped). No manual URL list needed.
"""
from __future__ import annotations

from ._shared import http_json, report, skip

BAP_ADMIN = ("https://api.bap.microsoft.com/providers/Microsoft.BusinessAppPlatform"
             "/scopes/admin/environments?api-version=2016-11-01")
BAP_USER = ("https://api.bap.microsoft.com/providers/Microsoft.BusinessAppPlatform"
            "/environments?api-version=2016-11-01")


def collect(fetch, token: str | None = None):
    """Returns (report, dataverse_urls, env_index).

    env_index maps dataverse_url -> {id, name} so agents can be tagged with the
    environment they live in.
    """
    if not token:
        return skip("powerplatform_env", "no BAP token supplied"), [], {}
    hdr = {"Authorization": f"Bearer {token}"}
    # Try the admin endpoint (needs PP admin); fall back to the per-user endpoint
    # so environments still list for a non-admin signed-in user.
    data, used = None, None
    for url, label in ((BAP_ADMIN, "admin"), (BAP_USER, "user")):
        try:
            data = http_json(fetch, "GET", url, headers=hdr) or {}
            used = label
            break
        except Exception as e:  # noqa: BLE001
            last_err = str(e)
    if data is None:
        return (report([], [{"kind": "powerplatform_env", "status": "error"}],
                       [{"scope": "bap", "error": last_err}]), [], {})
    envs = data.get("value", [])
    scopes, urls, index = [], [], {}
    for env in envs:
        props = env.get("properties", {})
        meta = props.get("linkedEnvironmentMetadata", {}) or {}
        url = (meta.get("instanceUrl") or "").rstrip("/")
        name = props.get("displayName", env.get("name", "?"))
        env_id = env.get("name", "")
        scopes.append({
            "kind": "powerplatform_env", "id": env_id, "name": name,
            "dataverse_url": url,
            "env_type": props.get("environmentSku", props.get("environmentType", "")),
            "region": props.get("azureRegion", ""),
            "status": "read" if url else "no_dataverse",
        })
        if url:
            urls.append(url)
            index[url] = {"id": env_id, "name": name,
                          "tenant_id": (props.get("tenantId")
                                        or meta.get("tenantId", "")),
                          # the DEFAULT env is addressed as Default-{tenantId}
                          # in the maker portal, so the link builder must know
                          "is_default": bool(props.get("isDefault"))
                          or "default" in str(name).lower()}
    return report([], scopes, []), urls, index

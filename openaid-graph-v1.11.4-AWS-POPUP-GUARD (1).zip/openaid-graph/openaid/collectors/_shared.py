"""Shared plumbing for the v0.2 collectors.

Same contract as the v0.1.1 patch: descriptors are built in one place, using
the repo's ``openaid.model`` helpers when importable and a plain dict when
not, so these files drop into the existing tree without editing it.

New in v0.2: every descriptor may carry ``links`` — a list of edges that the
trust graph consumes. A link is::

    {"rel": "<relation>", "target": "<descriptor id, endpoint URL, or name>"}

Relations the graph understands: ``invokes``, ``uses_connector``,
``calls_mcp``, ``reads``, ``writes``, ``authenticates_as``.
Unknown relations are kept and drawn, just not scored.
"""
from __future__ import annotations

import hashlib
from typing import Any, Callable, Iterable


def _stable_id(platform: str, *parts: str) -> str:
    h = hashlib.sha256(("|".join([platform, *parts])).encode()).hexdigest()[:16]
    return f"oaid:{platform}:{h}"


def build_descriptor(
    *,
    platform: str,
    agent_type: str,
    name: str,
    native_id: str,
    scope: dict | None = None,
    identity: dict | None = None,
    entitlements: list | None = None,
    endpoints: list | None = None,
    links: list | None = None,
    raw: dict | None = None,
    risk_hints: dict | None = None,
) -> dict:
    """Build a descriptor the existing validator accepts.

    Tries ``openaid.model.new_descriptor`` first; falls back to the documented
    dict shape. Either way the result carries the same keys.
    """
    doc = {
        "id": _stable_id(platform, native_id),
        "name": name,
        "agent": {"platform": platform, "agent_type": agent_type, "native_id": native_id},
        "scope": scope or {},
        "identity": identity or {},
        "entitlements": list(entitlements or []),
        "endpoints": list(endpoints or []),
        "links": list(links or []),
        "risk_hints": risk_hints or {},
        "source": {"collector": platform, "spec": "openaid-v0.2"},
    }
    if raw is not None:
        doc["raw_excerpt"] = {k: raw[k] for k in list(raw)[:12]}
    try:  # pragma: no cover - only fires inside the full repo
        from openaid import model  # type: ignore

        if hasattr(model, "new_descriptor"):
            return model.new_descriptor(**doc)
    except Exception:
        pass
    return doc


def report(descriptors: Iterable[dict], scopes: Iterable[dict] = (), errors: Iterable[dict] = ()) -> dict:
    """CollectionReport shape shared with the existing collectors."""
    return {
        "descriptors": list(descriptors),
        "scopes": list(scopes),
        "errors": list(errors),
    }


def skip(scope_kind: str, reason: str) -> dict:
    """A collector that is not configured must say so, loudly and structurally.

    An empty result and an unconfigured collector must never look the same —
    that is the /api/coverage rule from v0.1 and it holds here.
    """
    return report(
        [],
        scopes=[{"kind": scope_kind, "status": "skipped", "reason": reason}],
    )


FetchFn = Callable[..., Any]


def http_json(fetch: FetchFn, method: str, url: str, **kw) -> Any:
    """Uniform fetch wrapper so every collector is testable with a fake."""
    return fetch(method=method, url=url, **kw)

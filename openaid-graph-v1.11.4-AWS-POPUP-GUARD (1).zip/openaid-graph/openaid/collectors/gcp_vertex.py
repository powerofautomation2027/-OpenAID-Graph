"""GCP collector: Vertex AI Agent Builder engines + Reasoning Engines.

Completes the big-3 story. Two surfaces:

* Discovery Engine API — ``projects/*/locations/*/collections/*/engines``
  (Agent Builder / Agentspace agents)
* Vertex AI API — ``projects/*/locations/*/reasoningEngines``
  (LangChain/ADK agents deployed as managed runtimes)

Auth: caller passes a bearer token (ADC or SA) via ``token``; the collector
never mints credentials itself, same rule as the Azure/AWS collectors.

Config env vars: OPENAID_GCP_PROJECTS (comma list), OPENAID_GCP_LOCATIONS
(default ``global,us-central1``).
"""
from __future__ import annotations

import os

from ._shared import build_descriptor, http_json, report, skip

DISCOVERY = "https://discoveryengine.googleapis.com/v1"
VERTEX = "https://{loc}-aiplatform.googleapis.com/v1"


def _sa_links(engine: dict) -> list:
    links = []
    sa = engine.get("commonConfig", {}).get("serviceAccount") or engine.get("serviceAccount")
    if sa:
        links.append({"rel": "authenticates_as", "target": sa})
    for ds in engine.get("dataStoreIds", []) or []:
        links.append({"rel": "reads", "target": f"gcp:datastore:{ds}"})
    return links


def collect(fetch, token: str | None = None, projects: list[str] | None = None, locations: list[str] | None = None) -> dict:
    projects = projects or [p for p in os.getenv("OPENAID_GCP_PROJECTS", "").split(",") if p]
    if not projects:
        return skip("gcp_project", "OPENAID_GCP_PROJECTS not set")
    locations = locations or os.getenv("OPENAID_GCP_LOCATIONS", "global,us-central1").split(",")
    hdr = {"Authorization": f"Bearer {token}"} if token else {}
    docs, scopes, errors = [], [], []
    for proj in projects:
        found = 0
        for loc in locations:
            base = f"{DISCOVERY}/projects/{proj}/locations/{loc}/collections/default_collection/engines"
            try:
                data = http_json(fetch, "GET", base, headers=hdr) or {}
                for eng in data.get("engines", []):
                    found += 1
                    docs.append(build_descriptor(
                        platform="gcp_vertex",
                        agent_type="agent_builder_gcp",
                        name=eng.get("displayName", eng.get("name", "?")),
                        native_id=eng.get("name", ""),
                        scope={"kind": "gcp_project", "project": proj, "location": loc},
                        identity={"kind": "service_account",
                                  "principal": eng.get("commonConfig", {}).get("serviceAccount", "")},
                        links=_sa_links(eng),
                        raw=eng,
                    ))
            except Exception as e:  # noqa: BLE001 - surfaced, not swallowed
                errors.append({"scope": f"{proj}/{loc}", "surface": "discoveryengine", "error": str(e)})
            try:
                vurl = VERTEX.format(loc=loc) + f"/projects/{proj}/locations/{loc}/reasoningEngines"
                data = http_json(fetch, "GET", vurl, headers=hdr) or {}
                for re_ in data.get("reasoningEngines", []):
                    found += 1
                    docs.append(build_descriptor(
                        platform="gcp_vertex",
                        agent_type="reasoning_engine",
                        name=re_.get("displayName", re_.get("name", "?")),
                        native_id=re_.get("name", ""),
                        scope={"kind": "gcp_project", "project": proj, "location": loc},
                        identity={"kind": "service_account", "principal": re_.get("serviceAccount", "")},
                        links=[{"rel": "authenticates_as", "target": re_["serviceAccount"]}] if re_.get("serviceAccount") else [],
                        raw=re_,
                    ))
            except Exception as e:  # noqa: BLE001
                errors.append({"scope": f"{proj}/{loc}", "surface": "vertex", "error": str(e)})
        scopes.append({"kind": "gcp_project", "id": proj, "status": "read", "agents": found})
    return report(docs, scopes, errors)

"""Cisco Webex collector — bots and AI Agent Studio agents.

Control Hub has bot identities (machine accounts with API tokens that can read
rooms and post as themselves) that no identity inventory touches. First of its
kind, and cheap: two Webex REST calls.

* ``/v1/people?type=bot`` (org-level, needs admin scope) — bot accounts
* ``/v1/applications``   — integrations with OAuth scopes (edge material)

Config: token from caller (Webex admin token / service app). No env needed —
token presence is the switch.
"""
from __future__ import annotations

from ._shared import build_descriptor, http_json, report, skip

API = "https://webexapis.com/v1"


def collect(fetch, token: str | None = None) -> dict:
    if not token:
        return skip("webex_org", "no Webex token supplied")
    hdr = {"Authorization": f"Bearer {token}"}
    docs, errors = [], []
    try:
        people = (http_json(fetch, "GET", f"{API}/people?type=bot&max=1000", headers=hdr) or {}).get("items", [])
    except Exception as e:  # noqa: BLE001
        return report([], [{"kind": "webex_org", "status": "error"}], [{"scope": "webex", "error": str(e)}])
    apps = []
    try:
        apps = (http_json(fetch, "GET", f"{API}/applications", headers=hdr) or {}).get("items", [])
    except Exception as e:  # noqa: BLE001
        errors.append({"scope": "webex", "surface": "applications", "error": str(e)})
    scopes_by_app = {a.get("friendlyName", a.get("id", "?")): a.get("scopes", []) for a in apps}

    for p in people:
        ents = [{"resource": "webex:rooms", "actions": ["read", "post"],
                 "note": "bot token can read joined rooms and post as bot"}]
        docs.append(build_descriptor(
            platform="webex",
            agent_type="webex_bot",
            name=p.get("displayName", "?"),
            native_id=p.get("id", ""),
            scope={"kind": "webex_org", "org": p.get("orgId", "")},
            identity={"kind": "bot_account", "principal": (p.get("emails") or [""])[0]},
            entitlements=ents,
            links=[{"rel": "reads", "target": "webex:rooms"}],
            raw=p,
        ))
    for name, scp in scopes_by_app.items():
        docs.append(build_descriptor(
            platform="webex",
            agent_type="webex_integration",
            name=name,
            native_id=f"app:{name}",
            scope={"kind": "webex_org"},
            identity={"kind": "oauth_integration"},
            entitlements=[{"resource": "webex:api", "actions": scp}],
            raw={"scopes": scp},
        ))
    return report(docs, [{"kind": "webex_org", "status": "read", "agents": len(docs)}], errors)

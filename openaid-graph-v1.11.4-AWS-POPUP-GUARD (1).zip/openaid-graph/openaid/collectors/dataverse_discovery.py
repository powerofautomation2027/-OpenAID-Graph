"""Dataverse Global Discovery Service — lists every environment the signed-in
user can access, without needing Power Platform admin rights.

    GET https://globaldisco.crm.dynamics.com/api/discovery/v2.0/Instances
        ?$select=ApiUrl,FriendlyName,UrlName

This is the reliable way to enumerate Copilot Studio environments: BAP admin
403s for non-admins, but Global Discovery returns any org the user belongs to.
The ApiUrl it returns is the Web API base used to query the ``bot`` table.

Token audience: https://globaldisco.crm.dynamics.com/ — covered by the Dynamics
CRM (Dataverse) delegated permission.
"""
from __future__ import annotations

from ._shared import http_json, report, skip

GDS = ("https://globaldisco.crm.dynamics.com/api/discovery/v2.0/Instances"
       "?$select=ApiUrl,FriendlyName,UrlName,Id")


def collect(fetch, token: str | None = None):
    """Returns (report, dataverse_urls, env_index)."""
    if not token:
        return skip("dataverse_discovery", "no discovery token"), [], {}
    hdr = {"Authorization": f"Bearer {token}", "Accept": "application/json",
           "OData-MaxVersion": "4.0", "OData-Version": "4.0"}
    try:
        data = http_json(fetch, "GET", GDS, headers=hdr) or {}
    except Exception as e:  # noqa: BLE001
        return (report([], [{"kind": "dataverse_discovery", "status": "error"}],
                       [{"scope": "globaldisco", "error": str(e)}]), [], {})
    scopes, urls, index = [], [], {}
    for inst in data.get("value", []):
        api = (inst.get("ApiUrl") or "").rstrip("/")
        name = inst.get("FriendlyName", inst.get("UrlName", "?"))
        if not api:
            continue
        urls.append(api)
        index[api] = {"id": inst.get("Id", ""), "name": name}
        scopes.append({"kind": "powerplatform_env", "id": inst.get("Id", ""),
                       "name": name, "dataverse_url": api, "status": "read"})
    return report([], scopes, []), urls, index

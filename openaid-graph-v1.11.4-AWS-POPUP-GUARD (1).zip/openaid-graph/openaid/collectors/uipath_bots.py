"""UiPath collector — RPA robots as governed machine identities.

The thesis: an unattended robot with a stored Windows credential and access to
ERP screens is exactly the same governance problem as a Bedrock agent with an
IAM role. Nobody puts them in one inventory. OpenAID does.

Orchestrator OData surfaces:

* ``/odata/Robots``            — robot identities + type (Unattended, etc.)
* ``/odata/Assets``            — credential assets robots can read
* ``/odata/Releases``          — processes a robot runs (edge material)

Config: OPENAID_UIPATH_URL (``https://cloud.uipath.com/{org}/{tenant}/orchestrator_``),
bearer token from caller.
"""
from __future__ import annotations

import os

from ._shared import build_descriptor, http_json, report, skip


def _odata(fetch, base, hdr, entity):
    return (http_json(fetch, "GET", f"{base}/odata/{entity}", headers=hdr) or {}).get("value", [])


def collect(fetch, token: str | None = None, base_url: str | None = None) -> dict:
    base = (base_url or os.getenv("OPENAID_UIPATH_URL", "")).rstrip("/")
    if not base:
        return skip("uipath_tenant", "OPENAID_UIPATH_URL not set")
    hdr = {"Authorization": f"Bearer {token}"}
    docs, errors = [], []
    try:
        robots = _odata(fetch, base, hdr, "Robots")
    except Exception as e:  # noqa: BLE001
        return report([], [{"kind": "uipath_tenant", "id": base, "status": "error"}],
                      [{"scope": base, "error": str(e)}])
    cred_assets = []
    try:
        cred_assets = [a for a in _odata(fetch, base, hdr, "Assets")
                       if (a.get("ValueType") or "").lower() == "credential"]
    except Exception as e:  # noqa: BLE001
        errors.append({"scope": base, "surface": "Assets", "error": str(e)})
    releases = []
    try:
        releases = _odata(fetch, base, hdr, "Releases")
    except Exception as e:  # noqa: BLE001
        errors.append({"scope": base, "surface": "Releases", "error": str(e)})

    for r in robots:
        unattended = (r.get("Type") or "") in ("Unattended", "NonProduction")
        links = [{"rel": "invokes", "target": f"uipath:process:{rel.get('ProcessKey', rel.get('Name', '?'))}"}
                 for rel in releases]
        ents = [{"resource": f"uipath:asset:{a.get('Name')}", "actions": ["read"],
                 "note": "stored credential asset"} for a in cred_assets]
        if r.get("Username"):
            links.append({"rel": "authenticates_as", "target": f"windows:user:{r['Username']}"})
        docs.append(build_descriptor(
            platform="uipath",
            agent_type="rpa_robot",
            name=r.get("Name", "?"),
            native_id=str(r.get("Id", r.get("Name", "?"))),
            scope={"kind": "uipath_tenant", "instance": base},
            identity={"kind": "machine_account", "principal": r.get("Username", ""),
                      "machine": r.get("MachineName", "")},
            entitlements=ents,
            links=links,
            risk_hints={"unattended": unattended, "credential_assets": len(cred_assets)},
            raw=r,
        ))
    return report(docs, [{"kind": "uipath_tenant", "id": base, "status": "read", "agents": len(docs)}], errors)

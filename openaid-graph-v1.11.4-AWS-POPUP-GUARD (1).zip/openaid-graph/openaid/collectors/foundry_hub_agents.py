"""Hub-based Azure AI Foundry projects — legacy AML agents route.

Docs are explicit: projects created INSIDE A HUB cannot be read through
{account}.services.ai.azure.com/api/projects/... — those calls return
"Project not found". Hub projects expose agents on the legacy Azure ML
data plane instead:

    https://{region}.api.azureml.ms/agents/v1.0
        /subscriptions/{sub}/resourceGroups/{rg}
        /providers/Microsoft.MachineLearningServices/workspaces/{project}
        /assistants?api-version=2024-12-01-preview

Token audience: https://ml.azure.com (NOT ai.azure.com).

This collector: ARM-lists every Microsoft.MachineLearningServices
workspace (hubs have kind=Hub, projects kind=Project), then sweeps the
legacy route per project workspace.
"""
from __future__ import annotations

from ._shared import _stable_id, build_descriptor, http_json, report, skip

ARM = "https://management.azure.com"
WS_API = "2024-10-01"
LEGACY_VERSIONS = ("2024-12-01-preview", "2025-05-01", "v1")


def _workspaces(fetch, arm_token, sid):
    url = (f"{ARM}/subscriptions/{sid}/providers/"
           f"Microsoft.MachineLearningServices/workspaces?api-version={WS_API}")
    hdr = {"Authorization": f"Bearer {arm_token}"}
    out = []
    while url:
        j = http_json(fetch, "GET", url, headers=hdr) or {}
        out.extend(j.get("value", []))
        url = j.get("nextLink")
    return out


def collect(fetch, arm_token: str | None = None, ml_token: str | None = None,
            subscription_ids: list[str] | None = None,
            sub_names: dict | None = None) -> dict:
    if not (arm_token and ml_token):
        return skip("foundry_hub", "no ARM/ML token for hub-based projects")
    if not subscription_ids:
        return skip("foundry_hub", "no subscriptions")
    sub_names = sub_names or {}
    hdr = {"Authorization": f"Bearer {ml_token}"}
    docs, scopes, errors = [], [], []
    for sid in subscription_ids:
        try:
            wss = _workspaces(fetch, arm_token, sid)
        except Exception as e:  # noqa: BLE001
            errors.append({"scope": sid, "surface": "ml_workspaces", "error": str(e)[:200]})
            continue
        for ws in wss:
            kind = (ws.get("kind") or "").lower()
            if kind == "hub":
                continue  # hubs hold projects; agents live on the projects
            name = ws.get("name", "")
            loc = (ws.get("location") or "eastus").lower().replace(" ", "")
            ws_id = ws.get("id", "")
            base = f"https://{loc}.api.azureml.ms/agents/v1.0{ws_id}"
            agents = None
            for ver in LEGACY_VERSIONS:
                try:
                    j = http_json(fetch, "GET",
                                  f"{base}/assistants?api-version={ver}",
                                  headers=hdr) or {}
                except Exception:
                    continue
                agents = j.get("data", j.get("value", [])) or []
                break
            if agents is None:
                scopes.append({"kind": "foundry_hub_project", "id": name,
                               "subscription": sid, "status": "error"})
                continue
            for a in agents:
                aid = str(a.get("id") or a.get("name") or "")
                docs.append(build_descriptor(
                    platform="azure_foundry",
                    agent_type="foundry_hub_agent",
                    name=a.get("name") or aid,
                    native_id=aid,
                    scope={"kind": "foundry_hub_project", "endpoint": base,
                           "project": name, "subscription": sid,
                           "subscription_name": sub_names.get(sid, sid),
                           "portal_url": f"https://ai.azure.com/build/overview?wsid={ws_id}"},
                    identity={"kind": "foundry_agent_identity"},
                    entitlements=[{"resource": f"foundry:model:{a.get('model', '?')}",
                                   "actions": ["invoke"]}],
                    links=[],
                    risk_hints={"model": a.get("model", ""), "hub_based": True,
                                "portal_url": f"https://ai.azure.com/build/overview?wsid={ws_id}"},
                    raw={"id": aid, "model": a.get("model", "")},
                ))
            scopes.append({"kind": "foundry_hub_project", "id": name,
                           "subscription": sid, "status": "read",
                           "agents": len(agents)})
    return report(docs, scopes, errors)

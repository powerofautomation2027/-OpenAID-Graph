"""Third-party agent collectors.

Signing in to a connector only earns its place if data actually flows. Each
function here takes the token the operator connected with and returns OpenAID
descriptors, so a connected platform's agents land in the same inventory,
graph, trifecta audit, sprawl scan and reports as the Microsoft ones.

Every collector is defensive: a dead endpoint, a scope-limited token or a
changed payload shape returns an empty list and an error entry — it never
takes the whole discovery run down with it.
"""
from __future__ import annotations

from ._shared import build_descriptor, http_json, report, skip


def _bearer(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


# --------------------------------------------------------------------------
def openai_assistants(fetch, token: str) -> tuple[list, list]:
    """GET https://api.openai.com/v1/assistants (Assistants v2)."""
    docs, errors = [], []
    try:
        j = http_json(fetch, "GET", "https://api.openai.com/v1/assistants?limit=100",
                      headers={**_bearer(token), "OpenAI-Beta": "assistants=v2"}) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "openai", "error": str(e)[:200]}]
    for a in j.get("data", []) or []:
        tools = [t.get("type", "") for t in (a.get("tools") or [])]
        docs.append(build_descriptor(
            platform="openai", agent_type="openai_assistant",
            name=a.get("name") or a.get("id", "?"), native_id=a.get("id", ""),
            scope={"kind": "openai_account", "environment": "openai",
                   "portal_url": "https://platform.openai.com/assistants"},
            identity={"kind": "openai_api_key", "auth": "api_key"},
            entitlements=[{"resource": f"openai:tool:{t}", "actions": ["invoke"]}
                          for t in tools],
            endpoints=[], links=[],
            risk_hints={"model": a.get("model", ""), "tools": ",".join(tools),
                        "has_file_search": "file_search" in tools},
            raw={"id": a.get("id", "")}))
    return docs, errors


def slack_bots(fetch, token: str) -> tuple[list, list]:
    """GET https://slack.com/api/users.list — bot users are agents in Slack."""
    try:
        j = http_json(fetch, "GET", "https://slack.com/api/users.list?limit=200",
                      headers=_bearer(token)) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "slack", "error": str(e)[:200]}]
    if not j.get("ok", True):
        return [], [{"scope": "slack", "error": j.get("error", "slack api error")}]
    docs = []
    for m in j.get("members", []) or []:
        if not m.get("is_bot") or m.get("deleted"):
            continue
        prof = m.get("profile", {}) or {}
        docs.append(build_descriptor(
            platform="slack", agent_type="slack_bot",
            name=prof.get("real_name") or m.get("name", "?"),
            native_id=m.get("id", ""),
            scope={"kind": "slack_workspace", "environment": m.get("team_id", "slack"),
                   "portal_url": "https://app.slack.com/manage/apps"},
            identity={"kind": "slack_bot_user", "principal": m.get("id", ""),
                      "auth": "oauth"},
            entitlements=[{"resource": "slack:workspace", "actions": ["read", "post"]}],
            endpoints=[], links=[],
            risk_hints={"is_admin": bool(m.get("is_admin")),
                        "app_id": prof.get("api_app_id", "")},
            raw={"id": m.get("id", "")}))
    return docs, []


def github_apps(fetch, token: str) -> tuple[list, list]:
    """GET /user/installations — installed GitHub Apps act as autonomous agents."""
    try:
        j = http_json(fetch, "GET", "https://api.github.com/user/installations",
                      headers={**_bearer(token),
                               "Accept": "application/vnd.github+json"}) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "github", "error": str(e)[:200]}]
    docs = []
    for i in j.get("installations", []) or []:
        perms = i.get("permissions", {}) or {}
        writes = [k for k, v in perms.items() if v == "write"]
        docs.append(build_descriptor(
            platform="github", agent_type="github_app",
            name=(i.get("app_slug") or "app"), native_id=str(i.get("id", "")),
            scope={"kind": "github_org",
                   "environment": (i.get("account", {}) or {}).get("login", "github"),
                   "portal_url": i.get("html_url",
                                       "https://github.com/settings/installations")},
            identity={"kind": "github_app_installation", "auth": "app_token"},
            entitlements=[{"resource": f"github:{k}", "actions": [v]}
                          for k, v in perms.items()],
            endpoints=[], links=[],
            risk_hints={"write_scopes": len(writes),
                        "repository_selection": i.get("repository_selection", "")},
            raw={"id": i.get("id", "")}))
    return docs, []


def servicenow_agents(fetch, token: str, base_url: str) -> tuple[list, list]:
    """GET /api/now/table/sn_aia_agent — Now Assist AI agents."""
    if not base_url:
        return [], [{"scope": "servicenow", "error": "instance URL required"}]
    url = (f"{base_url.rstrip('/')}/api/now/table/sn_aia_agent"
           "?sysparm_limit=200&sysparm_display_value=true")
    try:
        j = http_json(fetch, "GET", url, headers=_bearer(token)) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "servicenow", "error": str(e)[:200]}]
    docs = []
    for a in j.get("result", []) or []:
        docs.append(build_descriptor(
            platform="servicenow", agent_type="now_assist_agent",
            name=a.get("name", "?"), native_id=a.get("sys_id", ""),
            scope={"kind": "servicenow_instance", "environment": base_url,
                   "portal_url": f"{base_url.rstrip('/')}/now/aiagentstudio/home"},
            identity={"kind": "servicenow_agent", "auth": "oauth"},
            entitlements=[{"resource": "servicenow:tables", "actions": ["read", "write"]}],
            endpoints=[], links=[],
            risk_hints={"active": a.get("active", ""), "role": a.get("role", "")},
            raw={"sys_id": a.get("sys_id", "")}))
    return docs, []


def salesforce_agents(fetch, token: str, base_url: str) -> tuple[list, list]:
    """SOQL over BotDefinition — Agentforce / Einstein bots."""
    if not base_url:
        return [], [{"scope": "salesforce", "error": "instance URL required"}]
    q = "SELECT Id,DeveloperName,MasterLabel,Type FROM BotDefinition LIMIT 200"
    url = f"{base_url.rstrip('/')}/services/data/v60.0/query?q={q.replace(' ', '+')}"
    try:
        j = http_json(fetch, "GET", url, headers=_bearer(token)) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "salesforce", "error": str(e)[:200]}]
    docs = []
    for r in j.get("records", []) or []:
        docs.append(build_descriptor(
            platform="salesforce", agent_type="agentforce_bot",
            name=r.get("MasterLabel") or r.get("DeveloperName", "?"),
            native_id=r.get("Id", ""),
            scope={"kind": "salesforce_org", "environment": base_url,
                   "portal_url": f"{base_url.rstrip('/')}/lightning/setup/EinsteinBots/home"},
            identity={"kind": "salesforce_bot", "auth": "oauth"},
            entitlements=[{"resource": "salesforce:objects", "actions": ["read", "write"]}],
            endpoints=[], links=[],
            risk_hints={"bot_type": r.get("Type", "")},
            raw={"id": r.get("Id", "")}))
    return docs, []


def uipath_robots(fetch, token: str, base_url: str) -> tuple[list, list]:
    """GET /odata/Releases — deployed automations acting unattended."""
    if not base_url:
        return [], [{"scope": "uipath", "error": "Orchestrator URL required"}]
    url = f"{base_url.rstrip('/')}/odata/Releases?$top=200"
    try:
        j = http_json(fetch, "GET", url, headers=_bearer(token)) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "uipath", "error": str(e)[:200]}]
    docs = []
    for r in j.get("value", []) or []:
        docs.append(build_descriptor(
            platform="uipath", agent_type="uipath_process",
            name=r.get("Name", "?"), native_id=str(r.get("Id", "")),
            scope={"kind": "uipath_orchestrator", "environment": base_url,
                   "portal_url": f"{base_url.rstrip('/')}/processes"},
            identity={"kind": "uipath_robot", "auth": "oauth"},
            entitlements=[{"resource": "uipath:process", "actions": ["execute"]}],
            endpoints=[], links=[],
            risk_hints={"unattended": True,
                        "process_key": r.get("ProcessKey", "")},
            raw={"id": r.get("Id", "")}))
    return docs, []


def vertex_reasoning_engines(fetch, token: str, project: str,
                             location: str = "us-central1") -> tuple[list, list]:
    """GET .../reasoningEngines — Vertex AI Agent Engine deployments."""
    if not project:
        return [], [{"scope": "gcp", "error": "project id required"}]
    url = (f"https://{location}-aiplatform.googleapis.com/v1/projects/"
           f"{project}/locations/{location}/reasoningEngines")
    try:
        j = http_json(fetch, "GET", url, headers=_bearer(token)) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "gcp", "error": str(e)[:200]}]
    docs = []
    for r in j.get("reasoningEngines", []) or []:
        rid = str(r.get("name", "")).rsplit("/", 1)[-1]
        docs.append(build_descriptor(
            platform="gcp_vertex", agent_type="vertex_agent_engine",
            name=r.get("displayName") or rid, native_id=rid,
            scope={"kind": "gcp_project", "environment": f"gcp:{project}",
                   "project": project,
                   "portal_url": ("https://console.cloud.google.com/vertex-ai/"
                                  f"agents?project={project}")},
            identity={"kind": "gcp_service_account", "auth": "oauth"},
            entitlements=[{"resource": f"gcp:project:{project}", "actions": ["invoke"]}],
            endpoints=[], links=[],
            risk_hints={"location": location},
            raw={"name": r.get("name", "")}))
    return docs, []


def zendesk_agents(fetch, token: str, base_url: str) -> tuple[list, list]:
    """GET /api/v2/custom_objects... Zendesk AI agents surface as bot users."""
    if not base_url:
        return [], [{"scope": "zendesk", "error": "subdomain URL required"}]
    url = f"{base_url.rstrip('/')}/api/v2/users.json?role=agent&per_page=100"
    try:
        j = http_json(fetch, "GET", url, headers=_bearer(token)) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "zendesk", "error": str(e)[:200]}]
    docs = []
    for u in j.get("users", []) or []:
        if not (u.get("role") == "agent" and u.get("active")):
            continue
        docs.append(build_descriptor(
            platform="zendesk", agent_type="zendesk_agent",
            name=u.get("name", "?"), native_id=str(u.get("id", "")),
            scope={"kind": "zendesk_instance", "environment": base_url,
                   "portal_url": f"{base_url.rstrip('/')}/admin/people/team/members"},
            identity={"kind": "zendesk_user", "auth": "api_token"},
            entitlements=[{"resource": "zendesk:tickets", "actions": ["read", "write"]}],
            endpoints=[], links=[],
            risk_hints={"suspended": bool(u.get("suspended"))},
            raw={"id": u.get("id", "")}))
    return docs, []


AWS_XRAY: list = []   # per-run trace of every AWS surface attempt


def _aws_auth_headers(method, url, token, region, service, body=b""):
    """Bearer for Bedrock API keys; SigV4 when ACCESS:SECRET[:SESSION]."""
    from .aws_sigv4 import parse_credentials, sigv4_headers
    creds = parse_credentials(token)
    if creds:
        ak, sk, st = creds
        return sigv4_headers(method, url, service=service, region=region,
                             access_key=ak, secret_key=sk, session_token=st,
                             body=body), "sigv4"
    return _bearer(token), "bearer"


def bedrock_agents(fetch, token: str, region: str = "us-east-1") -> tuple[list, list]:
    """AWS agents across BOTH surfaces:

      1. CLASSIC Bedrock Agents      GET  bedrock-agent.{r}/agents
      2. AgentCore runtimes          POST bedrock-agentcore-control.{r}/runtimes/
         (every console "Harness" is backed by one of these runtimes)

    Auth: a Bedrock API key covers the classic surface only; paste
    ACCESS_KEY_ID:SECRET_ACCESS_KEY[:SESSION] for SigV4, which both
    surfaces accept. Every attempt is traced into AWS_XRAY."""
    region = (region or "us-east-1").strip() or "us-east-1"
    AWS_XRAY.clear()
    docs, errors = [], []

    # ---- 1. classic Bedrock Agents ----
    url = f"https://bedrock-agent.{region}.amazonaws.com/agents/"
    hdr, mode = _aws_auth_headers("GET", url, token, region, "bedrock")
    try:
        j = http_json(fetch, "GET", url, headers=hdr) or {}
        rows = j.get("agentSummaries", j.get("agents", [])) or []
        AWS_XRAY.append({"surface": "bedrock-agent /agents", "auth": mode,
                         "result": f"OK: {len(rows)} agent(s)"})
        for a in rows:
            aid = a.get("agentId", "")
            docs.append(build_descriptor(
                platform="aws_bedrock", agent_type="bedrock_agent",
                name=a.get("agentName") or aid, native_id=aid,
                scope={"kind": "aws_region", "environment": f"aws:{region}",
                       "region": region,
                       "portal_url": (f"https://{region}.console.aws.amazon.com/bedrock/"
                                      f"home?region={region}#/agents/{aid}")},
                identity={"kind": "aws_iam_role", "auth": mode},
                entitlements=[{"resource": f"aws:bedrock:{region}", "actions": ["invoke"]}],
                endpoints=[], links=[],
                risk_hints={"status": a.get("agentStatus", ""),
                            "model": a.get("foundationModel", ""),
                            "updated": a.get("updatedAt", "")},
                raw={"agentId": aid}))
    except Exception as e:  # noqa: BLE001
        AWS_XRAY.append({"surface": "bedrock-agent /agents", "auth": mode,
                         "result": f"ERROR: {str(e)[:160]}"})
        errors.append({"scope": "aws:bedrock-agent", "error": str(e)[:200]})

    # ---- 2. AgentCore runtimes (Harness-backed agents) ----
    url = f"https://bedrock-agentcore-control.{region}.amazonaws.com/runtimes/?maxResults=100"
    hdr, mode = _aws_auth_headers("POST", url, token, region, "bedrock-agentcore")
    try:
        j = http_json(fetch, "POST", url, headers=hdr) or {}
        rows = j.get("agentRuntimes", []) or []
        AWS_XRAY.append({"surface": "bedrock-agentcore-control /runtimes", "auth": mode,
                         "result": f"OK: {len(rows)} runtime(s)"})
        for r in rows:
            rid = r.get("agentRuntimeId", "") or r.get("id", "")
            rname = r.get("agentRuntimeName", "") or rid
            # console "Harness" name = runtime name without the harness_ prefix
            display = rname[len("harness_"):] if rname.startswith("harness_") else rname
            docs.append(build_descriptor(
                platform="aws_bedrock", agent_type="agentcore_runtime",
                name=display, native_id=rid,
                scope={"kind": "aws_region", "environment": f"aws:{region}",
                       "region": region,
                       "portal_url": (f"https://{region}.console.aws.amazon.com/"
                                      f"bedrock-agentcore/runtimes/{rid}"),
                       "portal_candidates": [
                           f"https://{region}.console.aws.amazon.com/bedrock-agentcore/runtimes/{rid}",
                           f"https://{region}.console.aws.amazon.com/bedrock-agentcore/harnesses",
                       ]},
                identity={"kind": "aws_iam_role", "auth": mode,
                          "role": (r.get("roleArn", "") or "")[:120]},
                entitlements=[{"resource": f"aws:bedrock-agentcore:{region}",
                               "actions": ["invoke"]}],
                endpoints=[], links=[],
                risk_hints={"status": r.get("status", ""),
                            "arn": r.get("agentRuntimeArn", ""),
                            "updated": str(r.get("lastUpdatedAt", ""))},
                raw={"agentRuntimeId": rid}))
    except Exception as e:  # noqa: BLE001
        AWS_XRAY.append({"surface": "bedrock-agentcore-control /runtimes", "auth": mode,
                         "result": f"ERROR: {str(e)[:160]}"})
        errors.append({"scope": "aws:agentcore", "error": str(e)[:200]})

    return docs, errors


def n8n_workflows(fetch, token: str, base_url: str = "") -> tuple[list, list]:
    """n8n — the community's favorite self-hosted agent-workflow platform.
    GET {base}/api/v1/workflows (X-N8N-API-KEY). Workflows carrying
    LangChain/agent nodes are tagged as AI agents; the rest are listed as
    automations so the inventory shows the whole surface."""
    base = (base_url or "").rstrip("/")
    if not base:
        return [], [{"scope": "n8n", "error": "n8n base URL required (e.g. https://n8n.example.com)"}]
    hdr = {"X-N8N-API-KEY": token, "Accept": "application/json"}
    try:
        j = http_json(fetch, "GET", f"{base}/api/v1/workflows?limit=100",
                      headers=hdr) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "n8n", "error": str(e)[:200]}]
    docs = []
    for w in j.get("data", []) or []:
        wid = str(w.get("id", ""))
        nodes = w.get("nodes") or []
        node_types = [str(n.get("type", "")) for n in nodes]
        is_ai = any("langchain" in t.lower() or ".agent" in t.lower()
                    or "openai" in t.lower() or "anthropic" in t.lower()
                    for t in node_types)
        docs.append(build_descriptor(
            platform="n8n",
            agent_type="n8n_ai_agent" if is_ai else "n8n_workflow",
            name=w.get("name") or wid, native_id=wid,
            scope={"kind": "n8n_instance", "environment": base,
                   "portal_url": f"{base}/workflow/{wid}"},
            identity={"kind": "n8n_api_key", "auth": "api_key"},
            entitlements=[{"resource": "n8n:workflow", "actions": ["execute"]}],
            endpoints=[], links=[],
            risk_hints={"active": bool(w.get("active")),
                        "ai_nodes": sum(1 for t in node_types
                                        if "langchain" in t.lower()),
                        "updated": str(w.get("updatedAt", ""))},
            raw={"id": wid}))
    return docs, []


def anthropic_agents(fetch, token: str) -> tuple[list, list]:
    """Anthropic workspaces — Claude API keys are scoped per workspace, so each
    workspace is the unit of agent access worth inventorying."""
    hdr = {"x-api-key": token, "anthropic-version": "2023-06-01"}
    try:
        j = http_json(fetch, "GET",
                      "https://api.anthropic.com/v1/organizations/workspaces?limit=100",
                      headers=hdr) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "anthropic", "error": str(e)[:200]}]
    docs = []
    for w in j.get("data", []) or []:
        wid = w.get("id", "")
        docs.append(build_descriptor(
            platform="anthropic", agent_type="claude_workspace",
            name=w.get("name") or wid, native_id=wid,
            scope={"kind": "anthropic_workspace", "environment": "anthropic",
                   "portal_url": "https://console.anthropic.com/settings/workspaces"},
            identity={"kind": "anthropic_api_key", "auth": "api_key"},
            entitlements=[{"resource": "anthropic:models", "actions": ["invoke"]}],
            endpoints=[], links=[],
            risk_hints={"archived": bool(w.get("archived_at"))},
            raw={"id": wid}))
    return docs, []


# --------------------------------------------------------------------------
# registry: connector id -> (callable, needs_url)
COLLECTORS = {
    "openai": (openai_assistants, False),
    "n8n": (n8n_workflows, True),
    "slack": (slack_bots, False),
    "github": (github_apps, False),
    "servicenow": (servicenow_agents, True),
    "salesforce": (salesforce_agents, True),
    "uipath": (uipath_robots, True),
    "zendesk": (zendesk_agents, True),
    "gcp": (vertex_reasoning_engines, True),   # url field carries the project id
    "aws": (bedrock_agents, True),             # url field carries the region
    "anthropic": (anthropic_agents, False),
}


def collect(fetch, connections: dict | None = None) -> dict:
    """Run every connected third-party collector. connections maps
    platform -> {"token": ..., "url": ...}."""
    connections = connections or {}
    active = [p for p in COLLECTORS if (connections.get(p) or {}).get("token")]
    if not active:
        return skip("third_party", "no third-party connectors signed in")
    docs, scopes, errors = [], [], []
    for pid in active:
        fn, needs_url = COLLECTORS[pid]
        conn = connections[pid]
        try:
            if needs_url:
                d, e = fn(fetch, conn.get("token", ""), conn.get("url", ""))
            else:
                d, e = fn(fetch, conn.get("token", ""))
        except Exception as exc:  # noqa: BLE001
            d, e = [], [{"scope": pid, "error": str(exc)[:200]}]
        docs.extend(d)
        errors.extend(e)
        scopes.append({"kind": f"{pid}_tenant", "id": pid, "name": pid,
                       "status": "error" if e else "read", "agents": len(d)})
    return report(docs, scopes, errors)

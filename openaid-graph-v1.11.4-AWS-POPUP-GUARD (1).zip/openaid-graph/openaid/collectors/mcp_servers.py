"""MCP servers as a first-class identity class. Nobody else does this.

An MCP server is a machine identity: it holds credentials (app registration,
managed identity, API keys), exposes tools, and is invoked by agents from
multiple platforms. It deserves a descriptor, entitlements, and risk rules
exactly like an agent does.

Three discovery sources, all optional, results merged and de-duplicated by
endpoint URL:

1. **Azure Container Apps** — apps tagged ``mcp=true`` or whose ingress FQDN
   path ends in ``/mcp`` / ``/sse``. Uses the ARM list the Azure collector
   already has permission for (Reader).
2. **Bedrock AgentCore Gateway** — gateway targets of type MCP
   (``list_gateways`` / ``list_gateway_targets``); caller passes a boto3-like
   client so tests stay offline.
3. **Copilot Studio custom connectors** — connectors whose host matches a
   known MCP endpoint (the Power Platform collector already pulls
   ``connectionreference``; this re-reads the connector host list via the
   supplied fetch).

Every agent descriptor whose ``links`` contain ``calls_mcp`` gets resolved to
these nodes by endpoint URL in the trust graph — which is what turns "cross
platform pivot through a shared MCP server" into a computable finding.
"""
from __future__ import annotations

from urllib.parse import urlparse

from ._shared import build_descriptor, http_json, report

ARM = "https://management.azure.com"


def _norm(url: str) -> str:
    u = urlparse(url if "://" in url else f"https://{url}")
    return (u.netloc + u.path).rstrip("/").lower()


def _desc(name, endpoint, hosting, identity, ents=None, hints=None, raw=None):
    return build_descriptor(
        platform="mcp",
        agent_type="mcp_server",
        name=name,
        native_id=_norm(endpoint),
        scope={"kind": "mcp_endpoint", "hosting": hosting},
        identity=identity,
        entitlements=ents or [],
        endpoints=[{"url": endpoint, "protocol": "mcp"}],
        risk_hints=hints or {},
        raw=raw,
    )


def collect_azure_container_apps(fetch, token: str, subscriptions: list[str]) -> dict:
    hdr = {"Authorization": f"Bearer {token}"}
    docs, errors = [], []
    for sub in subscriptions:
        url = f"{ARM}/subscriptions/{sub}/providers/Microsoft.App/containerApps?api-version=2024-03-01"
        try:
            apps = (http_json(fetch, "GET", url, headers=hdr) or {}).get("value", [])
        except Exception as e:  # noqa: BLE001
            errors.append({"scope": sub, "error": str(e)})
            continue
        for app in apps:
            tags = {k.lower(): v for k, v in (app.get("tags") or {}).items()}
            fqdn = (app.get("properties", {}).get("configuration", {})
                    .get("ingress", {}) or {}).get("fqdn", "")
            looks_mcp = tags.get("mcp") == "true" or tags.get("openaid-mcp") == "true"
            if not (looks_mcp and fqdn):
                continue
            mi = app.get("identity", {}) or {}
            docs.append(_desc(
                app.get("name", "?"), f"https://{fqdn}/mcp", "azure_container_apps",
                {"kind": "managed_identity" if mi.get("type") else "unknown",
                 "principal": mi.get("principalId", "")},
                hints={"public_ingress": True, "auth_declared": tags.get("mcp-auth", "unknown")},
                raw={"id": app.get("id", "")},
            ))
    return report(docs, [{"kind": "mcp_source", "id": "azure_container_apps",
                          "status": "read", "servers": len(docs)}], errors)


def collect_agentcore_gateways(client) -> dict:
    """``client`` is boto3 ``bedrock-agentcore-control`` or a fake with the same calls."""
    docs, errors = [], []
    try:
        gateways = client.list_gateways().get("items", [])
    except Exception as e:  # noqa: BLE001
        return report([], [{"kind": "mcp_source", "id": "agentcore", "status": "error"}],
                      [{"scope": "agentcore", "error": str(e)}])
    for gw in gateways:
        try:
            targets = client.list_gateway_targets(gatewayIdentifier=gw["gatewayId"]).get("items", [])
        except Exception as e:  # noqa: BLE001
            errors.append({"scope": gw.get("gatewayId", "?"), "error": str(e)})
            continue
        for t in targets:
            cfg = t.get("targetConfiguration", {}).get("mcp", {})
            ep = cfg.get("endpoint") or gw.get("gatewayUrl", "")
            if not ep:
                continue
            docs.append(_desc(
                t.get("name", gw.get("name", "?")), ep, "bedrock_agentcore_gateway",
                {"kind": "iam_role", "principal": gw.get("roleArn", "")},
                hints={"outbound_auth": t.get("credentialProviderType", "unknown")},
                raw={"gatewayId": gw.get("gatewayId", "")},
            ))
    return report(docs, [{"kind": "mcp_source", "id": "agentcore",
                          "status": "read", "servers": len(docs)}], errors)


def collect_copilot_connectors(fetch, token: str, env_id: str, known_endpoints: list[str]) -> dict:
    """Match custom connector hosts against already-discovered MCP endpoints."""
    hdr = {"Authorization": f"Bearer {token}"}
    url = ("https://api.powerapps.com/providers/Microsoft.PowerApps/apis"
           f"?api-version=2016-11-01&$filter=environment eq '{env_id}'")
    known = {_norm(e).split("/")[0] for e in known_endpoints}
    docs, errors = [], []
    try:
        apis = (http_json(fetch, "GET", url, headers=hdr) or {}).get("value", [])
    except Exception as e:  # noqa: BLE001
        return report([], [{"kind": "mcp_source", "id": "copilot_connectors", "status": "error"}],
                      [{"scope": env_id, "error": str(e)}])
    for api in apis:
        host = (api.get("properties", {}).get("runtimeUrls") or [""])[0]
        if host and _norm(host).split("/")[0] in known:
            docs.append(_desc(
                api.get("properties", {}).get("displayName", api.get("name", "?")),
                host, "copilot_studio_connector",
                {"kind": "connector", "principal": api.get("name", "")},
                hints={"environment": env_id},
            ))
    return report(docs, [{"kind": "mcp_source", "id": "copilot_connectors",
                          "status": "read", "servers": len(docs)}], errors)


def merge(*reports: dict) -> dict:
    """De-duplicate by normalized endpoint; keep the richest identity."""
    by_ep: dict[str, dict] = {}
    scopes, errors = [], []
    for r in reports:
        scopes += r["scopes"]
        errors += r["errors"]
        for d in r["descriptors"]:
            key = d["agent"]["native_id"]
            cur = by_ep.get(key)
            if cur is None or (not cur["identity"].get("principal") and d["identity"].get("principal")):
                if cur is not None:
                    d = {**d, "risk_hints": {**cur.get("risk_hints", {}), **d.get("risk_hints", {})}}
                by_ep[key] = d
    return report(list(by_ep.values()), scopes, errors)

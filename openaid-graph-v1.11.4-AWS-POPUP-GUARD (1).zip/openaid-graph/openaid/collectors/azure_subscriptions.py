"""Enumerate ALL Azure subscriptions the caller can see (ARM).

Lets the app show every subscription and roll up the Azure agents (Foundry,
AOAI) discovered in each, instead of a single pinned subscription id.

Config: token supplied by caller (ARM-scoped). Returns subscription scopes and
the subscription id list for downstream Azure collectors.
"""
from __future__ import annotations

from ._shared import http_json, report, skip

ARM = "https://management.azure.com/subscriptions?api-version=2022-12-01"


def collect(fetch, token: str | None = None):
    """Returns (report, subscription_ids, names) — names maps id -> displayName."""
    if not token:
        return skip("azure_subscription", "no ARM token supplied"), []
    hdr = {"Authorization": f"Bearer {token}"}
    try:
        data = http_json(fetch, "GET", ARM, headers=hdr) or {}
    except Exception as e:  # noqa: BLE001
        return (report([], [{"kind": "azure_subscription", "status": "error"}],
                       [{"scope": "arm", "error": str(e)}]), [], {})
    subs = data.get("value", [])
    scopes, ids, names = [], [], {}
    # tenantId travels on the subscription payload — the New Foundry portal
    # requires it as ?tid= on agent links.
    names["__tenant__"] = next((s.get("tenantId", "") for s in subs
                                if s.get("tenantId")), "")
    for s in subs:
        sid = s.get("subscriptionId", "")
        scopes.append({
            "kind": "azure_subscription", "id": sid,
            "name": s.get("displayName", sid),
            "state": s.get("state", ""),
            "status": "read",
            "portal_url": f"https://portal.azure.com/#@/resource/subscriptions/{sid}/overview",
        })
        if sid:
            ids.append(sid)
            names[sid] = s.get("displayName", sid)
    return report([], scopes, []), ids, names

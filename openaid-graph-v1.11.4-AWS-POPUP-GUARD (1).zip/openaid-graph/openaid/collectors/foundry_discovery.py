"""Auto-discover Azure AI Foundry project endpoints via ARM.

Foundry projects live under Cognitive Services accounts:
    GET .../providers/Microsoft.CognitiveServices/accounts?api-version=2025-06-01
    GET .../accounts/{acct}/projects?api-version=2025-06-01

From each project we derive the data-plane endpoint
    https://{account}.services.ai.azure.com/api/projects/{project}
which the foundry_agents collector then queries for assistants.

Needs an ARM token + the list of subscription ids (from azure_subscriptions).
"""
from __future__ import annotations

from ._shared import http_json, report, skip

ARM = "https://management.azure.com"
CSV = "2025-06-01"


def collect(fetch, token: str | None = None, subscription_ids: list[str] | None = None,
            sub_names: dict | None = None, tenant_id: str = ""):
    """Returns (report, endpoints, ep_meta).
    ep_meta maps endpoint -> {arm_id, project, subscription_id, subscription_name}
    so the agents collector can build ai.azure.com deep links and attribute
    each agent to its subscription."""
    if not token:
        return skip("foundry_discovery", "no ARM token"), [], {}
    if not subscription_ids:
        return skip("foundry_discovery", "no subscriptions to scan"), [], {}
    hdr = {"Authorization": f"Bearer {token}"}
    sub_names = sub_names or {}
    scopes, endpoints, errors = [], [], []
    ep_meta: dict = {}
    for sid in subscription_ids:
        try:
            accts = (http_json(fetch, "GET",
                     f"{ARM}/subscriptions/{sid}/providers/Microsoft.CognitiveServices"
                     f"/accounts?api-version={CSV}", headers=hdr) or {}).get("value", [])
        except Exception as e:  # noqa: BLE001
            errors.append({"scope": sid, "surface": "cognitiveservices", "error": str(e)})
            continue
        for acct in accts:
            kind = (acct.get("kind") or "").lower()
            # Do NOT filter narrowly on kind — Foundry accounts appear as
            # AIServices, OpenAI, and (in newer "Microsoft Foundry" resources)
            # other kinds. Anything that exposes an AI endpoint is a candidate.
            acct_name = acct.get("name", "")
            acct_id = acct.get("id", "")
            props = acct.get("properties", {}) or {}
            # HOST MATTERS: ARM's properties.endpoint is the legacy
            # {name}.cognitiveservices.azure.com / {name}.openai.azure.com host,
            # which does NOT serve the Foundry agents data plane — every
            # /agents call 404s there and Foundry agents silently list as ZERO.
            # The agents API lives on {name}.services.ai.azure.com. Prefer the
            # explicit "AI Foundry API" endpoint when ARM exposes it, else
            # construct the services.ai host; keep the ARM endpoint ONLY for
            # the account-level Azure OpenAI assistants sweep.
            arm_ep = str(props.get("endpoint") or "").rstrip("/")
            foundry_api = str((props.get("endpoints") or {}).get("AI Foundry API") or "").rstrip("/")
            if foundry_api:
                base_ep = foundry_api
            elif "services.ai.azure.com" in arm_ep:
                base_ep = arm_ep
            else:
                base_ep = f"https://{acct_name}.services.ai.azure.com"
            if base_ep.endswith("/api/projects"):
                base_ep = base_ep[: -len("/api/projects")]
            aoai_base = arm_ep if arm_ep and "services.ai.azure.com" not in arm_ep else ""
            try:
                projects = (http_json(fetch, "GET",
                            f"{ARM}{acct_id}/projects?api-version={CSV}",
                            headers=hdr) or {}).get("value", [])
            except Exception:
                projects = []
            if not projects:
                # account with no sub-projects: data-plane still exposes agents
                ep = f"{base_ep}/api/projects/{acct_name}"
                endpoints.append(ep)
                ep_meta[ep] = {"arm_id": acct_id, "project": acct_name,
                               "subscription_id": sid,
                               "subscription_name": sub_names.get(sid, sid),
                               "tenant_id": tenant_id,
                               "aoai_base": aoai_base}
                scopes.append({"kind": "foundry_project", "id": ep,
                               "name": acct_name, "subscription": sid, "status": "read"})
                continue
            for proj in projects:
                pname = proj.get("name", "").split("/")[-1]
                ep = f"{base_ep}/api/projects/{pname}"
                endpoints.append(ep)
                ep_meta[ep] = {"arm_id": acct_id, "project": pname,
                               "subscription_id": sid,
                               "subscription_name": sub_names.get(sid, sid),
                               "tenant_id": tenant_id,
                               "aoai_base": aoai_base}
                scopes.append({"kind": "foundry_project", "id": ep,
                               "name": f"{acct_name}/{pname}", "subscription": sid,
                               "status": "read"})
    if not endpoints:
        scopes.append({"kind": "foundry_project", "status": "skipped",
                       "reason": "no Azure AI Foundry (AIServices/OpenAI) accounts found in "
                                 f"{len(subscription_ids)} subscription(s) — or ARM token lacks Reader"})
    return report([], scopes, errors), endpoints, ep_meta

"""ServiceNow AI Agents collector.

Reads the Now Assist / AI Agents tables through the Table API:

* ``sn_aia_agent`` — AI Agent definitions (Yokohama+)
* ``sn_aia_tool``  — tools bound to agents (script, flow, retriever, MCP)

Agents run under an integration user with roles; that identity and its tool
edges are what the trust graph wants.

Config: OPENAID_SNOW_INSTANCE (``https://x.service-now.com``), basic or OAuth
token supplied by caller.
"""
from __future__ import annotations

import os

from ._shared import build_descriptor, http_json, report, skip


def _rows(fetch, base, hdr, table, fields):
    url = f"{base}/api/now/table/{table}?sysparm_fields={fields}&sysparm_limit=1000"
    return (http_json(fetch, "GET", url, headers=hdr) or {}).get("result", [])


def collect(fetch, token: str | None = None, instance: str | None = None) -> dict:
    base = (instance or os.getenv("OPENAID_SNOW_INSTANCE", "")).rstrip("/")
    if not base:
        return skip("servicenow_instance", "OPENAID_SNOW_INSTANCE not set")
    hdr = {"Authorization": f"Bearer {token}"} if token else {}
    docs, errors = [], []
    try:
        agents = _rows(fetch, base, hdr, "sn_aia_agent", "sys_id,name,description,run_as,active")
    except Exception as e:  # noqa: BLE001
        return report([], [{"kind": "servicenow_instance", "id": base, "status": "error"}],
                      [{"scope": base, "error": str(e)}])
    tools_by_agent: dict[str, list] = {}
    try:
        for t in _rows(fetch, base, hdr, "sn_aia_tool", "sys_id,name,agent,type,endpoint"):
            tools_by_agent.setdefault(str(t.get("agent", "")), []).append(t)
    except Exception as e:  # noqa: BLE001
        errors.append({"scope": base, "surface": "sn_aia_tool", "error": str(e)})
    for a in agents:
        links = []
        for t in tools_by_agent.get(a["sys_id"], []):
            ttype = (t.get("type") or "").lower()
            if ttype == "mcp" and t.get("endpoint"):
                links.append({"rel": "calls_mcp", "target": t["endpoint"]})
            else:
                links.append({"rel": "invokes", "target": f"snow:tool:{t.get('name', t['sys_id'])}"})
        if a.get("run_as"):
            links.append({"rel": "authenticates_as", "target": f"snow:user:{a['run_as']}"})
        docs.append(build_descriptor(
            platform="servicenow",
            agent_type="now_assist_agent",
            name=a.get("name", "?"),
            native_id=a["sys_id"],
            scope={"kind": "servicenow_instance", "instance": base},
            identity={"kind": "servicenow_user", "principal": a.get("run_as", "")},
            entitlements=[{"resource": "servicenow:tables", "actions": ["read", "write"],
                           "note": "effective perms = run_as user's roles"}],
            links=links,
            risk_hints={"active": a.get("active") in ("true", True)},
            raw=a,
        ))
    return report(docs, [{"kind": "servicenow_instance", "id": base, "status": "read", "agents": len(docs)}], errors)

"""Salesforce Agentforce collector.

SaaS agents are the biggest ungoverned blind spot: they run under a Salesforce
user/integration identity with real CRM data access and never show up in any
cloud IAM inventory. This reads them via the Tooling/Metadata surface:

* ``/services/data/vXX.0/tooling/query`` on ``BotDefinition`` + ``BotVersion``
  (Agentforce agents are Bot records with type ``Agent``)
* ``GenAiPlannerBundle`` topics/actions when queryable

Config: OPENAID_SF_INSTANCE_URL, token passed by caller (client-credentials
flow handled outside, same rule as everywhere else).
"""
from __future__ import annotations

import os
from urllib.parse import quote

from ._shared import build_descriptor, http_json, report, skip

API = "v61.0"


def _q(fetch, base, hdr, soql):
    url = f"{base}/services/data/{API}/tooling/query?q={quote(soql)}"
    return (http_json(fetch, "GET", url, headers=hdr) or {}).get("records", [])


def collect(fetch, token: str | None = None, instance_url: str | None = None) -> dict:
    base = (instance_url or os.getenv("OPENAID_SF_INSTANCE_URL", "")).rstrip("/")
    if not base:
        return skip("salesforce_org", "OPENAID_SF_INSTANCE_URL not set")
    hdr = {"Authorization": f"Bearer {token}"}
    docs, errors = [], []
    try:
        bots = _q(fetch, base, hdr, "SELECT Id, DeveloperName, MasterLabel, BotUserId, Type FROM BotDefinition")
    except Exception as e:  # noqa: BLE001
        return report([], [{"kind": "salesforce_org", "id": base, "status": "error"}],
                      [{"scope": base, "error": str(e)}])
    for bot in bots:
        is_agent = (bot.get("Type") or "").lower() == "agent"
        links = []
        if bot.get("BotUserId"):
            links.append({"rel": "authenticates_as", "target": f"sf:user:{bot['BotUserId']}"})
        try:
            acts = _q(fetch, base, hdr,
                      f"SELECT Id, DeveloperName FROM GenAiPlugin WHERE BotDefinitionId = '{bot['Id']}'")
            for a in acts:
                links.append({"rel": "invokes", "target": f"sf:action:{a.get('DeveloperName', a['Id'])}"})
        except Exception as e:  # noqa: BLE001 - plugin table not on all orgs
            errors.append({"scope": bot.get("DeveloperName", "?"), "surface": "GenAiPlugin", "error": str(e)})
        docs.append(build_descriptor(
            platform="salesforce",
            agent_type="agentforce" if is_agent else "einstein_bot",
            name=bot.get("MasterLabel", bot.get("DeveloperName", "?")),
            native_id=bot["Id"],
            scope={"kind": "salesforce_org", "instance": base},
            identity={"kind": "salesforce_user", "principal": bot.get("BotUserId", "")},
            entitlements=[{"resource": "salesforce:crm", "actions": ["read", "write"],
                           "note": "runs as bot user; effective perms = that user's perm sets"}],
            links=links,
            raw=bot,
        ))
    return report(docs, [{"kind": "salesforce_org", "id": base, "status": "read", "agents": len(docs)}], errors)

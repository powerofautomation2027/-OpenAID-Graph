"""Minimal AWS Signature Version 4 signing — stdlib only.

Why this exists: Bedrock API keys (bearer) authenticate the classic Bedrock
API, but the AgentCore control plane (bedrock-agentcore-control) — where
Harness-backed agents actually live — requires SigV4. Rather than dragging
in boto3, this signs the two GET/POST list calls the collector makes.

Credential string accepted from the Connections card:
    ACCESS_KEY_ID:SECRET_ACCESS_KEY[:SESSION_TOKEN]
"""
from __future__ import annotations

import hashlib
import hmac
from datetime import datetime, timezone
from urllib.parse import quote, urlsplit


def parse_credentials(token: str):
    """Return (access_key, secret, session) or None if not SigV4-shaped."""
    parts = (token or "").strip().split(":")
    if len(parts) >= 2 and parts[0].startswith(("AKIA", "ASIA")):
        return parts[0], parts[1], (parts[2] if len(parts) > 2 else "")
    return None


def _sign(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode(), hashlib.sha256).digest()


def sigv4_headers(method: str, url: str, *, service: str, region: str,
                  access_key: str, secret_key: str, session_token: str = "",
                  body: bytes = b"", now: datetime | None = None) -> dict:
    """Compute the SigV4 Authorization header set for one request."""
    now = now or datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")

    parts = urlsplit(url)
    host = parts.netloc
    canonical_uri = quote(parts.path or "/", safe="/-_.~")
    # canonical query: sorted, url-encoded
    q = []
    if parts.query:
        for pair in parts.query.split("&"):
            k, _, v = pair.partition("=")
            q.append((quote(k, safe="-_.~"), quote(v, safe="-_.~")))
    canonical_query = "&".join(f"{k}={v}" for k, v in sorted(q))

    payload_hash = hashlib.sha256(body).hexdigest()
    headers = {"host": host, "x-amz-date": amz_date,
               "x-amz-content-sha256": payload_hash}
    if session_token:
        headers["x-amz-security-token"] = session_token
    signed_headers = ";".join(sorted(headers))
    canonical_headers = "".join(f"{k}:{headers[k]}\n" for k in sorted(headers))

    canonical_request = "\n".join([method.upper(), canonical_uri,
                                   canonical_query, canonical_headers,
                                   signed_headers, payload_hash])
    scope = f"{date_stamp}/{region}/{service}/aws4_request"
    string_to_sign = "\n".join([
        "AWS4-HMAC-SHA256", amz_date, scope,
        hashlib.sha256(canonical_request.encode()).hexdigest()])

    k = _sign(("AWS4" + secret_key).encode(), date_stamp)
    k = _sign(k, region)
    k = _sign(k, service)
    k = _sign(k, "aws4_request")
    signature = hmac.new(k, string_to_sign.encode(), hashlib.sha256).hexdigest()

    out = {"Authorization": (f"AWS4-HMAC-SHA256 Credential={access_key}/{scope}, "
                             f"SignedHeaders={signed_headers}, Signature={signature}"),
           "x-amz-date": amz_date, "x-amz-content-sha256": payload_hash}
    if session_token:
        out["x-amz-security-token"] = session_token
    return out

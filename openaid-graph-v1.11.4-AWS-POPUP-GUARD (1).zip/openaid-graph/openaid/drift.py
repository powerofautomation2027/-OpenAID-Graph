"""Agent drift detection — what changed since the last scan.

Nobody ships this for AI agents yet, and it's the thing that actually catches
problems: agent estates change daily because makers create agents without
review. A point-in-time inventory tells you what exists; drift tells you what
*appeared*, what gained reach, and what quietly became dangerous.

Detects, between two snapshots:

* ``new_agent``            — an agent that didn't exist before (shadow AI)
* ``removed_agent``        — an agent that disappeared
* ``became_anonymous``     — auth was removed from an existing agent (critical)
* ``blast_radius_increase``— an agent's reachable footprint grew materially
* ``new_child_agent``      — a connected/child agent was attached to a parent
* ``new_resource_access``  — an agent gained access to a resource it lacked
* ``new_mcp_call``         — an agent started calling an MCP server

Snapshots are kept in memory (single-admin tool); each ``/api/graph`` refresh
records one, so drift is available from the second scan onward.
"""
from __future__ import annotations

import time

_snapshots: list[dict] = []
MAX_SNAPSHOTS = 20
BLAST_JUMP = 15  # points of blast-radius growth worth reporting


def _fingerprint(inventory: dict) -> dict:
    agents = {}
    for a in inventory.get("agents", []):
        agents[a["id"]] = {
            "name": a.get("name", ""),
            "platform": a.get("platform", ""),
            "environment": a.get("environment", ""),
            "anonymous": bool(a.get("anonymous")),
            "blast": a.get("blast_score", 0),
            "resources": sorted(a.get("resources", [])),
            "children": a.get("child_count", 0) + a.get("connected_count", 0),
            "mcp": a.get("calls_mcp", 0),
        }
    return {"at": time.time(), "agents": agents}


def record(inventory: dict) -> None:
    snap = _fingerprint(inventory)
    if not snap["agents"]:
        return  # never snapshot an empty/failed scan
    _snapshots.append(snap)
    if len(_snapshots) > MAX_SNAPSHOTS:
        _snapshots.pop(0)


def _chg(kind, sev, agent, detail, **extra):
    return {"kind": kind, "severity": sev, "agent": agent, "detail": detail, **extra}


def diff() -> dict:
    """Compare the two most recent snapshots."""
    if len(_snapshots) < 2:
        return {"available": False,
                "reason": "drift needs two scans — refresh again to compare",
                "snapshots": len(_snapshots), "changes": []}
    prev, cur = _snapshots[-2], _snapshots[-1]
    changes = []
    for aid, now in cur["agents"].items():
        was = prev["agents"].get(aid)
        if was is None:
            changes.append(_chg("new_agent", "high", now["name"],
                                f"New agent appeared in {now['environment'] or now['platform']}",
                                platform=now["platform"]))
            continue
        if now["anonymous"] and not was["anonymous"]:
            changes.append(_chg("became_anonymous", "critical", now["name"],
                                "Authentication was removed — agent is now anonymously reachable",
                                platform=now["platform"]))
        if now["blast"] - was["blast"] >= BLAST_JUMP:
            changes.append(_chg("blast_radius_increase", "high", now["name"],
                                f"Blast radius grew {was['blast']} → {now['blast']}",
                                platform=now["platform"]))
        gained = sorted(set(now["resources"]) - set(was["resources"]))
        if gained:
            changes.append(_chg("new_resource_access", "high", now["name"],
                                f"Gained access to: {', '.join(gained[:4])}",
                                platform=now["platform"], resources=gained))
        if now["children"] > was["children"]:
            changes.append(_chg("new_child_agent", "medium", now["name"],
                                f"Child/connected agents {was['children']} → {now['children']}",
                                platform=now["platform"]))
        if now["mcp"] > was["mcp"]:
            changes.append(_chg("new_mcp_call", "medium", now["name"],
                                f"Started calling {now['mcp'] - was['mcp']} more MCP server(s)",
                                platform=now["platform"]))
    for aid, was in prev["agents"].items():
        if aid not in cur["agents"]:
            changes.append(_chg("removed_agent", "low", was["name"],
                                "Agent no longer present", platform=was["platform"]))
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    changes.sort(key=lambda c: order.get(c["severity"], 9))
    return {
        "available": True,
        "from": prev["at"], "to": cur["at"],
        "snapshots": len(_snapshots),
        "agents_before": len(prev["agents"]), "agents_after": len(cur["agents"]),
        "changes": changes,
    }

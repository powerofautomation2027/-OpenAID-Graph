"""Agent Hygiene — the governance report admins keep asking for.

Built from the recurring asks across Microsoft's own guidance and community
threads: surface ORPHANED agents (no accountable owner), INACTIVE agents
(no changes in 90+ days — deprecation candidates), and ANONYMOUS-access
agents (anyone with the link), then let the admin fix each in one click
(reassign owner via the Power Platform Reassign API the app already wires,
or open the agent to retire it).

Pure functions over the inventory the app already collects — no new API
calls, no new tokens.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

INACTIVE_DAYS = 90

# score weights: what each finding costs out of 100
_PENALTY = {"orphaned": 12, "anonymous": 15, "inactive": 4}
_GRADES = [(90, "A"), (80, "B"), (65, "C"), (50, "D"), (0, "F")]


def _parse(ts: str):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except Exception:
        return None


def analyze(agents: list[dict], now: datetime | None = None,
            inactive_days: int = INACTIVE_DAYS) -> dict:
    """Compute the hygiene report for a list of inventory agents."""
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(days=inactive_days)
    orphaned, inactive, anonymous = [], [], []

    for a in agents:
        plat = a.get("platform", "")
        row = {"id": a.get("id", ""), "name": a.get("name", ""),
               "platform": plat, "environment": a.get("environment", ""),
               "portal_url": a.get("portal_url", ""),
               "environment_id": a.get("environment_id", ""),
               "native_id": a.get("native_id", "")}
        # ORPHANED — only meaningful where we actually collect ownership
        if plat == "copilot_studio" and not (a.get("owner_id") or "").strip():
            orphaned.append(dict(row, reason="no accountable owner recorded"))
        # ANONYMOUS — anyone with the link can drive the agent
        if a.get("anonymous"):
            anonymous.append(dict(row, reason="anonymous access enabled"))
        # INACTIVE — untouched past the cutoff (deprecation candidate)
        m = _parse(a.get("modified_on", ""))
        if m is not None and m < cutoff:
            days = (now - m).days
            inactive.append(dict(row, reason=f"no changes in {days} days",
                                 days_inactive=days))

    inactive.sort(key=lambda r: -r.get("days_inactive", 0))
    total = max(len(agents), 1)
    score = 100
    score -= _PENALTY["orphaned"] * len(orphaned)
    score -= _PENALTY["anonymous"] * len(anonymous)
    score -= _PENALTY["inactive"] * len(inactive)
    score = max(0, min(100, score))
    grade = next(g for floor, g in _GRADES if score >= floor)

    return {
        "score": score,
        "grade": grade,
        "inactive_days_threshold": inactive_days,
        "totals": {"agents": len(agents), "orphaned": len(orphaned),
                   "inactive": len(inactive), "anonymous": len(anonymous),
                   "clean": max(0, len(agents) - len({r["id"] for r in
                                orphaned + inactive + anonymous}))},
        "orphaned": orphaned,
        "inactive": inactive,
        "anonymous": anonymous,
        "headline": (
            "Tenant is clean — every agent has an owner, recent activity, "
            "and authenticated access." if score == 100 else
            f"{len(orphaned)} orphaned, {len(anonymous)} anonymous-access, "
            f"{len(inactive)} inactive of {total} agents."),
    }

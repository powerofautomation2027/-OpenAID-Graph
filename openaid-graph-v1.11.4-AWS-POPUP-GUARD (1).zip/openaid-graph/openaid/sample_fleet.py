"""A built-in sample fleet so a fresh deploy shows a populated graph instantly.

Served at /api/graph?demo=1 and used automatically when no platform tokens are
configured, so the very first page load demonstrates the attack-path analysis
instead of an empty canvas.
"""
from __future__ import annotations


def sample_descriptors() -> list[dict]:
    mcp = {
        "id": "oaid:mcp:1", "name": "SharePoint MCP",
        "agent": {"platform": "mcp", "agent_type": "mcp_server", "native_id": "h/mcp"},
        "endpoints": [{"url": "https://sharepoint-mcp.internal/mcp"}],
        "entitlements": [{"resource": "sharepoint:sites", "actions": ["read", "write"]}],
        "risk_hints": {"public_ingress": True, "auth_declared": "unknown"}, "links": [],
    }
    copilot = {
        "id": "oaid:cp:1", "name": "HR Copilot",
        "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio", "native_id": "hr"},
        "entitlements": [{"resource": "dataverse:contacts", "actions": ["read"]}],
        "links": [{"rel": "calls_mcp", "target": "https://sharepoint-mcp.internal/mcp"},
                  {"rel": "authenticates_as", "target": "mi:shared"}],
    }
    bedrock = {
        "id": "oaid:br:1", "name": "Ops Agent",
        "agent": {"platform": "bedrock", "agent_type": "bedrock_agent", "native_id": "ops"},
        "entitlements": [{"resource": "s3:secrets-bucket", "actions": ["read"]}],
        "links": [{"rel": "calls_mcp", "target": "https://sharepoint-mcp.internal/mcp"},
                  {"rel": "authenticates_as", "target": "mi:shared"}],
    }
    robot = {
        "id": "oaid:rpa:1", "name": "FinanceBot",
        "agent": {"platform": "uipath", "agent_type": "rpa_robot", "native_id": "fin"},
        "entitlements": [{"resource": "uipath:asset:SapCred", "actions": ["read"]}],
        "risk_hints": {"credential_assets": 1, "unattended": True}, "links": [],
    }
    salesforce = {
        "id": "oaid:sf:1", "name": "Service Agent",
        "agent": {"platform": "salesforce", "agent_type": "agentforce", "native_id": "svc"},
        "entitlements": [{"resource": "salesforce:crm", "actions": ["read", "write"]}],
        "links": [{"rel": "invokes", "target": "oaid:rpa:1"},
                  {"rel": "authenticates_as", "target": "mi:shared"}],
    }
    gcp = {
        "id": "oaid:gcp:1", "name": "Support Agent (Vertex)",
        "agent": {"platform": "gcp_vertex", "agent_type": "agent_builder_gcp", "native_id": "sup"},
        "entitlements": [{"resource": "bigquery:tickets", "actions": ["read"]}],
        "links": [{"rel": "calls_mcp", "target": "https://sharepoint-mcp.internal/mcp"}],
    }
    # Copilot Studio: a main agent with a child agent and a connected agent.
    cs_main = {
        "id": "oaid:cs:main", "name": "IT Helpdesk (main)",
        "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent", "native_id": "helpdesk"},
        "scope": {"kind": "copilot_environment", "environment": "Contoso (default)"},
        "identity": {"kind": "copilot_agent", "auth": "anonymous"},
        "entitlements": [{"resource": "dataverse:tickets", "actions": ["read"]}],
        "risk_hints": {"anonymous": True, "child_count": 1, "connected_count": 1},
        "links": [{"rel": "delegates_to", "target": "oaid:cs:child", "kind": "child"},
                  {"rel": "connects_to", "target": "oaid:cs:conn", "kind": "connected"}],
    }
    cs_child = {
        "id": "oaid:cs:child", "name": "Password Reset (child)",
        "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent", "native_id": "pwreset"},
        "scope": {"kind": "copilot_environment", "environment": "Contoso (default)"},
        "entitlements": [{"resource": "keyvault:reset-secrets", "actions": ["read", "write"]}],
        "links": [{"rel": "authenticates_as", "target": "mi:shared"}],
    }
    cs_conn = {
        "id": "oaid:cs:conn", "name": "HR Lookup (connected)",
        "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent", "native_id": "hrlookup"},
        "scope": {"kind": "copilot_environment", "environment": "HR Production"},
        "entitlements": [{"resource": "dataverse:contacts", "actions": ["read"]}],
        "links": [{"rel": "invokes", "target": "oaid:rpa:1"}],
    }
    cs_sales = {
        "id": "oaid:cs:sales", "name": "Sales Copilot",
        "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent", "native_id": "sales"},
        "scope": {"kind": "copilot_environment", "environment": "Sales Dev"},
        "identity": {"kind": "copilot_agent", "auth": "authenticated"},
        "entitlements": [{"resource": "dataverse:opportunities", "actions": ["read", "write"]}],
        "links": [{"rel": "calls_mcp", "target": "https://sharepoint-mcp.internal/mcp"}],
    }
    # Azure AI Foundry: a main agent delegating to a subagent that out-privileges it.
    fdry_main = {
        "id": "oaid:fd:main", "name": "Research Orchestrator (Foundry)",
        "agent": {"platform": "azure_foundry", "agent_type": "foundry_agent", "native_id": "orch"},
        "scope": {"kind": "foundry_project", "environment": "sub:prod / proj-research"},
        "entitlements": [{"resource": "foundry:model:gpt-4o", "actions": ["invoke"]}],
        "risk_hints": {"connected_count": 1, "has_own_identity": True},
        "links": [{"rel": "delegates_to", "target": "oaid:fd:sub", "kind": "connected"}],
    }
    fdry_sub = {
        "id": "oaid:fd:sub", "name": "Finance Analyst (subagent)",
        "agent": {"platform": "azure_foundry", "agent_type": "foundry_agent", "native_id": "fin"},
        "scope": {"kind": "foundry_project", "environment": "sub:prod / proj-research"},
        "identity": {"kind": "foundry_agent_identity", "principal": "sub-fin-identity"},
        "entitlements": [{"resource": "s3:finance-reports", "actions": ["read"]},
                         {"resource": "sql:ledger", "actions": ["read"]}],
        "links": [{"rel": "authenticates_as", "target": "entra:sub-fin-identity"}],
    }
    aoai = {
        "id": "oaid:ao:1", "name": "Docs Assistant (AOAI)",
        "agent": {"platform": "azure_openai", "agent_type": "aoai_assistant", "native_id": "docs"},
        "scope": {"kind": "azure_openai", "environment": "sub:dev / aoai-eastus"},
        "entitlements": [{"resource": "storage:docs-blob", "actions": ["read"]}],
        "links": [],
    }
    # AWS beyond Bedrock: Amazon Q Business agent.
    amazonq = {
        "id": "oaid:q:1", "name": "Amazon Q Business",
        "agent": {"platform": "aws_q", "agent_type": "amazon_q_app", "native_id": "qbiz"},
        "scope": {"kind": "aws_account", "environment": "aws:111122223333"},
        "entitlements": [{"resource": "s3:knowledge-base", "actions": ["read"]},
                         {"resource": "external:web-index", "actions": ["read"]}],
        "links": [{"rel": "authenticates_as", "target": "iam:q-service-role"}],
    }
    # GCP beyond Vertex: Agentspace / Gemini Enterprise agent.
    agentspace = {
        "id": "oaid:as:1", "name": "Agentspace Assistant",
        "agent": {"platform": "gcp_agentspace", "agent_type": "agentspace_agent", "native_id": "aspace"},
        "scope": {"kind": "gcp_project", "environment": "gcp:proj-corp"},
        "entitlements": [{"resource": "bigquery:hr-data", "actions": ["read"]},
                         {"resource": "external:drive", "actions": ["read"]}],
        "links": [{"rel": "delegates_to", "target": "oaid:gcp:1", "kind": "connected"}],
    }
    # Cisco: AI Defense-monitored agent + a Webex AI agent.
    cisco_ai = {
        "id": "oaid:ci:1", "name": "NetOps AI Assistant (Cisco)",
        "agent": {"platform": "cisco", "agent_type": "cisco_ai_agent", "native_id": "netops"},
        "scope": {"kind": "cisco_org", "environment": "cisco:webex-org"},
        "identity": {"kind": "bot_account", "auth": "anonymous"},
        "entitlements": [{"resource": "webex:rooms", "actions": ["read", "post"]},
                         {"resource": "external:network-telemetry", "actions": ["read"]}],
        "risk_hints": {"anonymous": True},
        "links": [{"rel": "calls_mcp", "target": "https://sharepoint-mcp.internal/mcp"}],
    }
    return [mcp, copilot, bedrock, robot, salesforce, gcp,
            cs_main, cs_child, cs_conn, cs_sales, fdry_main, fdry_sub, aoai,
            amazonq, agentspace, cisco_ai]

"""Continuous security: scan -> diff -> auto-remediate -> report -> dispatch.

Point-in-time posture is table stakes. What operations teams actually need is
the *delta*: what broke since the last scan, what got fixed, and what has been
sitting open too long — plus the ability to have safe fixes applied
automatically and a report land in their channel without anyone logging in.

Pure functions where possible so every rule is unit-testable.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
from typing import Any, Callable


def _utcnow():
    return _dt.datetime.now(_dt.timezone.utc)


def _iso(d=None):
    return (d or _utcnow()).isoformat()


# --------------------------------------------------------------------------
# 1. SNAPSHOT — normalize every analyzer's output into one issue stream
# --------------------------------------------------------------------------
_SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


def issue_id(rule: str, agent_id: str) -> str:
    """Stable id so the same issue on the same agent matches across scans."""
    return hashlib.sha1(f"{rule}|{agent_id}".encode()).hexdigest()[:16]


def snapshot(findings: list[dict] | None = None,
             trifecta: dict | None = None,
             sprawl_out: dict | None = None,
             defender: list[dict] | None = None,
             at: str | None = None) -> dict:
    """Fold all analyzers into one normalized, comparable issue set."""
    issues: dict[str, dict] = {}

    def _put(rule, agent_id, agent_name, severity, detail, source, extra=None):
        iid = issue_id(rule, agent_id)
        if iid in issues and _SEV_RANK.get(severity, 0) <= _SEV_RANK.get(
                issues[iid]["severity"], 0):
            return
        issues[iid] = {"id": iid, "rule": rule, "agent_id": agent_id,
                       "agent": agent_name, "severity": severity,
                       "detail": detail, "source": source, **(extra or {})}

    for f in findings or []:
        _put(f.get("rule", "finding"), f.get("agent_id", "") or f.get("origin", ""),
             f.get("agent_name", "") or f.get("title", ""),
             f.get("severity", "medium"), f.get("detail", ""), "graph_rules")

    for row in (trifecta or {}).get("agents", []):
        if row.get("status") == "exploitable":
            rec = row.get("recommendation") or {}
            _put("lethal_trifecta", row["id"], row["name"], "critical",
                 "Holds all three trifecta legs — exploitable by prompt injection.",
                 "trifecta", {"cut_leg": rec.get("label", "")})

    for row in (sprawl_out or {}).get("rows", []):
        sev = "high" if row.get("priority") in ("critical", "high") else "medium"
        _put("sprawl_" + "_".join(sorted(row.get("flags", []))[:2]),
             row["id"], row["name"], sev,
             "Lifecycle flags: " + ", ".join(row.get("flags", [])), "sprawl")

    for d in defender or []:
        _put(d.get("rule", "defender_assessment"), d.get("resource_id", ""),
             d.get("resource", ""), d.get("severity", "medium"),
             d.get("detail", ""), "defender")

    return {"at": at or _iso(), "issues": issues,
            "counts": _counts(list(issues.values()))}


def _counts(issues: list[dict]) -> dict:
    out: dict[str, int] = {"total": len(issues)}
    for i in issues:
        out[i["severity"]] = out.get(i["severity"], 0) + 1
    return out


# --------------------------------------------------------------------------
# 2. DIFF — what is new, what got fixed, what is still open
# --------------------------------------------------------------------------
def diff(previous: dict | None, current: dict) -> dict:
    prev = (previous or {}).get("issues", {}) or {}
    cur = current.get("issues", {}) or {}
    new = [v for k, v in cur.items() if k not in prev]
    fixed = [v for k, v in prev.items() if k not in cur]
    persisting = [v for k, v in cur.items() if k in prev]

    # age: how long a persisting issue has been open (needs prev first_seen)
    prev_seen = {k: prev[k].get("first_seen") for k in prev}
    for i in persisting:
        i["first_seen"] = prev_seen.get(i["id"]) or (previous or {}).get("at")
    for i in new:
        i["first_seen"] = current.get("at")

    order = lambda xs: sorted(xs, key=lambda i: -_SEV_RANK.get(i["severity"], 0))  # noqa: E731
    return {"at": current.get("at"), "since": (previous or {}).get("at"),
            "new": order(new), "fixed": order(fixed), "persisting": order(persisting),
            "counts": {"new": len(new), "fixed": len(fixed),
                       "persisting": len(persisting),
                       "total": current.get("counts", {}).get("total", 0)}}


# --------------------------------------------------------------------------
# 3. AUTO-REMEDIATION POLICY
# --------------------------------------------------------------------------
DEFAULT_POLICY = {
    "enabled": False,          # opt-in: never auto-change a tenant by surprise
    "dry_run": True,           # decide + report, but do not write
    "min_severity": "critical",
    "rules": ["anonymous_agent"],   # only rules with a safe, reversible fix
    "environments": [],        # empty = all
    "max_per_run": 5,          # blast-radius cap on the automation itself
}

# rule -> the one-click action that fixes it (must be safe + reversible)
_AUTO_ACTION = {"anonymous_agent": "copilot_require_auth"}


def plan_auto_remediation(issues: list[dict], policy: dict | None = None,
                          agent_index: dict | None = None) -> dict:
    """Decide which issues get auto-fixed. Returns {planned, skipped, policy}."""
    pol = {**DEFAULT_POLICY, **(policy or {})}
    agent_index = agent_index or {}
    planned, skipped = [], []
    if not pol["enabled"]:
        return {"planned": [], "skipped": [{"id": i["id"], "reason": "policy disabled"}
                                           for i in issues], "policy": pol}
    floor = _SEV_RANK.get(pol["min_severity"], 4)
    for i in issues:
        a = agent_index.get(i.get("agent_id", "")) or {}
        if i["rule"] not in pol["rules"]:
            skipped.append({"id": i["id"], "reason": "rule not in policy"})
        elif _SEV_RANK.get(i["severity"], 0) < floor:
            skipped.append({"id": i["id"], "reason": "below severity floor"})
        elif pol["environments"] and a.get("environment") not in pol["environments"]:
            skipped.append({"id": i["id"], "reason": "environment not in scope"})
        elif i["rule"] not in _AUTO_ACTION:
            skipped.append({"id": i["id"], "reason": "no safe automatic action"})
        elif len(planned) >= pol["max_per_run"]:
            skipped.append({"id": i["id"], "reason": "max_per_run reached"})
        else:
            planned.append({"id": i["id"], "rule": i["rule"], "agent": i.get("agent", ""),
                            "agent_id": i.get("agent_id", ""),
                            "action": _AUTO_ACTION[i["rule"]],
                            "org_url": a.get("org_url", ""),
                            "bot_id": a.get("native_id", "")})
    return {"planned": planned, "skipped": skipped, "policy": pol}


def apply_auto_remediation(plan: dict, executor: Callable) -> list[dict]:
    """Execute the plan. `executor(action, org_url, bot_id) -> {ok, detail}`.
    Honors dry_run: nothing is written, but the intent is still reported."""
    pol = plan.get("policy", DEFAULT_POLICY)
    results = []
    for p in plan.get("planned", []):
        if pol.get("dry_run", True):
            results.append({**p, "ok": None, "detail": "dry run — no change applied"})
            continue
        try:
            r = executor(p["action"], p.get("org_url", ""), p.get("bot_id", ""))
        except Exception as e:  # noqa: BLE001
            r = {"ok": False, "detail": str(e)[:200]}
        results.append({**p, "ok": bool(r.get("ok")), "detail": r.get("detail", "")})
    return results


# --------------------------------------------------------------------------
# 4. REPORT + DISPATCH
# --------------------------------------------------------------------------
def build_report(delta: dict, remediations: list[dict] | None = None,
                 posture: dict | None = None, title: str = "OpenAID security scan") -> dict:
    rem = remediations or []
    applied = [r for r in rem if r.get("ok") is True]
    failed = [r for r in rem if r.get("ok") is False]
    c = delta.get("counts", {})
    crit_new = [i for i in delta.get("new", []) if i["severity"] == "critical"]
    headline = (f"{c.get('new',0)} new, {c.get('fixed',0)} fixed, "
                f"{c.get('persisting',0)} still open")
    if applied:
        headline += f" — {len(applied)} auto-remediated"
    return {
        "title": title, "at": delta.get("at"), "since": delta.get("since"),
        "headline": headline,
        "counts": c,
        "critical_new": crit_new[:10],
        "new": delta.get("new", [])[:25],
        "fixed": delta.get("fixed", [])[:25],
        "remediations": {"applied": applied, "failed": failed,
                         "dry_run": [r for r in rem if r.get("ok") is None]},
        "posture": {"score": (posture or {}).get("score"),
                    "grade": (posture or {}).get("grade")} if posture else None,
    }


def render_html(rep: dict) -> str:
    def rows(items):
        return "".join(
            f"<tr><td>{i.get('severity','')}</td><td>{i.get('agent','')}</td>"
            f"<td>{i.get('rule','')}</td><td>{i.get('detail','')[:140]}</td></tr>"
            for i in items) or "<tr><td colspan='4'>None</td></tr>"
    rem = rep.get("remediations", {})
    rem_rows = "".join(
        f"<tr><td>{r.get('agent','')}</td><td>{r.get('action','')}</td>"
        f"<td>{'applied' if r.get('ok') else ('dry run' if r.get('ok') is None else 'failed')}</td>"
        f"<td>{r.get('detail','')[:140]}</td></tr>"
        for r in rem.get("applied", []) + rem.get("failed", []) + rem.get("dry_run", [])
    ) or "<tr><td colspan='4'>No automatic remediations</td></tr>"
    g = rep.get("posture") or {}
    return f"""<html><body style="font-family:Segoe UI,sans-serif;color:#1b1b1b">
<h2>{rep['title']}</h2>
<p><b>{rep['headline']}</b><br><small>{rep.get('since','')} &rarr; {rep.get('at','')}</small></p>
{f"<p>Posture grade <b>{g.get('grade')}</b> ({g.get('score')}/100)</p>" if g.get('grade') else ''}
<h3>New issues</h3><table border=1 cellpadding=5 cellspacing=0>
<tr><th>Severity</th><th>Agent</th><th>Rule</th><th>Detail</th></tr>{rows(rep.get('new', []))}</table>
<h3>Fixed since last scan</h3><table border=1 cellpadding=5 cellspacing=0>
<tr><th>Severity</th><th>Agent</th><th>Rule</th><th>Detail</th></tr>{rows(rep.get('fixed', []))}</table>
<h3>Automatic remediation</h3><table border=1 cellpadding=5 cellspacing=0>
<tr><th>Agent</th><th>Action</th><th>Result</th><th>Detail</th></tr>{rem_rows}</table>
</body></html>"""


def to_teams_card(rep: dict) -> dict:
    """MessageCard payload — works with Teams and most generic webhooks."""
    return {
        "@type": "MessageCard", "@context": "https://schema.org/extensions",
        "summary": rep["title"], "themeColor": "E8C268",
        "title": rep["title"],
        "text": rep["headline"],
        "sections": [{"facts": [
            {"name": "New", "value": str(rep["counts"].get("new", 0))},
            {"name": "Fixed", "value": str(rep["counts"].get("fixed", 0))},
            {"name": "Still open", "value": str(rep["counts"].get("persisting", 0))},
            {"name": "Auto-remediated",
             "value": str(len(rep.get("remediations", {}).get("applied", [])))},
        ]}],
    }


def to_slack_blocks(rep: dict) -> dict:
    lines = [f"*{rep['title']}*", rep["headline"]]
    for i in rep.get("critical_new", [])[:5]:
        lines.append(f"• :rotating_light: *{i.get('agent','')}* — {i.get('rule','')}")
    return {"text": "\n".join(lines)}


def dispatch(rep: dict, webhook_url: str, fetch: Callable) -> dict:
    """POST the report to a Teams/Slack-style incoming webhook."""
    if not webhook_url:
        return {"ok": False, "detail": "no webhook configured"}
    payload = (to_slack_blocks(rep) if "slack.com" in webhook_url
               else to_teams_card(rep))
    try:
        fetch("POST", webhook_url, headers={"Content-Type": "application/json"},
              json=payload)
        return {"ok": True, "detail": "report delivered"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "detail": str(e)[:200]}


# --------------------------------------------------------------------------
# 5. HISTORY STORE (file-backed so trends survive a restart)
# --------------------------------------------------------------------------
class ScanStore:
    def __init__(self, path: str | None = None, keep: int = 50):
        self.path = path or os.getenv("OPENAID_SCAN_STORE", "/tmp/openaid_scans.json")
        self.keep = keep
        self._scans: list[dict] = []
        self._load()

    def _load(self):
        try:
            with open(self.path, encoding="utf-8") as fh:
                self._scans = json.load(fh)
        except Exception:  # noqa: BLE001
            self._scans = []

    def _save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as fh:
                json.dump(self._scans[-self.keep:], fh)
        except Exception:  # noqa: BLE001
            pass

    def latest(self) -> dict | None:
        return self._scans[-1] if self._scans else None

    def add(self, snap: dict, delta: dict, report: dict) -> None:
        self._scans.append({"at": snap["at"], "counts": snap["counts"],
                            "issues": snap["issues"], "delta_counts": delta["counts"],
                            "headline": report["headline"]})
        self._scans = self._scans[-self.keep:]
        self._save()

    def history(self, n: int = 30) -> list[dict]:
        return [{"at": s["at"], "counts": s["counts"],
                 "delta_counts": s.get("delta_counts", {}),
                 "headline": s.get("headline", "")} for s in self._scans[-n:]]


# --------------------------------------------------------------------------
# 6. SCHEDULER — unattended scanning on an interval
# --------------------------------------------------------------------------
DEFAULT_SCHEDULE = {"enabled": False, "interval_minutes": 360, "last_run": None,
                    "next_run": None, "runs": 0, "last_headline": ""}


def due(schedule: dict, now=None) -> bool:
    """Pure predicate so the timing rule is testable without sleeping."""
    if not schedule.get("enabled"):
        return False
    last = schedule.get("last_run")
    if not last:
        return True
    n = now or _utcnow()
    try:
        prev = _dt.datetime.fromisoformat(str(last))
    except Exception:  # noqa: BLE001
        return True
    if prev.tzinfo is None:
        prev = prev.replace(tzinfo=_dt.timezone.utc)
    mins = max(1, int(schedule.get("interval_minutes", 360)))
    return (n - prev).total_seconds() >= mins * 60


def mark_run(schedule: dict, headline: str = "", now=None) -> dict:
    n = now or _utcnow()
    mins = max(1, int(schedule.get("interval_minutes", 360)))
    schedule["last_run"] = _iso(n)
    schedule["next_run"] = _iso(n + _dt.timedelta(minutes=mins))
    schedule["runs"] = int(schedule.get("runs", 0)) + 1
    schedule["last_headline"] = headline
    return schedule

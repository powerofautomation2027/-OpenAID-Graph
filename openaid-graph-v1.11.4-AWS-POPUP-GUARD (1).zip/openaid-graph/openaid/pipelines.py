"""Agent Pipelines — promote an agent to another environment.

Two lanes, mirroring how each platform actually stores agents:

  COPILOT STUDIO  (Dataverse -> Dataverse)
    An agent is a `bot` row plus its `botcomponent` rows (topics, triggers,
    settings). Cloning = read both from the source org's Dataverse Web API
    and create them in the target org, re-parenting every component to the
    new bot. Connections, knowledge sources, and channel registrations do
    NOT travel — they are environment-scoped by design — so the clone lands
    as a draft the maker publishes after re-wiring those.

  AZURE AI FOUNDRY  (project -> project, any resource group)
    An agent is a data-plane object in a project. Cloning = GET the agent
    definition from the source project endpoint, strip server-managed
    fields, and POST it to the target project (new /agents surface first,
    retiring /assistants as fallback). The target project must have the
    same model deployed; if not, the API's error is surfaced verbatim.

Every step is appended to a `steps` list so the UI shows a real pipeline
run log, not a spinner.
"""
from __future__ import annotations

import copy

DV_API = "/api/data/v9.2"
_DV_HDR = {"OData-MaxVersion": "4.0", "OData-Version": "4.0",
           "Accept": "application/json", "Content-Type": "application/json"}

# fields that are safe to copy onto a new bot row
_BOT_COPY_FIELDS = ("name", "schemaname", "language", "authenticationmode",
                    "authenticationtrigger", "template", "iconbase64",
                    "synchronizationstatus", "runtimeprovider")
# botcomponent fields that carry the actual definition
_COMP_COPY_FIELDS = ("name", "schemaname", "componenttype", "content",
                     "data", "description", "language", "statecode")

_SERVER_FIELDS = ("id", "object", "created_at", "createdAt", "updated_at",
                  "updatedAt", "last_run_at", "versions", "version",
                  "system_data", "systemData", "etag")


def _hdr(token: str) -> dict:
    return {"Authorization": f"Bearer {token}", **_DV_HDR}


def copilot_clone(fetch, *, source_org_url: str, bot_id: str,
                  target_org_url: str, source_token: str,
                  target_token: str, new_name: str = "",
                  emit=None) -> dict:
    """Clone a Copilot Studio agent between Dataverse environments.
    emit(step, pct) fires live so the UI can draw a real progress bar."""
    steps: list[str] = []

    def _e(msg: str, pct: int) -> None:
        steps.append(msg)
        if emit:
            try:
                emit(msg, pct)
            except Exception:
                pass
    src = source_org_url.rstrip("/")
    dst = target_org_url.rstrip("/")
    if src == dst:
        return {"ok": False, "steps": steps,
                "detail": "source and target environment are the same"}

    # 1. read the bot
    sel = ",".join(_BOT_COPY_FIELDS)
    bot = fetch(method="GET",
                url=f"{src}{DV_API}/bots({bot_id})?$select=botid,{sel}",
                headers=_hdr(source_token)) or {}
    if not bot.get("schemaname"):
        return {"ok": False, "steps": steps,
                "detail": f"bot {bot_id} not readable in source environment"}
    _e(f"read source agent '{bot.get('name', bot_id)}'", 15)

    # 2. read its components
    comps = (fetch(method="GET",
                   url=(f"{src}{DV_API}/botcomponents?$select="
                        + ",".join(_COMP_COPY_FIELDS)
                        + f"&$filter=_parentbotid_value eq {bot_id}"),
                   headers=_hdr(source_token)) or {}).get("value", [])
    _e(f"read {len(comps)} component(s) (topics, triggers, settings)", 30)

    # 3. create the bot in the target (suffix the schema name to avoid clash)
    new_bot = {k: bot[k] for k in _BOT_COPY_FIELDS if bot.get(k) is not None}
    new_bot["schemaname"] = f"{bot['schemaname']}_p{bot_id[:6].replace('-', '')}"
    if new_name:
        new_bot["name"] = new_name
    created = fetch(method="POST", url=f"{dst}{DV_API}/bots",
                    headers={**_hdr(target_token), "Prefer": "return=representation"},
                    json=new_bot) or {}
    new_id = created.get("botid", "")
    if not new_id:
        return {"ok": False, "steps": steps,
                "detail": "target environment refused the bot create "
                          "(check maker permissions / Dataverse token for that org)"}
    _e(f"created agent in target as '{new_bot.get('name')}' ({new_id})", 45)

    # 4. re-create components under the new bot
    made = 0
    errors: list[str] = []
    for i, c in enumerate(comps):
        body = {k: c[k] for k in _COMP_COPY_FIELDS if c.get(k) is not None}
        body["parentbotid@odata.bind"] = f"/bots({new_id})"
        try:
            fetch(method="POST", url=f"{dst}{DV_API}/botcomponents",
                  headers=_hdr(target_token), json=body)
            made += 1
        except Exception as e:  # noqa: BLE001 — copy the rest regardless
            errors.append(f"{c.get('schemaname', '?')}: {str(e)[:80]}")
        if emit:
            try:
                emit(f"component {i + 1}/{len(comps)}",
                     45 + int(50 * (i + 1) / max(len(comps), 1)))
            except Exception:
                pass
    _e(f"re-created {made}/{len(comps)} component(s)", 97)
    if errors:
        steps.append(f"component errors: {'; '.join(errors[:3])}")

    _e("NOTE: connections, knowledge sources and channels are "
       "environment-scoped — re-wire them, then publish.", 100)
    return {"ok": True, "steps": steps, "new_bot_id": new_id,
            "detail": f"agent cloned to target environment ({made} components)"}


def _get_foundry_agent(fetch, endpoint: str, agent_id: str, token: str):
    """Fetch the agent definition, new surface first."""
    hdr = {"Authorization": f"Bearer {token}"}
    for path in (f"agents/{agent_id}?api-version=v1",
                 f"agents/{agent_id}?api-version=2025-05-01",
                 f"assistants/{agent_id}?api-version=v1",
                 f"assistants/{agent_id}?api-version=2025-05-01"):
        try:
            j = fetch(method="GET", url=f"{endpoint.rstrip('/')}/{path}",
                      headers=hdr)
            if j and (j.get("id") or j.get("name")):
                return j, path.split("?")[0].split("/")[0]
        except Exception:
            continue
    return None, ""


def foundry_clone(fetch, *, source_endpoint: str, agent_id: str,
                  target_endpoint: str, token: str,
                  new_name: str = "", emit=None) -> dict:
    """Clone a Foundry agent to another project (any RG/account).
    emit(step, pct) fires live for the UI progress bar."""
    steps: list[str] = []

    def _e(msg: str, pct: int) -> None:
        steps.append(msg)
        if emit:
            try:
                emit(msg, pct)
            except Exception:
                pass
    if source_endpoint.rstrip("/") == target_endpoint.rstrip("/"):
        return {"ok": False, "steps": steps,
                "detail": "source and target project are the same"}

    src_obj, surface = _get_foundry_agent(fetch, source_endpoint, agent_id, token)
    if not src_obj:
        return {"ok": False, "steps": steps,
                "detail": f"agent {agent_id} not readable in source project"}
    _e(f"read source agent '{src_obj.get('name', agent_id)}' "
       f"(surface: {surface})", 35)

    body = copy.deepcopy(src_obj)
    for f in _SERVER_FIELDS:
        body.pop(f, None)
    if new_name:
        body["name"] = new_name
    hdr = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    last_err = ""
    for path in ("agents?api-version=v1", "agents?api-version=2025-05-01",
                 "assistants?api-version=v1"):
        try:
            created = fetch(method="POST",
                            url=f"{target_endpoint.rstrip('/')}/{path}",
                            headers=hdr, json=body) or {}
            new_id = created.get("id") or created.get("name", "")
            if new_id:
                _e(f"created in target project via {path.split('?')[0]} "
                   f"as '{created.get('name', new_id)}'", 90)
                _e("NOTE: the target project must have the same model "
                   "deployed; tool connections may need re-linking.", 100)
                return {"ok": True, "steps": steps, "new_agent_id": new_id,
                        "new_agent_name": created.get("name", ""),
                        "detail": "agent cloned to target project"}
        except Exception as e:  # noqa: BLE001
            last_err = str(e)[:200]
            steps.append(f"{path.split('?')[0]} create failed: {last_err}")
    return {"ok": False, "steps": steps,
            "detail": f"target project refused the create: {last_err}"}


# --------------------------------------------------------------- preflight
def copilot_preflight(fetch, *, target_org_url: str, target_token: str,
                      schema_hint: str = "") -> dict:
    """Cheap go/no-go before a clone: is the target org reachable with this
    token, and does a schema-name clash already exist there?"""
    dst = target_org_url.rstrip("/")
    checks = []
    ok = True
    try:
        who = fetch(method="GET", url=f"{dst}{DV_API}/WhoAmI",
                    headers=_hdr(target_token)) or {}
        checks.append({"check": "target reachable + token valid",
                       "ok": bool(who.get("UserId")),
                       "detail": who.get("UserId", "no UserId returned")})
        ok = ok and bool(who.get("UserId"))
    except Exception as e:  # noqa: BLE001
        checks.append({"check": "target reachable + token valid", "ok": False,
                       "detail": str(e)[:160]})
        ok = False
    if schema_hint and ok:
        try:
            j = fetch(method="GET",
                      url=(f"{dst}{DV_API}/bots?$select=botid&$filter="
                           f"startswith(schemaname,'{schema_hint}')"),
                      headers=_hdr(target_token)) or {}
            n = len(j.get("value", []))
            checks.append({"check": "name clash in target", "ok": n == 0,
                           "detail": f"{n} similar agent(s) already there"
                           if n else "clear"})
        except Exception as e:  # noqa: BLE001
            checks.append({"check": "name clash in target", "ok": True,
                           "detail": f"could not check: {str(e)[:80]}"})
    return {"ok": ok, "checks": checks}


def foundry_preflight(fetch, *, target_endpoint: str, token: str) -> dict:
    """Is the target project listable with this token?"""
    hdr = {"Authorization": f"Bearer {token}"}
    checks = []
    for path in ("agents?api-version=v1", "assistants?api-version=v1"):
        try:
            j = fetch(method="GET",
                      url=f"{target_endpoint.rstrip('/')}/{path}", headers=hdr)
            n = len((j or {}).get("value", (j or {}).get("data", [])) or [])
            checks.append({"check": f"target {path.split('?')[0]} reachable",
                           "ok": True, "detail": f"{n} agent(s) there now"})
            return {"ok": True, "checks": checks}
        except Exception as e:  # noqa: BLE001
            checks.append({"check": f"target {path.split('?')[0]} reachable",
                           "ok": False, "detail": str(e)[:160]})
    return {"ok": False, "checks": checks}

"""Cloud AI security service integration — Microsoft Defender for Cloud.

OpenAID knows what your agents ARE. Defender for Cloud knows what Microsoft's
own security posture engine thinks of the resources those agents run on. This
module pulls both signals and normalizes them into OpenAID's issue shape so
they land in the same scan, the same delta, and the same report.

Sources:
  * Security assessments — Microsoft.Security/assessments (per subscription),
    filtered to the AI/Cognitive Services resources that host agents.
  * Security alerts     — Microsoft.Security/alerts, active alerts only.
Both are read-only ARM calls using the ARM token OpenAID already holds.
"""
from __future__ import annotations

ARM = "https://management.azure.com"
ASSESS_API = "2021-06-01"
ALERTS_API = "2022-01-01"

# Defender severity -> OpenAID severity
_SEV = {"High": "critical", "Medium": "high", "Low": "medium", "Informational": "info"}

# only surface assessments about the resources that actually host agents
_AI_RESOURCE_HINTS = ("cognitiveservices/accounts", "machinelearningservices",
                      "app/containerapps", "web/sites")


def _is_ai_resource(rid: str) -> bool:
    r = (rid or "").lower()
    return any(h in r for h in _AI_RESOURCE_HINTS)


def assessments(fetch, arm_token: str, subscription_ids: list[str]) -> list[dict]:
    """Unhealthy Defender for Cloud assessments on AI-hosting resources."""
    if not (arm_token and subscription_ids):
        return []
    hdr = {"Authorization": f"Bearer {arm_token}"}
    out: list[dict] = []
    for sid in subscription_ids:
        url = (f"{ARM}/subscriptions/{sid}/providers/Microsoft.Security"
               f"/assessments?api-version={ASSESS_API}")
        try:
            j = fetch("GET", url, headers=hdr) or {}
        except Exception:  # noqa: BLE001
            continue
        for a in j.get("value", []) or []:
            props = a.get("properties", {}) or {}
            status = (props.get("status", {}) or {}).get("code", "")
            if status != "Unhealthy":
                continue
            rid = ((props.get("resourceDetails", {}) or {}).get("Id")
                   or a.get("id", ""))
            if not _is_ai_resource(rid):
                continue
            meta = props.get("metadata", {}) or {}
            out.append({
                "rule": "defender_" + (a.get("name", "assessment")[:40] or "assessment"),
                "resource_id": rid,
                "resource": rid.rsplit("/", 1)[-1],
                "severity": _SEV.get(meta.get("severity", "Medium"), "medium"),
                "detail": (props.get("displayName")
                           or meta.get("displayName", "Defender assessment")),
                "remediation": meta.get("remediationDescription", ""),
                "subscription": sid,
                "portal_url": f"https://portal.azure.com/#@/resource{rid}/overview",
                "source": "defender_for_cloud",
            })
    return out


def alerts(fetch, arm_token: str, subscription_ids: list[str]) -> list[dict]:
    """Active Defender for Cloud alerts touching AI-hosting resources."""
    if not (arm_token and subscription_ids):
        return []
    hdr = {"Authorization": f"Bearer {arm_token}"}
    out: list[dict] = []
    for sid in subscription_ids:
        url = (f"{ARM}/subscriptions/{sid}/providers/Microsoft.Security"
               f"/alerts?api-version={ALERTS_API}")
        try:
            j = fetch("GET", url, headers=hdr) or {}
        except Exception:  # noqa: BLE001
            continue
        for a in j.get("value", []) or []:
            p = a.get("properties", {}) or {}
            if (p.get("status") or "").lower() in ("dismissed", "resolved"):
                continue
            rids = [r for r in (p.get("resourceIdentifiers") or [])
                    if _is_ai_resource(str(r.get("azureResourceId", "")))]
            rid = rids[0].get("azureResourceId", "") if rids else ""
            if not rid:
                continue
            out.append({
                "rule": "defender_alert",
                "resource_id": rid, "resource": rid.rsplit("/", 1)[-1],
                "severity": _SEV.get(p.get("severity", "Medium"), "medium"),
                "detail": p.get("alertDisplayName", "Defender alert"),
                "remediation": "; ".join(p.get("remediationSteps", [])[:2]),
                "subscription": sid,
                "portal_url": f"https://portal.azure.com/#@/resource{rid}/overview",
                "source": "defender_alert",
            })
    return out


def collect(fetch, arm_token: str, subscription_ids: list[str]) -> dict:
    a = assessments(fetch, arm_token, subscription_ids)
    al = alerts(fetch, arm_token, subscription_ids)
    items = a + al
    by_sev: dict[str, int] = {}
    for i in items:
        by_sev[i["severity"]] = by_sev.get(i["severity"], 0) + 1
    return {"items": items, "counts": {"total": len(items), "assessments": len(a),
                                       "alerts": len(al), "by_severity": by_sev},
            "connected": bool(arm_token and subscription_ids)}

"""Live platform feature news — Foundry, Copilot Studio, Bedrock, and more.

Agent platforms ship weekly. A posture tool that only knows what it scanned
last night is half-blind: a new tool type (Browser Automation), a new agent
surface (Hosted agents), or a new API version can change the risk picture
before your next scan. This pulls the vendors' own release feeds, filters them
to agent-relevant items, and tags anything that looks security-relevant.

Uses only the standard library for parsing — no new runtime dependencies.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET

FEEDS = [
    {"id": "azure", "source": "Azure updates",
     "url": "https://www.microsoft.com/releasecommunications/api/v2/azure/rss"},
    {"id": "m365", "source": "Microsoft 365 roadmap",
     "url": "https://www.microsoft.com/releasecommunications/api/v1/m365/rss"},
    {"id": "aws", "source": "AWS What's New",
     "url": "https://aws.amazon.com/about-aws/whats-new/recent/feed/"},
]

# an item is kept only if it mentions one of these
TOPICS = {
    "foundry": ["foundry", "ai studio", "azure ai", "agent service"],
    "copilot_studio": ["copilot studio", "power platform", "power virtual agent"],
    "bedrock": ["bedrock", "amazon q", "agentcore"],
    "agents": ["ai agent", "agents", "mcp", "model context protocol"],
}

# items matching these get a security flag — they usually change the risk model
SECURITY_HINTS = [
    "security", "identity", "authentication", "auth", "permission", "rbac",
    "governance", "compliance", "private endpoint", "network", "encryption",
    "entra", "guardrail", "content filter", "data loss", "dlp", "audit",
    "prompt injection", "vulnerabilit", "cve",
]

_TAG = re.compile(r"<[^>]+>")


def _clean(s: str, limit: int = 260) -> str:
    txt = _TAG.sub("", str(s or "")).replace("&nbsp;", " ")
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt[:limit] + ("…" if len(txt) > limit else "")


def classify(title: str, summary: str) -> tuple[list, bool]:
    blob = f"{title} {summary}".lower()
    topics = [t for t, words in TOPICS.items() if any(w in blob for w in words)]
    security = any(h in blob for h in SECURITY_HINTS)
    return topics, security


def parse_feed(xml_text: str, source: str, limit: int = 40) -> list[dict]:
    """Parse an RSS/Atom document defensively — a malformed feed yields []."""
    try:
        root = ET.fromstring(xml_text)
    except Exception:  # noqa: BLE001
        return []
    items = root.findall(".//item")
    atom = "{http://www.w3.org/2005/Atom}"
    if not items:
        items = root.findall(f".//{atom}entry")
    out = []
    for it in items[:limit]:
        def _t(*names):
            for n in names:
                el = it.find(n)
                if el is not None:
                    return el.text or el.get("href") or ""
            return ""
        title = _t("title", f"{atom}title")
        link = _t("link", f"{atom}link")
        if not link:
            el = it.find(f"{atom}link")
            link = el.get("href", "") if el is not None else ""
        summary = _t("description", "summary", f"{atom}summary", f"{atom}content")
        date = _t("pubDate", "published", f"{atom}updated", f"{atom}published")
        topics, security = classify(title, summary)
        if not topics:
            continue
        out.append({"title": _clean(title, 160), "url": link,
                    "summary": _clean(summary), "date": _clean(date, 40),
                    "source": source, "topics": topics, "security": security})
    return out


def collect(fetch_text, limit: int = 30) -> dict:
    """fetch_text(url) -> raw feed body. Each feed fails independently."""
    items, errors = [], []
    for f in FEEDS:
        try:
            body = fetch_text(f["url"])
        except Exception as e:  # noqa: BLE001
            errors.append({"source": f["source"], "error": str(e)[:160]})
            continue
        items.extend(parse_feed(body or "", f["source"]))
    # security-relevant first, then keep feed order
    items.sort(key=lambda i: (not i["security"],))
    by_topic: dict = {}
    for i in items:
        for t in i["topics"]:
            by_topic[t] = by_topic.get(t, 0) + 1
    return {"items": items[:limit], "errors": errors,
            "totals": {"items": len(items),
                       "security_relevant": sum(1 for i in items if i["security"]),
                       "by_topic": by_topic},
            "sources": [f["source"] for f in FEEDS]}

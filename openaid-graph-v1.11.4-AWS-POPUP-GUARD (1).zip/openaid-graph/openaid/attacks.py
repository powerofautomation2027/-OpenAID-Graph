"""Agent attack-surface analysis, mapped to the OWASP Top 10 for Agentic
Applications 2026 (ASI01-ASI10).

For every discovered agent we compute which OWASP Agentic techniques it is
*exposed* to, based on real, observed properties (not guesswork):

  ASI01 Agent Goal Hijack .......... anonymous / unauthenticated entry
  ASI02 Tool Misuse ................ calls tools/MCP with write or broad scope
  ASI03 Identity & Privilege Abuse . shared identity, or child out-privileges parent
  ASI04 Supply Chain ............... calls an MCP/tool not in inventory
  ASI05 Unexpected Code Execution .. reaches an RPA robot / code-exec tool
  ASI06 Memory Poisoning ........... reads external/untrusted data stores
  ASI07 Insecure Inter-Agent Comms . delegates to agents over unauth channels
  ASI08 Cascading Failures ......... deep delegation / many downstream agents
  ASI09 Human-Agent Trust Exploit .. anonymous agent presented to end users
  ASI10 Rogue Agents ............... agent reachable that isn't inventoried

Then we compute **attack paths**: entry (an internet/anonymous-reachable agent)
-> pivot (shared MCP / shared identity) -> impact (sensitive store), using the
same trust graph the rest of the app is built on. This is the "show any agent
attack" view — concrete, per-agent, and graph-derived.
"""
from __future__ import annotations

from .graph.trust_graph import HIERARCHY

TECHNIQUES = {
    "ASI01": ("Agent Goal Hijack", "Attacker manipulates the agent's objective via prompt injection, poisoned data, or forged messages."),
    "ASI02": ("Tool Misuse", "Agent is driven to abuse its tools/connectors — writes, deletes, or exfiltrates through them."),
    "ASI03": ("Identity & Privilege Abuse", "Agent's identity is over-scoped or shared; compromise grants broad access."),
    "ASI04": ("Supply Chain", "Agent depends on an external tool/MCP/model not under governance."),
    "ASI05": ("Unexpected Code Execution", "Agent can trigger code / RPA execution with real system reach."),
    "ASI06": ("Memory Poisoning", "Agent ingests untrusted external data that can corrupt its later decisions."),
    "ASI07": ("Insecure Inter-Agent Comms", "Agent delegates to other agents over unauthenticated channels."),
    "ASI08": ("Cascading Failures", "A fault or compromise propagates through a chain of downstream agents."),
    "ASI09": ("Human-Agent Trust Exploitation", "Anonymous/untrusted agent is presented to humans as trustworthy."),
    "ASI10": ("Rogue Agents", "An agent operates outside inventory/oversight and can be reached."),
}

_SENSITIVE = ("crm", "secret", "keyvault", "s3", "sql", "ledger", "finance",
              "dataverse", "storage", "sharepoint", "bedrock", "openai")


def _has(links, rel):
    return [l for l in links if l.get("rel") == rel]


def _writes(d):
    for e in d.get("entitlements", []):
        acts = [a.lower() for a in e.get("actions", [])]
        if any(a in ("write", "post", "create", "update", "delete") for a in acts):
            return True
    return False


def analyze_agent(d: dict, graph) -> dict:
    """Return the OWASP technique exposure for one descriptor."""
    ag = d["agent"]
    rh = d.get("risk_hints", {})
    links = d.get("links", [])
    ident = d.get("identity", {})
    techs = []

    anon = rh.get("anonymous") or ident.get("auth") == "anonymous"
    if anon:
        techs.append("ASI01")
        techs.append("ASI09")
    if _has(links, "calls_mcp") or (_has(links, "invokes") and _writes(d)) or _writes(d):
        techs.append("ASI02")
    # identity abuse: shared principal or child edges present
    if graph is not None:
        node = graph.nodes.get(d["id"])
        if node:
            # shared identity?
            for e in graph.out.get(d["id"], []):
                if e.rel == "authenticates_as":
                    peers = [x for x in graph.inn.get(e.dst, []) if x.rel == "authenticates_as"]
                    if len(peers) >= 2:
                        techs.append("ASI03")
                        break
    if _has(links, "delegates_to") or _has(links, "connects_to"):
        techs.append("ASI07")
        # cascading if this agent has >1 downstream or a child that itself delegates
        downstream = [l for l in links if l.get("rel") in HIERARCHY]
        if len(downstream) >= 2:
            techs.append("ASI08")
    # supply chain / rogue: calls an MCP or child not resolved in inventory
    if graph is not None:
        for e in graph.out.get(d["id"], []):
            tgt = graph.nodes.get(e.dst)
            if tgt and tgt.meta.get("unresolved"):
                techs.append("ASI04")
            if tgt and tgt.meta.get("synthetic") and e.rel in HIERARCHY:
                techs.append("ASI10")
    # code execution: reaches an RPA robot
    if graph is not None:
        for i in graph.reachable(d["id"]):
            n = graph.nodes.get(i)
            if n and n.kind == "rpa_robot":
                techs.append("ASI05")
                break
    # memory poisoning: reads an external/untrusted store
    for e in d.get("entitlements", []):
        acts = [a.lower() for a in e.get("actions", [])]
        if "read" in acts and any(h in e.get("resource", "").lower() for h in ("web", "email", "external", "blob", "sites")):
            techs.append("ASI06")
            break

    techs = sorted(set(techs))
    return {
        "id": d["id"], "name": d.get("name", "?"), "platform": ag.get("platform", ""),
        "techniques": [{"id": t, "name": TECHNIQUES[t][0], "desc": TECHNIQUES[t][1]} for t in techs],
        "technique_ids": techs,
        "exposure": len(techs),
        "anonymous": bool(anon),
    }


def _reach_sensitive(graph, start):
    hits = []
    for i in graph.reachable(start):
        n = graph.nodes.get(i)
        if n and n.kind == "resource" and any(h in n.name.lower() for h in _SENSITIVE):
            hits.append(n.name)
    return hits


def attack_paths(graph, top: int = 12) -> list[dict]:
    """Entry -> pivot -> impact chains. Entry = an anonymous/agent node; impact =
    a sensitive resource; pivot = the highest-degree shared node on the way."""
    paths = []
    for n in graph.nodes.values():
        if n.kind != "agent":
            continue
        anon = n.meta.get("risk_hints", {}).get("anonymous")
        if not anon:
            continue
        sensitive = _reach_sensitive(graph, n.id)
        if not sensitive:
            continue
        # find a pivot: a reachable mcp_server or shared identity
        pivot = None
        for i in graph.reachable(n.id):
            nd = graph.nodes.get(i)
            if nd and nd.kind == "mcp_server":
                pivot = nd.name
                break
            if nd and nd.kind == "identity":
                peers = [x for x in graph.inn.get(i, []) if x.rel == "authenticates_as"]
                if len(peers) >= 2:
                    pivot = nd.name
        paths.append({
            "entry": n.name, "entry_id": n.id, "platform": n.platform,
            "pivot": pivot or "(direct)",
            "impact": sensitive[:4],
            "impact_count": len(sensitive),
            "technique": "ASI01 -> ASI03 -> ASI02",
        })
    paths.sort(key=lambda p: p["impact_count"], reverse=True)
    return paths[:top]


def build_attack_view(descriptors: list[dict], graph) -> dict:
    per_agent = [analyze_agent(d, graph) for d in descriptors]
    per_agent = [a for a in per_agent if a["exposure"] > 0]
    per_agent.sort(key=lambda a: a["exposure"], reverse=True)
    # technique rollup
    counts = {tid: 0 for tid in TECHNIQUES}
    for a in per_agent:
        for t in a["technique_ids"]:
            counts[t] += 1
    technique_rollup = [{"id": tid, "name": TECHNIQUES[tid][0], "desc": TECHNIQUES[tid][1],
                         "count": counts[tid]} for tid in TECHNIQUES]
    return {
        "techniques": technique_rollup,
        "agents": per_agent,
        "paths": attack_paths(graph),
    }

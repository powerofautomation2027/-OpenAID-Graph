"""Exports: OCSF for Splunk/Cisco XDR, and asset context for Cisco AI Defense.

Two cheap, high-value bridges to the Cisco stack:

* ``to_ocsf`` — emits OCSF-shaped events (class 6002 Detection Finding + a
  synthetic Entity Management view) so findings land in Splunk ES / Cisco XDR
  with the fields those SIEMs already parse. HEC-ready NDJSON.
* ``to_ai_defense_context`` — a flat asset-context document keyed by endpoint
  and identity, meant to be side-loaded into Cisco AI Defense so its runtime
  guardrails carry the identity/ownership/blast-radius that AI Defense itself
  does not compute. Complementary, not competing.

Nothing here calls Cisco APIs; it produces artifacts the operator ships. That
keeps the export deterministic and unit-testable.
"""
from __future__ import annotations

import json
import time
from typing import Iterable

OCSF_VERSION = "1.3.0"
_SEV = {"low": 2, "medium": 3, "high": 4, "critical": 5}


def _finding_event(blast: dict, descriptor: dict) -> dict:
    sev = blast["severity"]
    return {
        "metadata": {"version": OCSF_VERSION, "product": {"name": "OpenAID", "vendor_name": "PowerOfAutomation"}},
        "class_uid": 2004, "class_name": "Detection Finding",
        "category_uid": 2, "activity_id": 1,
        "time": int(time.time() * 1000),
        "severity_id": _SEV.get(sev, 2), "severity": sev.title(),
        "finding_info": {
            "title": f"Agent blast radius: {blast['origin_name']}",
            "uid": blast["origin"],
            "desc": (f"If compromised, reaches {blast['reachable_total']} nodes across "
                     f"{len(blast['cross_platform']) + 1} platform(s); "
                     f"{len(blast['sensitive_resources'])} sensitive resource(s)."),
        },
        "resources": [{"name": r, "type": "data-store"} for r in blast["sensitive_resources"]],
        "evidences": [{
            "actor": {"process": {"name": descriptor.get("name", "")}},
            "cross_platform": blast["cross_platform"],
            "reachable_agents": blast["reachable_agents"],
        }],
        "risk_score": blast["score"],
        "unmapped": {"platform": descriptor["agent"]["platform"],
                     "agent_type": descriptor["agent"].get("agent_type", "")},
    }


def to_ocsf(descriptors: Iterable[dict], blasts: Iterable[dict]) -> str:
    by_id = {d["id"]: d for d in descriptors}
    lines = []
    for b in blasts:
        d = by_id.get(b["origin"])
        if d is None:
            continue
        lines.append(json.dumps(_finding_event(b, d), separators=(",", ":")))
    return "\n".join(lines) + ("\n" if lines else "")


def to_ai_defense_context(descriptors: Iterable[dict], blasts: Iterable[dict]) -> str:
    blast_by = {b["origin"]: b for b in blasts}
    assets = []
    for d in descriptors:
        b = blast_by.get(d["id"], {})
        ep = (d.get("endpoints") or [{}])[0].get("url", "")
        assets.append({
            "asset_id": d["id"],
            "name": d.get("name", ""),
            "endpoint": ep,
            "platform": d["agent"]["platform"],
            "agent_type": d["agent"].get("agent_type", ""),
            "identity": d.get("identity", {}),
            "owner_identity": next((l["target"] for l in d.get("links", [])
                                    if l.get("rel") == "authenticates_as"), ""),
            "blast_radius_score": b.get("score", 0),
            "blast_severity": b.get("severity", "unknown"),
            "reaches_sensitive": b.get("sensitive_resources", []),
            "cross_platform_reach": b.get("cross_platform", []),
        })
    return json.dumps({"schema": "openaid.ai_defense_context.v1",
                       "generated": int(time.time()),
                       "assets": assets}, indent=2)

"""CrowdStrike Falcon export — AI agent identities as security telemetry.

Two shapes, both accepted by Falcon Next-Gen SIEM / LogScale:

1. ``falcon_ngsiem_ndjson`` — one JSON event per agent, using Falcon's
   ``#event_simpleName`` convention so events land in a queryable repo. Carries
   identity, blast radius, OWASP technique exposure, and cross-platform reach.

2. ``falcon_iocs`` — the MCP/agent endpoints an agent can reach, expressed as
   Falcon custom IOC domain indicators, so Falcon can alert if an endpoint that
   should only be called by an agent shows up elsewhere.

This makes OpenAID an input to the SOC's existing tooling rather than another
console to watch: an agent with a high blast radius becomes a detectable,
correlatable entity next to endpoint and identity telemetry.
"""
from __future__ import annotations

import json

SEV = {"critical": 90, "high": 70, "medium": 50, "low": 20}


def _events(inventory: dict, attacks: dict) -> list[dict]:
    tech_by_agent = {a["id"]: a.get("technique_ids", [])
                     for a in (attacks or {}).get("agents", [])}
    out = []
    for a in inventory.get("agents", []):
        out.append({
            "#event_simpleName": "AiAgentIdentity",
            "#repo": "openaid",
            "vendor": "OpenAID",
            "product": "AI Agent Identity Discovery",
            "AgentId": a["id"],
            "AgentName": a["name"],
            "Platform": a["platform"],
            "AgentType": a["type"],
            "Environment": a["environment"],
            "IdentityKind": a.get("identity_kind", ""),
            "IdentityPrincipal": a.get("identity", ""),
            "AnonymousAccess": bool(a.get("anonymous")),
            "Unattended": bool(a.get("unattended")),
            "ChildAgentCount": a.get("child_count", 0),
            "ConnectedAgentCount": a.get("connected_count", 0),
            "McpServerCalls": a.get("calls_mcp", 0),
            "ReachableResources": a.get("resources", []),
            "BlastRadiusScore": a.get("blast_score", 0),
            "SeverityName": a.get("blast_severity", "low"),
            "Severity": SEV.get(a.get("blast_severity", "low"), 20),
            "OwaspAgenticTechniques": tech_by_agent.get(a["id"], []),
        })
    for p in (attacks or {}).get("paths", []):
        out.append({
            "#event_simpleName": "AiAgentAttackPath",
            "#repo": "openaid",
            "vendor": "OpenAID",
            "EntryAgent": p.get("entry"),
            "EntryPlatform": p.get("platform"),
            "PivotVia": p.get("pivot"),
            "ImpactedResources": p.get("impact", []),
            "ImpactedResourceCount": p.get("impact_count", 0),
            "TechniqueChain": p.get("technique"),
            "Severity": SEV["critical"],
            "SeverityName": "critical",
        })
    return out


def _iocs(inventory: dict) -> list[dict]:
    iocs = []
    for m in inventory.get("mcp_servers", []):
        host = str(m.get("name", "")).replace("https://", "").replace("http://", "").split("/")[0]
        if not host or "." not in host:
            continue
        iocs.append({
            "type": "domain",
            "value": host,
            "action": "detect",
            "severity": "high" if m.get("public") else "medium",
            "description": (f"MCP server reachable by {m.get('caller_count', 0)} AI agent(s) "
                            f"across {', '.join(m.get('platforms', [])) or 'unknown platforms'}"
                            f"{'; public ingress' if m.get('public') else ''}"),
            "platforms": ["windows", "mac", "linux"],
            "tags": ["openaid", "ai-agent", "mcp"],
            "applied_globally": True,
        })
    return iocs


def build(inventory: dict, attacks: dict | None = None) -> dict:
    events = _events(inventory, attacks or {})
    iocs = _iocs(inventory)
    return {
        "falcon_ngsiem_ndjson": "\n".join(json.dumps(e) for e in events),
        "falcon_iocs": iocs,
        "event_count": len(events),
        "ioc_count": len(iocs),
    }

"""Agent sprawl & shadow-AI detection.

The #1 operational complaint about low-code agent platforms is sprawl: makers
spin up agents, move teams, and nobody deletes anything. Security tools flag
*vulnerable* agents; almost nothing flags *abandoned* ones — yet an orphaned
agent with live credentials is both a standing risk and a recurring bill.

Signals computed from lifecycle metadata OpenAID already collects:
  ORPHANED   — no owner recorded
  STALE      — untouched beyond the staleness window
  DORMANT    — disabled but still provisioned (statecode != 0)
  DUPLICATE  — same display name appearing more than once in an environment
  UNUSED     — zero sessions in the usage window (when usage data is present)
"""
from __future__ import annotations

import datetime as _dt

STALE_DAYS = 90


def _utcnow():
    return _dt.datetime.now(_dt.timezone.utc)


def _parse(ts: str):
    if not ts:
        return None
    try:
        return _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except Exception:  # noqa: BLE001
        return None


def _age_days(ts: str):
    d = _parse(ts)
    return None if d is None else max(0, (_utcnow() - d).days)


def analyze(agents: list[dict], sessions_by_agent: dict | None = None,
            stale_days: int = STALE_DAYS) -> dict:
    """agents: inventory rows (need risk_hints lifecycle fields merged in)."""
    sessions_by_agent = sessions_by_agent or {}
    name_counts: dict[tuple, int] = {}
    for a in agents:
        key = ((a.get("environment") or ""), (a.get("name") or "").strip().lower())
        name_counts[key] = name_counts.get(key, 0) + 1

    rows = []
    for a in agents:
        flags = []
        age = _age_days(a.get("modified_on", ""))
        if not a.get("owner_id"):
            flags.append("orphaned")
        if age is not None and age >= stale_days:
            flags.append("stale")
        if a.get("statecode") not in (None, 0):
            flags.append("dormant")
        key = ((a.get("environment") or ""), (a.get("name") or "").strip().lower())
        if name_counts.get(key, 0) > 1:
            flags.append("duplicate")
        if a.get("id") in sessions_by_agent and sessions_by_agent[a["id"]] == 0:
            flags.append("unused")
        if not flags:
            continue
        rows.append({
            "id": a.get("id", ""), "name": a.get("name", "?"),
            "platform": a.get("platform", ""), "environment": a.get("environment", ""),
            "portal_url": a.get("portal_url", ""),
            "days_since_change": age, "flags": flags,
            "anonymous": bool(a.get("anonymous")),
            # an orphaned agent that is ALSO anonymous is the worst combination:
            # nobody owns it and anyone can call it
            "priority": ("critical" if ("orphaned" in flags and a.get("anonymous"))
                         else "high" if len(flags) >= 2 else "medium"),
        })

    order = {"critical": 0, "high": 1, "medium": 2}
    rows.sort(key=lambda r: (order[r["priority"]], -(r["days_since_change"] or 0)))
    counts: dict[str, int] = {}
    for r in rows:
        for f in r["flags"]:
            counts[f] = counts.get(f, 0) + 1
    return {
        "rows": rows,
        "totals": {"agents": len(agents), "flagged": len(rows),
                   "clean": len(agents) - len(rows),
                   "sprawl_pct": round(100 * len(rows) / len(agents)) if agents else 0},
        "by_flag": counts,
        "stale_days": stale_days,
    }

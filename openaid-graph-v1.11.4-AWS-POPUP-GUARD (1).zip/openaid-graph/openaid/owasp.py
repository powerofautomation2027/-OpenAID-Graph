"""OWASP Top 10 for LLM Applications (2025) — live coverage scan.

Maps every discovered finding, trifecta leg and lifecycle flag onto the OWASP
LLM Top 10 so a team can answer, in one screen, "which OWASP categories are we
actually exposed on right now, and on which agents".
"""
from __future__ import annotations

TOP10 = [
    ("LLM01", "Prompt Injection"),
    ("LLM02", "Sensitive Information Disclosure"),
    ("LLM03", "Supply Chain"),
    ("LLM04", "Data and Model Poisoning"),
    ("LLM05", "Improper Output Handling"),
    ("LLM06", "Excessive Agency"),
    ("LLM07", "System Prompt Leakage"),
    ("LLM08", "Vector and Embedding Weaknesses"),
    ("LLM09", "Misinformation"),
    ("LLM10", "Unbounded Consumption"),
]

# rule -> OWASP ids it evidences
RULE_MAP = {
    "lethal_trifecta": ["LLM01", "LLM02", "LLM06"],
    "anonymous_agent": ["LLM01", "LLM10", "LLM06"],
    "high_blast_radius": ["LLM06"],
    "privilege_non_inheritance": ["LLM06"],
    "shared_identity": ["LLM06"],
    "mcp_public": ["LLM03", "LLM02"],
    "mcp_no_auth": ["LLM03", "LLM06"],
    "cross_platform_pivot": ["LLM03"],
    "orphaned_agent": ["LLM03"],
    "knowledge_overscope": ["LLM02", "LLM08"],
}


def scan(findings: list[dict] | None = None, trifecta: dict | None = None,
         sprawl_out: dict | None = None) -> dict:
    """Return per-category exposure with the agents evidencing it."""
    cats = {cid: {"id": cid, "name": name, "agents": [], "rules": set(), "count": 0}
            for cid, name in TOP10}

    def _hit(rule, agent):
        for cid in RULE_MAP.get(rule, []):
            c = cats[cid]
            c["count"] += 1
            c["rules"].add(rule)
            if agent and agent not in c["agents"]:
                c["agents"].append(agent)

    for f in findings or []:
        _hit(f.get("rule", ""), f.get("agent_name") or f.get("subject") or "")
    for r in (trifecta or {}).get("agents", []):
        if r.get("status") == "exploitable":
            _hit("lethal_trifecta", r.get("name", ""))
    for r in (sprawl_out or {}).get("rows", []):
        if "orphaned" in r.get("flags", []):
            _hit("orphaned_agent", r.get("name", ""))

    out = []
    for cid, name in TOP10:
        c = cats[cid]
        out.append({"id": cid, "name": name, "count": c["count"],
                    "rules": sorted(c["rules"]),
                    "agents": c["agents"][:8],
                    "status": ("exposed" if c["count"] else "clear")})
    exposed = [c for c in out if c["status"] == "exposed"]
    return {"categories": out,
            "totals": {"exposed": len(exposed), "clear": 10 - len(exposed),
                       "evidence": sum(c["count"] for c in out),
                       "coverage_pct": round(100 * (10 - len(exposed)) / 10)},
            "framework": "OWASP Top 10 for LLM Applications (2025)"}

"""Executive posture report — industry-aware, marketing-ready summary.

Maps discovered findings to the control frameworks each industry cares about,
so a healthcare buyer sees HIPAA, a retailer sees PCI-DSS, etc. Pure functions
for testability; the server wraps them into /api/posture.
"""
from __future__ import annotations

# finding rule -> frameworks it maps to, with a plain-English control ref
FRAMEWORK_MAP = {
    "anonymous_agent": {
        "hipaa": "164.312(a) Access Control — unauthenticated access to ePHI-capable agents",
        "pci": "Req 7/8 — no authentication on a system component",
        "soc2": "CC6.1 — logical access not restricted",
        "gdpr": "Art. 32 — insufficient access security for personal data",
        "iso27001": "A.9 Access control",
    },
    "shared_identity": {
        "soc2": "CC6.2 — credentials not unique per principal",
        "pci": "Req 8.5 — shared authentication credentials",
        "iso27001": "A.9.2 User access management",
    },
    "high_blast_radius": {
        "soc2": "CC7.1 — broad blast radius weakens containment",
        "iso27001": "A.12 Operations security",
    },
    "mcp_public": {
        "pci": "Req 1 — system component exposed to untrusted network",
        "hipaa": "164.312(e) Transmission security",
        "soc2": "CC6.6 — external exposure without controls",
    },
    "mcp_no_auth": {
        "hipaa": "164.312(d) Person/entity authentication",
        "pci": "Req 8 — no authentication",
        "soc2": "CC6.1",
    },
    "privilege_non_inheritance": {
        "soc2": "CC6.3 — least privilege not enforced across delegation",
        "iso27001": "A.9.2.3 Privileged access",
    },
}

INDUSTRIES = {
    "healthcare": {"label": "Healthcare / Life Sciences", "frameworks": ["hipaa", "soc2", "iso27001"]},
    "finance": {"label": "Financial Services", "frameworks": ["pci", "soc2", "iso27001"]},
    "retail": {"label": "Retail / E-commerce", "frameworks": ["pci", "gdpr", "soc2"]},
    "public": {"label": "Public Sector / Government", "frameworks": ["iso27001", "soc2", "gdpr"]},
    "technology": {"label": "Technology / SaaS", "frameworks": ["soc2", "iso27001", "gdpr"]},
    "general": {"label": "General / Cross-industry", "frameworks": ["soc2", "iso27001", "hipaa", "pci", "gdpr"]},
}

FRAMEWORK_LABEL = {"hipaa": "HIPAA", "pci": "PCI-DSS", "soc2": "SOC 2",
                   "gdpr": "GDPR", "iso27001": "ISO 27001"}

_SEV_WEIGHT = {"critical": 40, "high": 25, "medium": 10, "low": 3, "info": 1}


def posture_score(findings: list[dict]) -> dict:
    """0-100 posture score (100 = clean). Weighted by severity, capped."""
    penalty = sum(_SEV_WEIGHT.get(f.get("severity", "low"), 3) for f in findings)
    score = max(0, 100 - min(100, penalty))
    grade = ("A" if score >= 90 else "B" if score >= 75 else
             "C" if score >= 60 else "D" if score >= 40 else "F")
    return {"score": score, "grade": grade}


def build_report(findings: list[dict], agents: list[dict],
                 industry: str = "general") -> dict:
    ind = INDUSTRIES.get(industry, INDUSTRIES["general"])
    fws = ind["frameworks"]

    # count findings by severity
    sev_counts: dict[str, int] = {}
    for f in findings:
        s = f.get("severity", "low")
        sev_counts[s] = sev_counts.get(s, 0) + 1

    # framework impact: how many findings touch each relevant framework
    fw_impact = {fw: {"label": FRAMEWORK_LABEL.get(fw, fw), "findings": [], "count": 0}
                 for fw in fws}
    for f in findings:
        rule = f.get("rule", "")
        m = FRAMEWORK_MAP.get(rule, {})
        for fw in fws:
            if fw in m:
                fw_impact[fw]["count"] += 1
                if len(fw_impact[fw]["findings"]) < 5:
                    fw_impact[fw]["findings"].append(
                        {"rule": rule, "control": m[fw], "severity": f.get("severity", "low")})

    # top exposures = highest-severity findings, deduped by rule
    seen = set()
    top = []
    for f in sorted(findings, key=lambda x: -_SEV_WEIGHT.get(x.get("severity", "low"), 0)):
        if f.get("rule") in seen:
            continue
        seen.add(f.get("rule"))
        top.append({"rule": f.get("rule", ""), "title": f.get("title", ""),
                    "severity": f.get("severity", "low"), "detail": f.get("detail", "")})
        if len(top) >= 6:
            break

    score = posture_score(findings)
    anon = sum(1 for a in agents if a.get("anonymous"))
    return {
        "industry": industry, "industry_label": ind["label"],
        "frameworks": [FRAMEWORK_LABEL.get(fw, fw) for fw in fws],
        "score": score["score"], "grade": score["grade"],
        "totals": {"agents": len(agents), "findings": len(findings),
                   "anonymous_agents": anon},
        "severity": sev_counts,
        "framework_impact": [fw_impact[fw] for fw in fws],
        "top_exposures": top,
        "headline": _headline(score["grade"], len(findings), anon, ind["label"]),
    }


def _headline(grade: str, n_findings: int, anon: int, industry: str) -> str:
    if grade in ("A", "B"):
        return (f"Strong AI-agent posture for {industry}: {n_findings} open "
                f"findings, {anon} anonymously accessible agents.")
    return (f"AI-agent posture needs attention for {industry}: {n_findings} open "
            f"findings including {anon} anonymously accessible agents — prioritize "
            f"authentication and blast-radius reduction.")

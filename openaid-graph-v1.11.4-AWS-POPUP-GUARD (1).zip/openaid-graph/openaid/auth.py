"""Interactive sign-in for the admin console (device-code flow).

The user clicks "Sign in" in the GUI, this starts a Microsoft device-code flow,
the UI shows a short code + link, the user completes sign-in in their browser,
and the app receives delegated tokens. From the one sign-in, MSAL silently
acquires per-resource tokens (ARM, Power Platform BAP, Dataverse, Foundry) using
the cached refresh token, so live discovery can read the real tenant.

Requires an Azure AD *public client* app registration with device-code enabled
and delegated permissions consented. DEPLOY.ps1 creates it and passes its id via
OPENAID_CLIENT_ID / OPENAID_TENANT_ID. If those aren't set, the app stays in
demo mode and this module reports "not configured" cleanly.

Single-admin tool: one in-memory token cache/session is intentional and fine.
"""
from __future__ import annotations

import os
import threading
import time

# Resource scopes we acquire (delegated). `.default` returns a token for any
# permission that's been admin-consented for the resource — more reliable than
# naming /user_impersonation, which must match an explicitly-registered scope.
SCOPES = {
    "arm": ["https://management.azure.com/.default"],
    "bap": ["https://api.bap.microsoft.com/.default"],
    "foundry": ["https://ml.azure.com/.default"],
}

_state = {
    "app": None,          # MSAL PublicClientApplication
    "flow": None,         # pending device flow
    "account": None,      # signed-in account
    "pending": False,
    "error": None,
    "thread": None,
}
_lock = threading.Lock()


def _client_id():
    return os.getenv("OPENAID_CLIENT_ID", "")


def _authority():
    tenant = os.getenv("OPENAID_TENANT_ID", "organizations")
    return f"https://login.microsoftonline.com/{tenant}"


def configured() -> bool:
    return bool(_client_id())


def _get_app():
    if _state["app"] is not None:
        return _state["app"]
    try:
        import msal  # type: ignore
        _state["app"] = msal.PublicClientApplication(_client_id(), authority=_authority())
    except Exception as e:  # noqa: BLE001 - never let auth init crash the API
        _state["error"] = f"auth init failed: {e}"
        return None
    return _state["app"]


def status() -> dict:
    return {
        "configured": configured(),
        "signed_in": _state["account"] is not None,
        "pending": _state["pending"],
        "account": (_state["account"] or {}).get("username", "") if _state["account"] else "",
        "error": _state["error"],
    }


def start_device_flow() -> dict:
    """Begin sign-in. Returns the user_code + verification link for the GUI."""
    if not configured():
        return {"ok": False, "error": "Sign-in not configured (no OPENAID_CLIENT_ID). Running in demo mode."}
    app = _get_app()
    if app is None:
        return {"ok": False, "error": _state.get("error")
                or "sign-in unavailable (MSAL could not initialise in the container)."}
    with _lock:
        # MSAL adds the reserved scopes (openid, profile, offline_access)
        # automatically and REJECTS them if passed in — request only the
        # resource scope here; other resources come from the refresh token.
        try:
            flow = app.initiate_device_flow(
                scopes=["https://management.azure.com/user_impersonation"])
        except Exception as e:  # noqa: BLE001 - surface the reason, never 500
            return {"ok": False, "error": f"could not start sign-in: {e}"}
        if "user_code" not in flow:
            return {"ok": False, "error": flow.get("error_description", "could not start device flow")}
        _state["flow"] = flow
        _state["pending"] = True
        _state["error"] = None

        def _complete():
            try:
                result = app.acquire_token_by_device_flow(flow)  # blocks until done/expired
                if "access_token" in result:
                    accts = app.get_accounts()
                    _state["account"] = accts[0] if accts else {"username": "signed-in"}
                    _state["error"] = None
                else:
                    _state["error"] = result.get("error_description", "sign-in failed")
            except Exception as e:  # noqa: BLE001
                _state["error"] = str(e)
            finally:
                _state["pending"] = False

        t = threading.Thread(target=_complete, daemon=True)
        _state["thread"] = t
        t.start()
    return {
        "ok": True,
        "user_code": flow["user_code"],
        "verification_uri": flow.get("verification_uri", "https://microsoft.com/devicelogin"),
        "message": flow.get("message", ""),
        "expires_in": flow.get("expires_in", 900),
    }


def sign_out() -> dict:
    app = _get_app()
    if app and _state["account"]:
        try:
            for a in app.get_accounts():
                app.remove_account(a)
        except Exception:
            pass
    _state["account"] = None
    _state["flow"] = None
    _state["pending"] = False
    return {"ok": True}


def get_token(resource: str) -> str:
    """Silently acquire a token for a known resource key, or a Dataverse URL."""
    app = _get_app()
    if app is None or _state["account"] is None:
        return ""
    if resource in SCOPES:
        scopes = SCOPES[resource]
    else:
        # treat as a Dataverse org URL / globaldisco -> its own audience
        base = resource.rstrip("/")
        scopes = [f"{base}/.default"]
    try:
        accts = app.get_accounts()
        if not accts:
            return ""
        res = app.acquire_token_silent(scopes, account=accts[0])
        return (res or {}).get("access_token", "") if res else ""
    except Exception:
        return ""

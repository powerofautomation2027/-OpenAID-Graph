"""Agent-to-agent trust graph and blast-radius engine.

This is the piece that does not exist anywhere else. Human identity has
BloodHound; AI agents have nothing. Given the descriptors from every
collector, we build a directed multigraph and answer one question:

    if THIS agent is compromised, what else is reachable, and how bad is it?

No third-party graph library — a few hundred lines of dict-of-sets is enough,
keeps the container dependency-free, and is exact for the graph sizes an agent
fleet produces (thousands of nodes, not millions).

Nodes are descriptors (agents, MCP servers, RPA robots) plus *resource* and
*identity* nodes synthesized from ``entitlements`` and ``links``. Edges carry a
relation and a weight; weight feeds severity, not pathfinding.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Iterable

# Relations that move an attacker forward (a compromise can traverse these).
TRAVERSABLE = {
    "invokes": 1.0,
    "calls_mcp": 1.0,
    "delegates_to": 1.0,   # parent -> child agent (Copilot child / Foundry subagent)
    "connects_to": 0.95,   # parent -> connected (independent) agent
    "uses_connector": 0.9,
    "authenticates_as": 0.8,
    "writes": 0.7,
    "reads": 0.4,
}
# Hierarchy relations: a compromise traverses them AND they define the tree the
# UI draws under a main agent.
HIERARCHY = {"delegates_to", "connects_to"}
# Relations we draw but never traverse for blast radius (informational).
NON_TRAVERSABLE = {"member_of", "tagged"}

# Node kinds that count as "sensitive" when tallying blast-radius impact.
SENSITIVE_RESOURCE_HINTS = (
    "crm", "dataverse", "s3", "storage", "sql", "keyvault", "secret",
    "email", "sharepoint", "tables", "bedrock", "openai",
)


@dataclass
class Node:
    id: str
    kind: str            # agent | mcp_server | rpa_robot | resource | identity
    name: str
    platform: str = ""
    meta: dict = field(default_factory=dict)


@dataclass
class Edge:
    src: str
    dst: str
    rel: str
    weight: float
    label: str = ""


class TrustGraph:
    def __init__(self) -> None:
        self.nodes: dict[str, Node] = {}
        self.out: dict[str, list[Edge]] = defaultdict(list)
        self.inn: dict[str, list[Edge]] = defaultdict(list)

    # ---- construction -----------------------------------------------------
    def add_node(self, node: Node) -> None:
        self.nodes.setdefault(node.id, node)

    def add_edge(self, src: str, dst: str, rel: str, label: str = "") -> None:
        if src == dst:
            return
        w = TRAVERSABLE.get(rel, 0.0 if rel in NON_TRAVERSABLE else 0.3)
        e = Edge(src, dst, rel, w, label)
        self.out[src].append(e)
        self.inn[dst].append(e)

    @classmethod
    def from_descriptors(cls, descriptors: Iterable[dict]) -> "TrustGraph":
        g = cls()
        # index endpoints so calls_mcp targets resolve to the real MCP node
        endpoint_index: dict[str, str] = {}
        for d in descriptors:
            for ep in d.get("endpoints", []):
                url = ep.get("url", "")
                if url:
                    endpoint_index[_ep_key(url)] = d["id"]

        # Pre-register every descriptor as a node first, so hierarchy links
        # (delegates_to / connects_to) resolve to the real child agent even when
        # the parent is processed before the child in iteration order.
        for d in descriptors:
            g.add_node(Node(
                id=d["id"], kind=_kind_of(d), name=d.get("name", "?"),
                platform=d["agent"]["platform"],
                meta={"agent_type": d["agent"].get("agent_type", ""),
                      "risk_hints": d.get("risk_hints", {}),
                      "portal_url": d.get("scope", {}).get("portal_url", ""),
                      "environment": (d.get("scope", {}).get("environment")
                                      or d.get("scope", {}).get("project")
                                      or d.get("scope", {}).get("subscription_name")
                                      or ""),
                      "environment_id": d.get("scope", {}).get("environment_id", ""),
                      "subscription": d.get("scope", {}).get("subscription_name", "")},
            ))

        for d in descriptors:
            # entitlement -> resource nodes + read/write edges
            for ent in d.get("entitlements", []):
                res = ent.get("resource", "")
                if not res:
                    continue
                rid = f"resource:{res}"
                g.add_node(Node(id=rid, kind="resource", name=res, meta={"sensitive": _sensitive(res)}))
                actions = [a.lower() for a in ent.get("actions", [])]
                rel = "writes" if any(a in ("write", "post", "create", "update", "delete") for a in actions) else "reads"
                g.add_edge(d["id"], rid, rel)
            # links -> edges (resolve calls_mcp to real endpoint node when known)
            for link in d.get("links", []):
                rel = link.get("rel", "")
                tgt = link.get("target", "")
                if not tgt:
                    continue
                if rel == "calls_mcp":
                    resolved = endpoint_index.get(_ep_key(tgt))
                    dst = resolved or f"mcp:{_ep_key(tgt)}"
                    if not resolved:
                        g.add_node(Node(id=dst, kind="mcp_server", name=tgt, meta={"unresolved": True}))
                elif rel == "authenticates_as":
                    dst = f"identity:{tgt}"
                    g.add_node(Node(id=dst, kind="identity", name=tgt))
                elif rel in ("reads", "writes"):
                    dst = f"resource:{tgt}"
                    g.add_node(Node(id=dst, kind="resource", name=tgt, meta={"sensitive": _sensitive(tgt)}))
                elif rel in ("delegates_to", "connects_to"):
                    # parent -> child/connected agent; target is a real descriptor
                    # id when we resolved it, else a synthetic child agent node.
                    if tgt in g.nodes:
                        dst = tgt
                    else:
                        dst = f"agent:{tgt}"
                        g.add_node(Node(id=dst, kind="agent", name=tgt.split(":")[-1],
                                        meta={"child_kind": link.get("kind", ""), "synthetic": True}))
                    # tag the child so the UI can nest it under this parent
                    child = g.nodes.get(dst)
                    if child is not None:
                        child.meta.setdefault("parent", d["id"])
                        child.meta.setdefault("child_kind", link.get("kind", rel))
                else:  # invokes / uses_connector / unknown -> target may be another descriptor
                    dst = tgt if tgt in g.nodes else f"ext:{tgt}"
                    if dst not in g.nodes:
                        g.add_node(Node(id=dst, kind="external", name=tgt))
                g.add_edge(d["id"], dst, rel, link.get("label", ""))
        return g

    # ---- analysis ---------------------------------------------------------
    def reachable(self, start: str, max_depth: int = 8) -> dict[str, int]:
        """BFS over traversable edges. Returns node_id -> hop distance."""
        seen = {start: 0}
        q = deque([start])
        while q:
            cur = q.popleft()
            if seen[cur] >= max_depth:
                continue
            for e in self.out.get(cur, []):
                if e.weight <= 0:
                    continue
                if e.dst not in seen:
                    seen[e.dst] = seen[cur] + 1
                    q.append(e.dst)
        seen.pop(start, None)
        return seen

    def blast_radius(self, start: str) -> dict:
        reach = self.reachable(start)
        ids = list(reach)
        identities = [i for i in ids if self.nodes[i].kind == "identity"]
        resources = [i for i in ids if self.nodes[i].kind == "resource"]
        sensitive = [i for i in resources if self.nodes[i].meta.get("sensitive")]
        agents = [i for i in ids if self.nodes[i].kind in ("agent", "mcp_server", "rpa_robot")]
        cross = {self.nodes[i].platform for i in agents if self.nodes[i].platform}
        origin_pf = self.nodes[start].platform if start in self.nodes else ""
        cross.discard(origin_pf)
        cross.discard("mcp")  # MCP is shared infra, not a destination platform
        # severity: sensitive stores dominate, cross-platform pivots amplify
        score = min(100, int(
            len(sensitive) * 18 + len(identities) * 6 + len(agents) * 4
            + len(cross) * 12 + (len(resources) - len(sensitive)) * 2
        ))
        return {
            "origin": start,
            "origin_name": self.nodes[start].name if start in self.nodes else start,
            "score": score,
            "severity": _band(score),
            "reachable_total": len(ids),
            "reachable_agents": len(agents),
            "reachable_identities": len(identities),
            "reachable_resources": len(resources),
            "sensitive_resources": [self.nodes[i].name for i in sensitive],
            "cross_platform": sorted(cross),
            "sample_path_targets": [self.nodes[i].name for i in sorted(ids, key=lambda x: reach[x])[:6]],
        }

    def rank_blast(self, top: int = 25) -> list[dict]:
        origins = [n for n in self.nodes.values() if n.kind in ("agent", "mcp_server", "rpa_robot")]
        results = [self.blast_radius(n.id) for n in origins]
        results.sort(key=lambda r: r["score"], reverse=True)
        return results[:top]

    def cross_platform_pivots(self) -> list[dict]:
        """Every edge where the source and destination are agents on different
        platforms, or an agent -> mcp_server both feeding >1 platform. These are
        the findings that only a cross-cloud inventory can produce."""
        out = []
        for edges in self.out.values():
            for e in edges:
                s, d = self.nodes.get(e.src), self.nodes.get(e.dst)
                if not s or not d:
                    continue
                if s.kind in ("agent", "rpa_robot") and d.kind == "mcp_server":
                    callers = {self.nodes[x.src].platform for x in self.inn.get(e.dst, [])}
                    callers.discard("")
                    if len(callers) > 1:
                        out.append({"mcp": d.name, "shared_by": sorted(callers),
                                    "rel": e.rel, "why": "one MCP server reachable from multiple platforms"})
        # de-dup
        seen, uniq = set(), []
        for o in out:
            k = (o["mcp"], tuple(o["shared_by"]))
            if k not in seen:
                seen.add(k)
                uniq.append(o)
        return uniq

    def hierarchies(self) -> list[dict]:
        """Parent -> child/connected agent trees. One entry per main agent that
        has at least one child or connected agent, so the UI can nest them."""
        out = []
        for n in self.nodes.values():
            if n.kind not in ("agent",):
                continue
            kids = []
            seen_kids = set()
            for e in self.out.get(n.id, []):
                if e.rel in HIERARCHY:
                    c = self.nodes.get(e.dst)
                    label = getattr(e, "label", "") or (c.name if c else e.dst)
                    if c and e.dst not in seen_kids:
                        seen_kids.add(e.dst)
                        kids.append({
                            "id": c.id, "name": (label if c.meta.get("synthetic") else c.name) or label,
                            "type": "child" if e.rel == "delegates_to" else "connected",
                            "platform": c.platform or n.platform,
                            "synthetic": bool(c.meta.get("synthetic")),
                            # GROUNDED: child agents have NO page of their own —
                            # they're configured on the parent's Agents page. Send
                            # child links to {parent}/agents; connected agents keep
                            # their own overview URL.
                            "portal_url": (c.meta.get("portal_url", "")
                                           if e.rel == "connects_to"
                                           else (n.meta.get("portal_url", "").replace("/overview", "/agents").replace("/details", "/agents")
                                                 or n.meta.get("portal_url", ""))),
                            "environment": c.meta.get("environment", "")
                                           or n.meta.get("environment", ""),
                            "agent_type": c.meta.get("agent_type", ""),
                        })
            if kids:
                out.append({
                    "parent": n.id, "parent_name": n.name, "platform": n.platform,
                    "children": kids, "child_count": len(kids),
                    "portal_url": n.meta.get("portal_url", ""),
                    "environment": n.meta.get("environment", ""),
                    "environment_id": n.meta.get("environment_id", ""),
                    "subscription": n.meta.get("subscription", ""),
                    "agent_type": n.meta.get("agent_type", ""),
                    "child_n": sum(1 for k in kids if k["type"] == "child"),
                    "connected_n": sum(1 for k in kids if k["type"] == "connected"),
                    "anonymous": bool((n.meta.get("risk_hints") or {}).get("anonymous")),
                    "risk": ("high" if (n.meta.get("risk_hints") or {}).get("anonymous")
                             else ("elevated" if len(kids) >= 3 else "normal")),
                })
        out.sort(key=lambda h: h["child_count"], reverse=True)
        return out

    def to_cytoscape(self) -> dict:
        """Elements for the webapp graph screen."""
        return {
            "nodes": [{"data": {"id": n.id, "label": n.name, "kind": n.kind,
                                "platform": n.platform, **n.meta}} for n in self.nodes.values()],
            "edges": [{"data": {"source": e.src, "target": e.dst, "rel": e.rel,
                                "weight": e.weight, "hierarchy": e.rel in HIERARCHY}}
                      for edges in self.out.values() for e in edges],
        }


# ---- helpers --------------------------------------------------------------
def _kind_of(d: dict) -> str:
    at = d["agent"].get("agent_type", "")
    if at == "mcp_server":
        return "mcp_server"
    if at == "rpa_robot":
        return "rpa_robot"
    return "agent"


def _ep_key(url: str) -> str:
    u = url.split("://")[-1]
    return u.rstrip("/").lower()


def _sensitive(res: str) -> bool:
    r = res.lower()
    return any(h in r for h in SENSITIVE_RESOURCE_HINTS)


def _band(score: int) -> str:
    if score >= 70:
        return "critical"
    if score >= 45:
        return "high"
    if score >= 20:
        return "medium"
    return "low"

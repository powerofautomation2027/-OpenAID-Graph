"""v0.2 discovery orchestrator.

Runs every configured collector, merges into one descriptor list, builds the
trust graph, ranks blast radius, finds cross-platform pivots, and produces the
Cisco exports. Designed to sit *next to* the existing ``discover.py`` so v0.1
paths are untouched; the web service calls whichever it is pointed at.

Each collector is optional and self-gating: if its env/config is absent it
returns a ``skipped`` scope, never an error, so coverage stays honest.
"""
from __future__ import annotations

from .collectors import (
    azure_subscriptions,
    copilot_studio,
    dataverse_discovery,
    foundry_agents,
    foundry_discovery,
    foundry_hub_agents,
    third_party,
    gcp_vertex,
    mcp_servers,
    powerplatform_envs,
    salesforce_agentforce,
    servicenow_agents,
    uipath_bots,
    webex_bots,
)
from .attacks import build_attack_view
from .exports import cisco_ocsf, crowdstrike
from .graph.trust_graph import TrustGraph
from .inventory import build_inventory, build_env_resolver
from .risk import agent_graph_rules


def _merge_reports(reports: list[dict]) -> dict:
    descriptors, scopes, errors = [], [], []
    for r in reports:
        descriptors += r.get("descriptors", [])
        scopes += r.get("scopes", [])
        errors += r.get("errors", [])
    return {"descriptors": descriptors, "scopes": scopes, "errors": errors}


_ENVMETA_PATH = "/tmp/openaid_envmeta.json"


def _envmeta_save(index: dict) -> None:
    import json as _j
    try:
        if index:
            with open(_ENVMETA_PATH, "w") as f:
                _j.dump(index, f)
    except Exception:
        pass


def _envmeta_backfill(index: dict) -> dict:
    import json as _j
    try:
        with open(_ENVMETA_PATH) as f:
            cached = _j.load(f)
    except Exception:
        return index
    for url, meta in (index or {}).items():
        c = cached.get(url) or {}
        for k in ("tenant_id", "is_default"):
            if not meta.get(k) and c.get(k) is not None:
                meta[k] = c[k]
    return index


def discover(fetch, *, existing_descriptors=None, tokens=None, config=None) -> dict:
    """``fetch`` is the injected HTTP function; ``tokens``/``config`` hold the
    per-platform credentials the operator supplied. ``existing_descriptors``
    lets v0.2 fold in whatever v0.1 already found so the graph is complete."""
    tokens = tokens or {}
    config = config or {}
    reports = []

    # Enumerate Power Platform environments. Prefer BAP (has richer metadata),
    # but ALWAYS also try Global Discovery, which lists every Dataverse org the
    # signed-in user can access even without Power Platform admin rights.
    pp_urls = config.get("dataverse_urls") or []
    env_index = {}
    bap_token = config.get("bap_token") or tokens.get("azure")
    arm_token = config.get("arm_token") or tokens.get("azure")
    disco_token = config.get("discovery_token")
    if bap_token:
        pp_report, discovered_urls, env_index = powerplatform_envs.collect(fetch, token=bap_token)
        _envmeta_save(env_index)
        reports.append(pp_report)
        pp_urls = list({*pp_urls, *discovered_urls})
    if disco_token:
        gd_report, gd_urls, gd_index = dataverse_discovery.collect(fetch, token=disco_token)
        # BAP down: globaldisco entries lack tenant_id/is_default, which
        # silently downgrades Copilot deep links (default-env agents bounce
        # to home). Backfill from the last successful BAP snapshot.
        gd_index = _envmeta_backfill(gd_index)
        reports.append(gd_report)
        pp_urls = list({*pp_urls, *gd_urls})
        # MERGE, never overwrite: globaldisco entries carry only {id, name};
        # a blind update() stomped BAP's tenant_id/is_default and silently
        # broke Copilot default-env deep links whenever both sources ran.
        for _u, _m in gd_index.items():
            _cur = env_index.get(_u)
            if _cur is None:
                env_index[_u] = _m
            else:
                for _k, _v in _m.items():
                    _cur.setdefault(_k, _v)
    sub_ids, sub_names = [], {}
    if arm_token:
        sub_report, sub_ids, sub_names = azure_subscriptions.collect(fetch, token=arm_token)
        reports.append(sub_report)

    # Auto-discover Azure AI Foundry project endpoints via ARM, then list agents.
    foundry_eps = config.get("foundry_endpoints") or []
    foundry_meta = {}
    if arm_token and sub_ids:
        fd_report, discovered_eps, foundry_meta = foundry_discovery.collect(
            fetch, token=arm_token, subscription_ids=sub_ids, sub_names=sub_names,
            tenant_id=config.get("tenant_id", ""))
        reports.append(fd_report)
        foundry_eps = list({*foundry_eps, *discovered_eps})

    reports.append(gcp_vertex.collect(fetch, token=tokens.get("gcp"),
                                      projects=config.get("gcp_projects")))
    reports.append(salesforce_agentforce.collect(fetch, token=tokens.get("salesforce"),
                                                 instance_url=config.get("sf_instance")))
    reports.append(servicenow_agents.collect(fetch, token=tokens.get("servicenow"),
                                             instance=config.get("snow_instance")))
    reports.append(uipath_bots.collect(fetch, token=tokens.get("uipath"),
                                       base_url=config.get("uipath_url")))
    reports.append(webex_bots.collect(fetch, token=tokens.get("webex")))
    # Copilot Studio: acquire a per-environment Dataverse token when a token
    # provider is available (interactive sign-in), else fall back to a shared one.
    dv_provider = config.get("dataverse_token")
    if dv_provider and pp_urls:
        for url in pp_urls:
            rep = copilot_studio.collect(fetch, token=dv_provider(url),
                                         dataverse_urls=[url], env_index=env_index,
                                         pp_token=config.get("pp_token", ""))
            # tag each agent with the friendly environment name for the dropdown
            friendly = (env_index.get(url) or {}).get("name") or url
            for d in rep.get("descriptors", []):
                d.setdefault("scope", {})["environment"] = friendly
            reports.append(rep)
    else:
        reports.append(copilot_studio.collect(fetch, token=tokens.get("azure"),
                                              dataverse_urls=pp_urls, env_index=env_index,
                                              pp_token=config.get("pp_token", "")))
    reports.append(foundry_agents.collect(fetch,
                                          token=config.get("foundry_token") or tokens.get("azure"),
                                          endpoints=foundry_eps, ep_meta=foundry_meta,
                                          cogsvc_token=config.get("cogsvc_token")))
    # Hub-based Foundry projects are INVISIBLE to the services.ai data plane
    # ("Project not found") — sweep them via the legacy AML agents route.
    if arm_token and sub_ids:
        reports.append(foundry_hub_agents.collect(
            fetch, arm_token=arm_token, ml_token=config.get("ml_token"),
            subscription_ids=sub_ids, sub_names=sub_names))

    # MCP servers: several sources, merged separately then folded in.
    mcp_reports = []
    if tokens.get("azure") and config.get("subscriptions"):
        mcp_reports.append(mcp_servers.collect_azure_container_apps(
            fetch, tokens["azure"], config["subscriptions"]))
    if config.get("agentcore_client"):
        mcp_reports.append(mcp_servers.collect_agentcore_gateways(config["agentcore_client"]))
    if mcp_reports:
        reports.append(mcp_servers.merge(*mcp_reports))

    # Connected third-party platforms feed the SAME graph — a signed-in
    # connector is only worth having if its agents actually show up in the
    # inventory, blast radius, trifecta audit and reports.
    tp_conns = config.get("third_party") or {}
    if tp_conns:
        reports.append(third_party.collect(fetch, tp_conns))

    merged = _merge_reports(reports)
    all_desc = list(existing_descriptors or []) + merged["descriptors"]

    graph = TrustGraph.from_descriptors(all_desc)
    blasts = graph.rank_blast(top=50)
    pivots = graph.cross_platform_pivots()
    hierarchies = graph.hierarchies()
    # Normalize hierarchy environment labels to the SAME friendly names the
    # agents table + dropdown use. Live Copilot scopes sometimes fall back to
    # the raw Dataverse URL (env_index miss), which then never matched a
    # dropdown option — selecting an environment showed nothing.
    _envres = build_env_resolver(merged["scopes"])
    for _h in hierarchies:
        _h["environment"] = _envres(_h.get("environment", ""))
        for _c in _h.get("children", []):
            _c["environment"] = _envres(_c.get("environment", ""))
    graph_findings = agent_graph_rules.evaluate(graph, blasts, pivots)
    inventory = build_inventory(all_desc, merged["scopes"], blasts,
                                graph=graph, coverage=_coverage(merged["scopes"]))
    attacks = build_attack_view(all_desc, graph)

    return {
        "descriptors": all_desc,
        "scopes": merged["scopes"],
        "errors": merged["errors"],
        "graph": graph.to_cytoscape(),
        "blast_radius": blasts,
        "cross_platform_pivots": pivots,
        "hierarchies": hierarchies,
        "graph_findings": graph_findings,
        "inventory": inventory,
        "attacks": attacks,
        "exports": {
            "ocsf_ndjson": cisco_ocsf.to_ocsf(all_desc, blasts),
            "ai_defense_context": cisco_ocsf.to_ai_defense_context(all_desc, blasts),
            "crowdstrike": crowdstrike.build(inventory, attacks),
        },
        "coverage": _coverage(merged["scopes"]),
    }


def _coverage(scopes: list[dict]) -> dict:
    read = [s for s in scopes if s.get("status") == "read"]
    skipped = [s for s in scopes if s.get("status") == "skipped"]
    errored = [s for s in scopes if s.get("status") == "error"]
    return {
        "read": len(read),
        "skipped": [{"kind": s.get("kind"), "reason": s.get("reason")} for s in skipped],
        "errored": len(errored),
        "blind": bool(skipped or errored),
    }

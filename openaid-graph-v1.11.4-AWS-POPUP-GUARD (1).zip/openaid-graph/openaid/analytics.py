"""Command Center analytics — the numbers admins show their boss.

Everything derives from data the app already collects:
  * Copilot transcript rows (bot_id + createdon) -> daily sessions series,
    week-over-week delta, busiest-hours heatmap, per-agent sparklines
  * inventory agents -> platform mix, adoption (created per month),
    environment league
  * hygiene report -> the governance score on the same screen

Pure functions; the demo synthesizer is deterministic so screenshots are
reproducible.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timedelta, timezone

DAYS = 14


def _parse(ts: str):
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except Exception:
        return None


def build(transcript_rows: list[dict], agents: list[dict],
          hygiene_score: int | None = None,
          foundry_tokens_total: int = 0,
          now: datetime | None = None) -> dict:
    """transcript_rows: [{bot_id, createdon}] over the last DAYS days."""
    now = now or datetime.now(timezone.utc)
    day0 = (now - timedelta(days=DAYS - 1)).date()

    daily = [0] * DAYS
    heat = [[0] * 24 for _ in range(7)]          # Mon..Sun x hour
    per_agent_daily: dict[str, list[int]] = {}
    for r in transcript_rows:
        t = _parse(r.get("createdon", ""))
        if t is None:
            continue
        idx = (t.date() - day0).days
        if not 0 <= idx < DAYS:
            continue
        daily[idx] += 1
        heat[t.weekday()][t.hour] += 1
        bid = (r.get("bot_id") or "").lower()
        if bid:
            per_agent_daily.setdefault(bid, [0] * DAYS)[idx] += 1

    this_week = sum(daily[-7:])
    prev_week = sum(daily[:7])
    delta_pct = (round(100 * (this_week - prev_week) / prev_week)
                 if prev_week else (100 if this_week else 0))

    by_id = {(a.get("native_id") or "").lower(): a for a in agents}
    by_id.update({(a.get("id") or "").lower(): a for a in agents})
    leaderboard = []
    for bid, series in per_agent_daily.items():
        a = by_id.get(bid, {})
        wk, pv = sum(series[-7:]), sum(series[:7])
        leaderboard.append({
            "name": a.get("name", bid[:8]), "id": a.get("id", bid),
            "platform": a.get("platform", "copilot_studio"),
            "environment": a.get("environment", ""),
            "sessions_7d": wk, "spark": series,
            "delta_pct": (round(100 * (wk - pv) / pv) if pv
                          else (100 if wk else 0)),
            "portal_url": a.get("portal_url", "")})
    leaderboard.sort(key=lambda x: -x["sessions_7d"])

    mix: dict[str, int] = {}
    for a in agents:
        mix[a.get("platform", "?")] = mix.get(a.get("platform", "?"), 0) + 1
    platform_mix = sorted(({"platform": k, "count": v} for k, v in mix.items()),
                          key=lambda x: -x["count"])

    env_league: dict[str, dict] = {}
    active_ids = {e["id"].lower() for e in leaderboard if e["sessions_7d"]}
    for a in agents:
        e = env_league.setdefault(a.get("environment") or "(unknown)",
                                  {"agents": 0, "active": 0, "sessions": 0})
        e["agents"] += 1
        if (a.get("id") or "").lower() in active_ids:
            e["active"] += 1
    for row in leaderboard:
        env_league.setdefault(row["environment"] or "(unknown)",
                              {"agents": 0, "active": 0, "sessions": 0}
                              )["sessions"] += row["sessions_7d"]
    environments = sorted(
        ({"environment": k, **v} for k, v in env_league.items()),
        key=lambda x: -x["sessions"])

    # adoption: agents created per month, last 6 months
    months: list[str] = []
    cur = now.replace(day=1)
    for _ in range(6):
        months.append(f"{cur:%Y-%m}")
        cur = (cur - timedelta(days=1)).replace(day=1)
    months.reverse()
    adoption = {m: 0 for m in months}
    for a in agents:
        c = _parse(a.get("created_on", ""))
        if c and f"{c:%Y-%m}" in adoption:
            adoption[f"{c:%Y-%m}"] += 1

    active_agents = sum(1 for r in leaderboard if r["sessions_7d"] > 0)
    return {
        "days": DAYS,
        "kpis": {"sessions_7d": this_week, "sessions_prev_7d": prev_week,
                 "delta_pct": delta_pct, "active_agents": active_agents,
                 "total_agents": len(agents),
                 "hygiene_score": hygiene_score,
                 "foundry_tokens_7d": foundry_tokens_total},
        "daily": daily,
        "heatmap": heat,
        "platform_mix": platform_mix,
        "leaderboard": leaderboard[:15],
        "environments": environments[:10],
        "adoption": [{"month": m, "created": adoption[m]} for m in months],
    }


def demo_rows(agents: list[dict], now: datetime | None = None) -> list[dict]:
    """Deterministic synthetic transcripts so demo mode looks alive."""
    now = (now or datetime.now(timezone.utc)).replace(second=0, microsecond=0)
    rows: list[dict] = []
    cs = [a for a in agents if a.get("platform") == "copilot_studio"]
    for a in cs:
        seed = int(hashlib.sha256(
            (a.get("id") or a.get("name", "")).encode()).hexdigest()[:8], 16)
        base = 2 + seed % 9
        for d in range(DAYS):
            day = now - timedelta(days=DAYS - 1 - d)
            n = base + ((seed >> (d % 16)) & 7) - (3 if day.weekday() >= 5 else 0)
            for i in range(max(0, n)):
                hour = (9 + (seed + i * 3 + d) % 9)      # office hours
                rows.append({"bot_id": (a.get("native_id") or a.get("id", "")).lower(),
                             "createdon": day.replace(
                                 hour=hour, minute=(i * 7) % 60
                             ).isoformat()})
    return rows

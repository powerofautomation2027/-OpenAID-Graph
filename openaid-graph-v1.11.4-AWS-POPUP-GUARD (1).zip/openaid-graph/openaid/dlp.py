"""DLP policy coverage — the Power Platform community's most persistent ask.

Every admin forum thread about agent governance eventually lands on the same
question: "which environments actually have a DLP policy, and which connectors
can my agents reach?" The admin center shows policies one at a time; nobody
shows you the INVERSE — the environments with NO policy, and the agents sitting
in them.

Source: BAP governance API
    GET /providers/PowerPlatform.Governance/v2/policies
Each policy carries connector groups (Business / Non-Business / Blocked) and
an environment scope (AllEnvironments, OnlyEnvironments, ExceptEnvironments).
"""
from __future__ import annotations

BAP = "https://api.bap.microsoft.com"
POLICY_API = f"{BAP}/providers/PowerPlatform.Governance/v2/policies?api-version=2020-10-01"

# connectors that hand an agent an outbound or untrusted-input channel
RISKY_CONNECTORS = (
    "http", "webhook", "sendmail", "outlook", "gmail", "smtp", "ftp",
    "sharepoint", "onedrive", "dropbox", "box", "sql", "dataverse",
    "twitter", "x", "facebook", "rss", "azureblob", "azurefile",
)


def fetch_policies(fetch, bap_token: str) -> tuple[list, list]:
    if not bap_token:
        return [], [{"scope": "dlp", "error": "no Power Platform token"}]
    try:
        j = fetch("GET", POLICY_API,
                  headers={"Authorization": f"Bearer {bap_token}"}) or {}
    except Exception as e:  # noqa: BLE001
        return [], [{"scope": "dlp", "error": str(e)[:200]}]
    return j.get("value", []) or [], []


def _scope_of(policy: dict) -> tuple[str, set]:
    env = policy.get("environments", {}) or {}
    kind = (policy.get("environmentType")
            or env.get("environmentType") or "AllEnvironments")
    names = set()
    for e in (env.get("environments") or policy.get("environments") or []):
        if isinstance(e, dict):
            n = e.get("name") or e.get("id", "")
            if n:
                names.add(str(n).rsplit("/", 1)[-1])
    return str(kind), names


def _connector_groups(policy: dict) -> dict:
    out = {"Business": [], "NonBusiness": [], "Blocked": []}
    for g in policy.get("connectorGroups", []) or []:
        cls = g.get("classification", "")
        key = ("Business" if cls.lower().startswith("gener") or cls == "Business"
               else "Blocked" if cls == "Blocked" else "NonBusiness")
        for c in g.get("connectors", []) or []:
            out[key].append(c.get("name") or c.get("id", ""))
    return out


def applies_to(policy: dict, env_id: str) -> bool:
    kind, names = _scope_of(policy)
    if kind == "AllEnvironments":
        return True
    if kind == "OnlyEnvironments":
        return env_id in names
    if kind == "ExceptEnvironments":
        return env_id not in names
    return False


def analyze(policies: list[dict], environments: list[dict],
            agents: list[dict] | None = None) -> dict:
    """environments: [{id,name}] ; agents: inventory rows (for exposure counts)."""
    agents = agents or []
    agents_by_env: dict[str, int] = {}
    for a in agents:
        k = a.get("environment_id") or a.get("environment") or ""
        agents_by_env[k] = agents_by_env.get(k, 0) + 1

    rows = []
    for env in environments:
        eid, ename = env.get("id", ""), env.get("name", env.get("id", ""))
        matched = [p for p in policies if applies_to(p, eid)]
        blocked, risky_allowed = set(), set()
        for p in matched:
            g = _connector_groups(p)
            blocked |= {str(c).lower() for c in g["Blocked"]}
            for c in g["Business"] + g["NonBusiness"]:
                cl = str(c).lower()
                if any(r in cl for r in RISKY_CONNECTORS):
                    risky_allowed.add(cl)
        n_agents = agents_by_env.get(eid, 0) or agents_by_env.get(ename, 0)
        rows.append({
            "environment": ename, "environment_id": eid,
            "policies": [p.get("displayName") or p.get("name", "?") for p in matched],
            "covered": bool(matched),
            "agents": n_agents,
            "blocked_connectors": len(blocked),
            "risky_allowed": sorted(risky_allowed)[:8],
            "risk": ("critical" if (not matched and n_agents)
                     else "high" if not matched
                     else "medium" if risky_allowed else "low"),
        })

    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    rows.sort(key=lambda r: (order[r["risk"]], -r["agents"]))
    uncovered = [r for r in rows if not r["covered"]]
    return {
        "rows": rows,
        "totals": {
            "environments": len(rows),
            "covered": len(rows) - len(uncovered),
            "uncovered": len(uncovered),
            "agents_without_dlp": sum(r["agents"] for r in uncovered),
            "coverage_pct": (round(100 * (len(rows) - len(uncovered)) / len(rows))
                             if rows else 0),
            "policies": len(policies),
        },
        "headline": (f"{len(uncovered)} environment(s) have no DLP policy, "
                     f"holding {sum(r['agents'] for r in uncovered)} agent(s)")
        if uncovered else "Every environment is covered by a DLP policy",
    }

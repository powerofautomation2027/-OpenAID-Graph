"""Remediation engine — turn findings into fixes.

Two layers:
* PLAYBOOKS — per-risk guidance: steps, exact commands, and the portal deep
  link, rendered in the UI drawer for agents, findings, and MCP servers.
* execute() — one-click fixes where a safe API write exists today:
    - copilot_require_auth : Dataverse PATCH bots(id) authenticationmode -> 2
                             (Authenticate with Microsoft)
    - copilot_disable      : Dataverse PATCH bots(id) statecode -> 1 (disable
                             the agent until it is secured)
  Everything else returns the guided playbook (no destructive automation).
"""
from __future__ import annotations

DV_API = "/api/data/v9.2"
PP_API = "https://api.powerplatform.com"

PLAYBOOKS: dict[str, dict] = {
    "orphaned_agent": {
        "title": "Agent has no owner",
        "risk": ("Nobody is accountable for this agent. Orphaned agents keep "
                 "live credentials, keep costing money, and nobody notices when "
                 "they misbehave."),
        "steps": [
            "Identify the right owner (team lead for the agent's business area).",
            "Reassign ownership with the button below, or in Copilot Studio.",
            "If no owner can be found, disable the agent until one is assigned.",
        ],
        "actions": [
            {"id": "copilot_reassign_owner", "label": "Fix now: reassign owner",
             "kind": "write", "platform": "copilot_studio", "needs": ["new_owner"]},
            {"id": "copilot_disable", "label": "Quarantine: disable agent",
             "kind": "write", "platform": "copilot_studio"},
        ],
    },
    "anonymous_agent": {
        "title": "Agent allows anonymous access",
        "risk": "Anyone with the link can drive this agent and everything it can reach.",
        "steps": [
            "Open the agent in Copilot Studio (button below).",
            "Settings > Security > Authentication.",
            "Switch from 'No authentication' to 'Authenticate with Microsoft' (or your provider).",
            "Publish the agent again.",
        ],
        "actions": [
            {"id": "copilot_require_auth", "label": "Fix now: require authentication",
             "kind": "write", "platform": "copilot_studio"},
            {"id": "copilot_disable", "label": "Quarantine: disable agent",
             "kind": "write", "platform": "copilot_studio"},
        ],
    },
    "high_blast_radius": {
        "title": "High blast radius",
        "risk": "Compromise of this agent reaches many resources/agents downstream.",
        "steps": [
            "Review the agent's connections and child/connected agents in the drawer.",
            "Remove unused connectors and knowledge sources.",
            "Split broad agents into narrower child agents with least privilege.",
            "Re-scan and confirm the blast score drops.",
        ],
        "actions": [],
    },
    "privilege_non_inheritance": {
        "title": "Connected agent holds broader access than its parent",
        "risk": "A delegated subagent can do things its caller was never granted.",
        "steps": [
            "Open the connected agent (portal link on its row).",
            "Review its identity's role assignments / connector permissions.",
            "Reduce to the minimum the parent scenario needs.",
        ],
        "actions": [],
    },
    "shared_identity": {
        "title": "Multiple agents share one identity",
        "risk": "One leaked credential exposes every agent using it.",
        "steps": [
            "Create a dedicated identity (managed identity / service principal) per agent.",
            "Rotate the shared credential after migration.",
        ],
        "actions": [],
    },
    "mcp_public": {
        "title": "MCP server publicly reachable",
        "risk": "A public MCP endpoint lets anyone invoke tools your agents trust.",
        "steps": [
            "Restrict ingress to internal (VNet) unless external access is required.",
            "Front it with authentication (built-in auth / API key / Entra).",
            "Re-scan: the Ingress column should show 'internal'.",
        ],
        "commands": [
            "az containerapp ingress update -n <APP> -g <RG> --type internal",
            "az containerapp auth microsoft update -n <APP> -g <RG> --client-id <APPID> --client-secret <SECRET> --tenant-id <TENANT>",
        ],
        "actions": [],
    },
    "mcp_no_auth": {
        "title": "MCP server has no authentication",
        "risk": "Any caller that can reach the endpoint can use every exposed tool.",
        "steps": [
            "Enable built-in authentication on the container app, or require an API key in the server.",
            "Give each calling agent its own credential — never share one key across platforms.",
        ],
        "commands": [
            "az containerapp auth update -n <APP> -g <RG> --unauthenticated-client-action Return401",
        ],
        "actions": [],
    },
    "cross_platform_pivot": {
        "title": "MCP server reachable from multiple platforms",
        "risk": "Compromise on one platform pivots into the other through this shared server.",
        "steps": [
            "Decide whether both platforms truly need this server.",
            "If yes: issue separate credentials per platform and log per-caller.",
            "If no: remove the extra platform's connection.",
        ],
        "actions": [],
    },
}


def playbook_for(rule: str) -> dict:
    return PLAYBOOKS.get(rule) or {
        "title": rule, "risk": "",
        "steps": ["Open the resource in its portal and review its configuration."],
        "actions": [],
    }


def execute(action: str, *, fetch, org_url: str = "", bot_id: str = "",
            dataverse_token: str = "", environment_id: str = "",
            new_owner: str = "", pp_token: str = "") -> dict:
    """Run a supported one-click fix. Returns {ok, action, detail}."""
    if action == "copilot_reassign_owner":
        # Documented Power Platform API (2026-05):
        # POST /copilotstudio/environments/{EnvironmentId}/bots/{BotId}
        #      /api/botAdminOperations/reassign?api-version=1
        # NOTE: classic chatbots return 405 Method Not Allowed.
        if not (environment_id and bot_id and new_owner):
            return {"ok": False, "action": action,
                    "detail": "need environment id, bot id and a new owner"}
        if not pp_token:
            return {"ok": False, "action": action,
                    "detail": "no Power Platform token (api.powerplatform.com)"}
        url = (f"{PP_API}/copilotstudio/environments/{environment_id}"
               f"/bots/{bot_id}/api/botAdminOperations/reassign?api-version=1")
        try:
            fetch("POST", url,
                  headers={"Authorization": f"Bearer {pp_token}",
                           "Content-Type": "application/json"},
                  json={"newOwnerId": new_owner})
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if "405" in msg:
                return {"ok": False, "action": action,
                        "detail": "classic chatbot — reassign API not supported"}
            return {"ok": False, "action": action, "detail": msg[:300]}
        return {"ok": True, "action": action,
                "detail": f"ownership reassigned to {new_owner}"}

    if action in ("copilot_require_auth", "copilot_disable"):
        if not (org_url and bot_id):
            return {"ok": False, "action": action,
                    "detail": "missing org_url/bot_id for this agent"}
        if not dataverse_token:
            return {"ok": False, "action": action,
                    "detail": "no Dataverse token — sign in or paste one in Connections"}
        hdr = {
            "Authorization": f"Bearer {dataverse_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
        }
        url = f"{org_url.rstrip('/')}{DV_API}/bots({bot_id})"
        body = ({"authenticationmode": 2} if action == "copilot_require_auth"
                else {"statecode": 1, "statuscode": 2})
        try:
            fetch("PATCH", url, headers=hdr, json=body)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "action": action, "detail": str(e)[:300]}
        done = ("authentication set to 'Authenticate with Microsoft' — republish the agent"
                if action == "copilot_require_auth" else
                "agent disabled (statecode=1) — re-enable after securing it")
        return {"ok": True, "action": action, "detail": done}
    return {"ok": False, "action": action, "detail": "unsupported action"}


# ---------------------------------------------------------------------------
# Per-agent security scan: everything wrong with ONE agent, plus the fixes
# that can actually be applied to it, in one place.
# ---------------------------------------------------------------------------

def scan_agent(agent: dict, findings: list[dict] | None = None,
               trifecta_row: dict | None = None) -> dict:
    """Return {agent, issues:[{rule,title,severity,why,actions,manual}]}.

    `actions` are one-click fixes valid for THIS agent's platform; `manual`
    holds the guided steps when no safe API write exists.
    """
    issues: list[dict] = []
    plat = agent.get("platform", "")
    rh_anon = bool(agent.get("anonymous"))
    blast = agent.get("blast_score", 0) or 0
    sev_of = lambda s: s  # noqa: E731

    def _add(rule, severity, why):
        pb = playbook_for(rule)
        acts = [a for a in pb.get("actions", []) if a.get("platform") in (None, plat)]
        issues.append({
            "rule": rule, "title": pb["title"], "severity": severity,
            "why": why or pb.get("risk", ""),
            "steps": pb.get("steps", []), "commands": pb.get("commands", []),
            "actions": acts,
            "fixable": bool(acts),
        })

    if not agent.get("owner_id") and plat == "copilot_studio":
        _add("orphaned_agent", "high",
             "No owner recorded — nobody is accountable for this agent.")

    if rh_anon:
        _add("anonymous_agent", "critical",
             "This agent accepts unauthenticated callers — anyone with the link "
             "can drive it and everything it can reach.")

    if blast >= 60:
        _add("high_blast_radius", "high",
             f"Blast score {blast}: a compromise here propagates widely.")

    # trifecta exposure is an issue in its own right
    if trifecta_row and trifecta_row.get("status") == "exploitable":
        rec = trifecta_row.get("recommendation") or {}
        issues.append({
            "rule": "lethal_trifecta", "title": "Exploitable by prompt injection",
            "severity": "critical",
            "why": ("Holds all three trifecta legs (private data + untrusted "
                    "content + external comms), so injected instructions can "
                    "complete a full exfiltration loop."),
            "steps": [rec.get("advice", "")] if rec.get("advice") else [],
            "commands": [],
            "actions": [a for a in playbook_for("anonymous_agent")["actions"]
                        if rh_anon and a.get("platform") in (None, plat)],
            "fixable": bool(rh_anon),
            "cut_leg": rec.get("label", ""),
        })

    for f in findings or []:
        if f.get("agent_id") and f["agent_id"] != agent.get("id"):
            continue
        rule = f.get("rule", "")
        if rule in {i["rule"] for i in issues} or rule not in PLAYBOOKS:
            continue
        _add(rule, f.get("severity", "medium"), f.get("detail", ""))

    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    issues.sort(key=lambda i: order.get(i["severity"], 5))
    fixable = sum(1 for i in issues if i["fixable"])
    return {
        "agent": {"id": agent.get("id", ""), "name": agent.get("name", "?"),
                  "platform": plat, "environment": agent.get("environment", ""),
                  "portal_url": agent.get("portal_url", ""),
                  "org_url": agent.get("org_url", ""),
                  "native_id": agent.get("native_id", "")},
        "issues": issues,
        "summary": {"total": len(issues), "one_click_fixable": fixable,
                    "critical": sum(1 for i in issues if i["severity"] == "critical")},
    }

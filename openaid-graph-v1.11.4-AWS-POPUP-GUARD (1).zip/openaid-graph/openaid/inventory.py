"""Build the inventory rollups the multi-tab UI renders.

Turns the flat descriptor list + scopes + blast ranking into:

* ``environments``  — every Power Platform environment, with agent counts
* ``subscriptions`` — every Azure subscription, with agent counts
* ``platforms``     — per-platform agent counts (for the dashboard)
* ``agents``        — one rich row per agent with ALL details the table shows
* ``stats``         — headline numbers for the dashboard tiles
"""
from __future__ import annotations


def build_env_resolver(scopes: list[dict]):
    """Return a function url/id/name -> friendly environment name, matching the
    exact logic used for agent rows so hierarchy cards and the dropdown agree."""
    def _norm(u: str) -> str:
        # collapse the Dataverse ".api" host variant so
        # org.api.crm.dynamics.com and org.crm.dynamics.com compare equal
        return str(u or "").rstrip("/").replace(".api.crm.dynamics.com",
                                                ".crm.dynamics.com").lower()
    friendly = {}
    for s in scopes:
        nm = s.get("name")
        if not nm:
            continue
        for key in (s.get("dataverse_url"), s.get("id"), s.get("endpoint")):
            if key:
                friendly[_norm(key)] = nm
    def resolve(raw: str) -> str:
        r = _norm(raw)
        if r in friendly:
            return friendly[r]
        for key, nm in friendly.items():
            if key and (key in r or r in key):
                return nm
        return raw
    return resolve


def _unique_envs(agents: list[dict]) -> list[dict]:
    """De-duplicated environment list for the dropdown. Keyed by a normalized
    name so 'Contoso' from an org-url row and 'Contoso' from an api-url row
    collapse to ONE option. Returns [{name,id}] sorted by name."""
    seen: dict[str, dict] = {}
    for a in agents:
        nm = (a.get("environment") or "").strip()
        if not nm or nm == "\u2014":
            continue
        key = nm.lower()
        if key not in seen:
            seen[key] = {"name": nm, "id": a.get("environment_id", "")}
        elif not seen[key]["id"] and a.get("environment_id"):
            seen[key]["id"] = a["environment_id"]
    return sorted(seen.values(), key=lambda e: e["name"].lower())


def _env_label(d: dict) -> str:
    sc = d.get("scope", {})
    return (sc.get("environment") or sc.get("dataverse") or sc.get("endpoint")
            or sc.get("instance") or sc.get("project") or sc.get("subscription")
            or sc.get("org") or "—")


def _resources(d: dict) -> list[str]:
    return [e.get("resource", "") for e in d.get("entitlements", []) if e.get("resource")]


def _with_tid(url: str) -> str:
    """Append &tid= to any Microsoft agent-portal link that lacks it.

    This deployment spans TWO directories, so ai.azure.com AND
    copilotstudio.microsoft.com both bounce to the wrong tenant's home when
    tid is absent — indistinguishable from a broken link. Applied centrally
    so every emitter benefits.
    """
    import os as _os
    if not url or "tid=" in url:
        return url
    # ONLY ai.azure.com: Microsoft's own Copilot Studio deepLinkUrl metadata
    # carries no tid, and an unknown query param is one more way for that
    # portal to bounce to home — so Copilot links stay clean.
    if "ai.azure.com" not in url:
        return url
    _tid = _os.getenv("OPENAID_TENANT_ID", "")
    if not _tid:
        return url
    return url + ("&" if "?" in url else "?") + f"tid={_tid}"


def _portal_link(d: dict) -> str:
    """Deep link to open the agent in its native portal."""
    ag = d["agent"]
    plat = ag.get("platform", "")
    nid = ag.get("native_id", "")
    sc = d.get("scope", {})
    # collectors now attach exact deep links (env/bot id, wsid) — always prefer
    direct = sc.get("portal_url") or d.get("risk_hints", {}).get("portal_url")
    if direct:
        return _with_tid(direct)
    if plat == "copilot_studio":
        # environment id + SCHEMA NAME is what the maker portal resolves
        env_id = sc.get("environment_id", "")
        # BotId GUID — the schema-name form 404s ("link is broken")
        if env_id and nid:
            # canonical current shape: /copilots/{botId}/details (no tid —
            # Microsoft's own deepLinkUrl metadata carries none)
            return (f"https://copilotstudio.microsoft.com/environments/"
                    f"{env_id}/copilots/{nid}/details")
        return "https://copilotstudio.microsoft.com/"
    if plat in ("azure_foundry",):
        # NEVER build a portal link from the DATA-PLANE host
        # (acct.services.ai.azure.com) — that is an API endpoint, not a page.
        # The portal is always ai.azure.com, addressed by ARM wsid.
        arm_id, proj = sc.get("arm_id", ""), sc.get("project", "")
        if arm_id and proj and nid:
            return _with_tid(f"https://ai.azure.com/build/agents/{nid}/build"
                             f"?wsid={arm_id}/projects/{proj}")
        if arm_id and proj:
            return _with_tid(f"https://ai.azure.com/build/overview?wsid={arm_id}/projects/{proj}")
        return "https://ai.azure.com/"
    if plat == "azure_openai":
        arm_id = sc.get("arm_id", "")
        return (f"https://ai.azure.com/resource/overview?wsid={arm_id}"
                if arm_id else "https://oai.azure.com/")
    if plat == "bedrock":
        return "https://console.aws.amazon.com/bedrock/home#/agents"
    if plat == "aws_q":
        return "https://console.aws.amazon.com/amazonq/"
    if plat in ("gcp_vertex", "gcp_agentspace"):
        return "https://console.cloud.google.com/vertex-ai/agents"
    if plat == "salesforce":
        return "https://login.salesforce.com/"
    if plat == "servicenow":
        return "https://www.servicenow.com/"
    if plat == "uipath":
        return "https://cloud.uipath.com/"
    if plat == "cisco":
        return "https://admin.webex.com/"
    return ""


def build_inventory(descriptors: list[dict], scopes: list[dict], blasts: list[dict],
                    graph=None, coverage: dict | None = None) -> dict:
    blast_by = {b["origin"]: b for b in blasts}

    # url/id -> friendly environment name, so agent rows and the dropdown use
    # the SAME value. Without this the dropdown shows "Contoso Prod" while the
    # agent row holds "https://contoso.crm.dynamics.com" and filtering matches
    # nothing.
    _resolve_env = build_env_resolver(scopes)

    def _env_of(d):
        return _resolve_env(_env_label(d))

    agents = []
    for d in descriptors:
        ag = d["agent"]
        rh = d.get("risk_hints", {})
        b = blast_by.get(d["id"], {})
        links = d.get("links", [])
        agents.append({
            "id": d["id"],
            "name": d.get("name", "?"),
            "platform": ag.get("platform", ""),
            "type": ag.get("agent_type", ""),
            "environment": _env_of(d),
            "environment_id": d.get("scope", {}).get("environment_id", "")
                              or d.get("scope", {}).get("subscription", ""),
            "identity_kind": d.get("identity", {}).get("kind", ""),
            "identity": d.get("identity", {}).get("principal", "")
                        or d.get("identity", {}).get("auth", ""),
            "anonymous": bool(rh.get("anonymous")),
            "resources": _resources(d),
            "child_count": sum(1 for l in links if l.get("rel") == "delegates_to"),
            "connected_count": sum(1 for l in links if l.get("rel") == "connects_to"),
            "calls_mcp": sum(1 for l in links if l.get("rel") == "calls_mcp"),
            "blast_score": b.get("score", 0),
            "blast_severity": b.get("severity", "low"),
            "unattended": bool(rh.get("unattended")),
            "portal_url": _portal_link(d),
            "native_id": d["agent"].get("native_id", ""),
            "org_url": d.get("scope", {}).get("dataverse", ""),
            "endpoint": d.get("scope", {}).get("endpoint", ""),
            "portal_candidates": d.get("scope", {}).get("portal_candidates", []),
            "modified_on": rh.get("modified_on", ""),
            "created_on": rh.get("created_on", ""),
            "statecode": rh.get("statecode"),
            "owner_id": rh.get("owner_id", ""),
        })
    agents.sort(key=lambda a: a["blast_score"], reverse=True)

    # environments (Power Platform) from scopes
    environments = []
    for s in scopes:
        if s.get("kind") == "powerplatform_env" and s.get("dataverse_url"):
            url = s.get("dataverse_url", "")
            name = s.get("name") or url
            # count by the SAME normalized label the agent rows carry
            n = sum(1 for a in agents if a["environment"] == name)
            environments.append({
                "id": s.get("id", ""), "name": name,
                "dataverse_url": url, "env_type": s.get("env_type", ""),
                "region": s.get("region", ""), "status": s.get("status", ""),
                "agents": n, "platform": "copilot_studio",
            })
        elif s.get("kind") == "foundry_project" and s.get("id"):
            # Azure AI Foundry projects are environments too — they must appear
            # in the environment dropdown alongside Power Platform environments.
            name = s.get("name") or s.get("id")
            n = sum(1 for a in agents if a["environment"] in (name, s.get("id")))
            environments.append({
                "id": s.get("id", ""), "name": name,
                "dataverse_url": "", "env_type": "Azure AI Foundry project",
                "region": "", "status": s.get("status", ""),
                "agents": n, "platform": "azure_foundry",
            })
    # if no explicit env scopes (demo), synthesize from copilot agents' environment label
    if not environments:
        seen = {}
        for a in agents:
            if a["platform"] == "copilot_studio":
                seen.setdefault(a["environment"], 0)
                seen[a["environment"]] += 1
        environments = [{"id": k, "name": k, "dataverse_url": k, "env_type": "",
                         "region": "", "status": "read", "agents": v}
                        for k, v in seen.items()]

    # subscriptions (Azure) from scopes
    # foundry agents carry scope.subscription now — count exactly, not by
    # substring of the environment label (which never matched, so subs showed 0)
    sub_agent_counts: dict = {}
    for d in descriptors:
        sid = d.get("scope", {}).get("subscription", "")
        if sid:
            sub_agent_counts[sid] = sub_agent_counts.get(sid, 0) + 1
    subscriptions = []
    for s in scopes:
        if s.get("kind") == "azure_subscription":
            sid = s.get("id", "")
            subscriptions.append({
                "id": sid, "name": s.get("name", "?"),
                "state": s.get("state", ""),
                "agents": sub_agent_counts.get(sid, 0),
                "portal_url": s.get("portal_url", ""),
            })
    if not subscriptions:
        seen = {}
        for a in agents:
            if a["platform"] in ("azure_foundry", "azure_openai"):
                seen.setdefault(a["environment"], 0)
                seen[a["environment"]] += 1
        subscriptions = [{"id": k, "name": k, "state": "Enabled", "agents": v}
                         for k, v in seen.items()]

    # platform rollup
    platforms = {}
    for a in agents:
        platforms.setdefault(a["platform"], 0)
        platforms[a["platform"]] += 1
    platform_list = sorted(({"platform": k, "count": v} for k, v in platforms.items()),
                           key=lambda x: x["count"], reverse=True)

    stats = {
        "agents": len(agents),
        "platforms": len(platform_list),
        "environments": len(environments),
        "subscriptions": len(subscriptions),
        "mcp_servers": sum(1 for d in descriptors if d["agent"].get("agent_type") == "mcp_server"),
        "rpa_robots": sum(1 for d in descriptors if d["agent"].get("agent_type") == "rpa_robot"),
        "child_agents": sum(a["child_count"] + a["connected_count"] for a in agents),
        "anonymous": sum(1 for a in agents if a["anonymous"]),
    }

    # MCP servers as identities + their callers (from the graph when available)
    mcp_servers = []
    identities = []
    if graph is not None:
        for n in graph.nodes.values():
            if n.kind == "mcp_server":
                callers = [graph.nodes[e.src] for e in graph.inn.get(n.id, [])
                           if graph.nodes.get(e.src)]
                caller_names = sorted({c.name for c in callers})
                caller_plats = sorted({c.platform for c in callers if c.platform})
                rh = n.meta.get("risk_hints", {})
                mcp_servers.append({
                    "id": n.id, "name": n.name,
                    "callers": caller_names, "caller_count": len(caller_names),
                    "platforms": caller_plats,
                    "public": bool(rh.get("public_ingress")),
                    "auth": rh.get("auth_declared", "unknown"),
                    "unresolved": bool(n.meta.get("unresolved")),
                })
            elif n.kind == "identity":
                users = [graph.nodes[e.src] for e in graph.inn.get(n.id, [])
                         if e.rel == "authenticates_as" and graph.nodes.get(e.src)]
                identities.append({
                    "id": n.id, "name": n.name,
                    "agents": sorted({u.name for u in users}),
                    "agent_count": len({u.name for u in users}),
                    "platforms": sorted({u.platform for u in users if u.platform}),
                    "shared": len({u.name for u in users}) >= 2,
                })
        mcp_servers.sort(key=lambda m: m["caller_count"], reverse=True)
        identities.sort(key=lambda i: i["agent_count"], reverse=True)

    return {
        "stats": stats,
        "platforms": platform_list,
        "environments": environments,
        # Dropdown source: derived from the agent rows themselves, so a selected
        # value ALWAYS matches at least one agent. Includes Foundry projects,
        # AWS accounts, etc. — not just Power Platform.
        "all_environments": _unique_envs(agents),
        "subscriptions": subscriptions,
        "agents": agents,
        "mcp_servers": mcp_servers,
        "identities": identities,
        "coverage": coverage or {},
    }

"""Minimal model shim for standalone operation.

The v0.2 collectors build descriptors via ``collectors._shared`` which already
falls back to a plain dict when ``openaid.model.new_descriptor`` is absent. This
module simply makes ``from openaid import model`` succeed and offers a light
validator, so the package stands on its own without the v0.1 codebase.
"""
from __future__ import annotations

REQUIRED_KEYS = ("id", "name", "agent")


def validate(descriptor: dict) -> bool:
    return all(k in descriptor for k in REQUIRED_KEYS) and \
        all(k in descriptor["agent"] for k in ("platform", "agent_type", "native_id"))

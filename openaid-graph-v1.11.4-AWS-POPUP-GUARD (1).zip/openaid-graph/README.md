# OpenAID Graph v0.2.1 — hierarchy fix release

## What was broken in v0.2 (why Child / Connected showed 0)
1. **Child agents were undetectable.** Real Copilot Studio child agents are
   `botcomponent` rows with `kind: AgentDialog` + `beginDialog: OnToolSelected`
   — they are NOT bots. v0.2 only detected agents by cross-referencing other
   bots' schema names, which can never match a child component. Fixed:
   AgentDialog YAML is now classified as a child and nested under its parent.
2. **Connected refs by GUID were missed.** InvokeConnectedAgent actions carry
   the target bot's GUID; now resolved to the real bot (word-boundary schema
   matching kept as a second signal).
3. **Link targets never matched graph nodes.** Links pointed at raw botids /
   Foundry agent ids, but node ids are `oaid:{platform}:{hash}` — every
   "resolved" connection silently rendered as a synthetic duplicate. Fixed:
   targets are descriptor ids via `_stable_id`.
4. **Foundry collector called a dead route.** Only
   `/assistants?api-version=2025-11-15-preview` was tried, which 404s on
   current Foundry resources. Now: `/agents?api-version=v1` →
   `2025-05-01` → legacy assistants fallback; accepts `value` or `data`.
5. **No portal links / no subscription attribution.** Agents, hierarchy rows,
   and subscriptions now carry deep links:
   - Copilot: `copilotstudio.microsoft.com/environments/{envId}/bots/{botId}/overview`
   - Foundry: `ai.azure.com/resource/agents/{id}?wsid={armAccountId}/projects/{project}`
   - Subscription: `portal.azure.com/#@/resource/subscriptions/{id}/overview`
   Foundry agents are attributed to their subscription, so the Environments &
   subscriptions tab shows real per-sub agent counts (was substring matching
   that never matched → always 0).
6. **DEPLOY.ps1 died on 32-bit az CLI.** `$ErrorActionPreference='Stop'`
   turned the harmless 32-bit-Python stderr warning into a terminating
   NativeCommandError. Now 'Continue' + explicit exit-code checks.

## Deploy (zero touch, 1 line)
```powershell
powershell -ExecutionPolicy Bypass -File .\DEPLOY.ps1
```
Reuses your existing Container Apps environment + ACR (auto-discovered),
builds in ACR with a unique tag, updates `ca-openaid-graph`.

Local demo (no Azure): `.\DEPLOY.ps1 -LocalOnly` → http://localhost:8000

## Verify after deploy
- UI → Child / Connected tab: parents with nested child (blue) / connected
  (orange) badges, ↗ opens the agent in its portal.
- `/api/diag` — token + per-scope status if anything shows 0.
- 0 children with no errors = your agents genuinely have none configured yet
  (Copilot Studio → open agent → Agents node → Add).

42 tests pass (`python -m pytest tests/test_v2.py -q`).

"""v0.2 tests. Offline: every collector gets a fake ``fetch`` that returns
canned JSON keyed by URL substring. No network, no cloud, deterministic.
"""
import pathlib
import pytest
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from openaid.collectors import (  # noqa: E402
    gcp_vertex, salesforce_agentforce, servicenow_agents, uipath_bots,
    webex_bots, mcp_servers,
)
from openaid.graph.trust_graph import TrustGraph  # noqa: E402
from openaid.exports import cisco_ocsf  # noqa: E402
from openaid.risk import agent_graph_rules  # noqa: E402
from openaid import discover_v2  # noqa: E402


def make_fetch(routes):
    """routes: list of (substring, payload). First match wins."""
    def fetch(method, url, **kw):
        for sub, payload in routes:
            if sub in url:
                return payload
        raise RuntimeError(f"no route for {url}")
    return fetch


# ---------------------------------------------------------------- collectors
def test_gcp_skips_without_projects(monkeypatch):
    monkeypatch.delenv("OPENAID_GCP_PROJECTS", raising=False)
    r = gcp_vertex.collect(make_fetch([]), token="t")
    assert r["descriptors"] == []
    assert r["scopes"][0]["status"] == "skipped"


def test_gcp_reads_engines_and_reasoning_engines():
    routes = [
        ("collections/default_collection/engines", {"engines": [
            {"name": "projects/p/locations/global/collections/default_collection/engines/e1",
             "displayName": "Support Agent",
             "commonConfig": {"serviceAccount": "sa@p.iam.gserviceaccount.com"},
             "dataStoreIds": ["kb1"]}]}),
        ("reasoningEngines", {"reasoningEngines": [
            {"name": "projects/p/locations/global/reasoningEngines/r1",
             "displayName": "Planner", "serviceAccount": "planner@p.iam"}]}),
    ]
    r = gcp_vertex.collect(make_fetch(routes), token="t", projects=["p"], locations=["global"])
    types = {d["agent"]["agent_type"] for d in r["descriptors"]}
    assert types == {"agent_builder_gcp", "reasoning_engine"}
    ab = [d for d in r["descriptors"] if d["agent"]["agent_type"] == "agent_builder_gcp"][0]
    assert any(l["rel"] == "authenticates_as" for l in ab["links"])
    assert any(l["rel"] == "reads" for l in ab["links"])


def test_salesforce_classifies_agentforce_vs_bot():
    routes = [
        ("BotDefinition", {"records": [
            {"Id": "b1", "DeveloperName": "svc", "MasterLabel": "Service Agent",
             "BotUserId": "u1", "Type": "Agent"},
            {"Id": "b2", "DeveloperName": "faq", "MasterLabel": "FAQ Bot",
             "BotUserId": "u2", "Type": "Chatbot"}]}),
        ("GenAiPlugin", {"records": [{"Id": "p1", "DeveloperName": "LookupOrder"}]}),
    ]
    r = salesforce_agentforce.collect(make_fetch(routes), token="t", instance_url="https://x.my.salesforce.com")
    types = {d["agent"]["agent_type"] for d in r["descriptors"]}
    assert types == {"agentforce", "einstein_bot"}
    af = [d for d in r["descriptors"] if d["agent"]["agent_type"] == "agentforce"][0]
    assert any(l["rel"] == "invokes" for l in af["links"])
    assert any(l["rel"] == "authenticates_as" for l in af["links"])


def test_servicenow_maps_mcp_tool_to_calls_mcp():
    routes = [
        ("sn_aia_agent", {"result": [
            {"sys_id": "a1", "name": "Incident Agent", "run_as": "svc.aia", "active": "true"}]}),
        ("sn_aia_tool", {"result": [
            {"sys_id": "t1", "name": "kb_search", "agent": "a1", "type": "retriever"},
            {"sys_id": "t2", "name": "remote", "agent": "a1", "type": "mcp",
             "endpoint": "https://mcp.example.com/mcp"}]}),
    ]
    r = servicenow_agents.collect(make_fetch(routes), token="t", instance="https://x.service-now.com")
    d = r["descriptors"][0]
    rels = {l["rel"] for l in d["links"]}
    assert "calls_mcp" in rels
    assert any(l["target"] == "https://mcp.example.com/mcp" for l in d["links"])


def test_uipath_flags_unattended_and_credentials():
    routes = [
        ("Robots", {"value": [
            {"Id": 1, "Name": "FinanceBot", "Type": "Unattended",
             "Username": "corp\\svc_fin", "MachineName": "RPA01"}]}),
        ("Assets", {"value": [
            {"Name": "SapCred", "ValueType": "Credential"},
            {"Name": "Timeout", "ValueType": "Integer"}]}),
        ("Releases", {"value": [{"ProcessKey": "InvoicePosting", "Name": "Invoice"}]}),
    ]
    r = uipath_bots.collect(make_fetch(routes), token="t", base_url="https://cloud.uipath.com/o/t/orchestrator_")
    d = r["descriptors"][0]
    assert d["risk_hints"]["unattended"] is True
    assert d["risk_hints"]["credential_assets"] == 1
    assert any(l["rel"] == "invokes" for l in d["links"])


def test_webex_reads_bots_and_integrations():
    routes = [
        ("people?type=bot", {"items": [
            {"id": "botid", "displayName": "DeployBot", "emails": ["deploy@webex.bot"], "orgId": "org1"}]}),
        ("applications", {"items": [
            {"friendlyName": "CI Integration", "id": "app1", "scopes": ["spark:messages_write"]}]}),
    ]
    r = webex_bots.collect(make_fetch(routes), token="t")
    types = {d["agent"]["agent_type"] for d in r["descriptors"]}
    assert types == {"webex_bot", "webex_integration"}


def test_webex_skips_without_token():
    r = webex_bots.collect(make_fetch([]), token=None)
    assert r["scopes"][0]["status"] == "skipped"


# --------------------------------------------------------------- MCP servers
def test_mcp_container_apps_detects_tagged_app():
    routes = [("containerApps", {"value": [
        {"name": "spoherocobaby", "tags": {"mcp": "true", "mcp-auth": "entra"},
         "identity": {"type": "SystemAssigned", "principalId": "pid1"},
         "properties": {"configuration": {"ingress": {"fqdn": "ca-mcp.eastus.azurecontainerapps.io"}}},
         "id": "/subscriptions/s1/.../spoherocobaby"},
        {"name": "not-mcp", "tags": {},
         "properties": {"configuration": {"ingress": {"fqdn": "x.io"}}}}]})]
    r = mcp_servers.collect_azure_container_apps(make_fetch(routes), "tok", ["s1"])
    assert len(r["descriptors"]) == 1
    assert r["descriptors"][0]["agent"]["agent_type"] == "mcp_server"


class _FakeAgentCore:
    def list_gateways(self):
        return {"items": [{"gatewayId": "gw1", "name": "gw", "gatewayUrl": "https://gw/mcp",
                           "roleArn": "arn:aws:iam::1:role/gw"}]}

    def list_gateway_targets(self, gatewayIdentifier):
        return {"items": [{"name": "jira", "credentialProviderType": "OAUTH",
                           "targetConfiguration": {"mcp": {"endpoint": "https://gw/mcp/jira"}}}]}


def test_mcp_agentcore_gateway():
    r = mcp_servers.collect_agentcore_gateways(_FakeAgentCore())
    assert r["descriptors"][0]["agent"]["agent_type"] == "mcp_server"
    assert r["descriptors"][0]["identity"]["kind"] == "iam_role"


def test_mcp_merge_dedups_by_endpoint():
    a = mcp_servers._desc("x", "https://h/mcp", "azure_container_apps", {"principal": ""})
    b = mcp_servers._desc("x", "https://h/mcp/", "bedrock_agentcore_gateway", {"principal": "arn"})
    merged = mcp_servers.merge(mcp_servers.report([a]), mcp_servers.report([b]))
    assert len(merged["descriptors"]) == 1
    assert merged["descriptors"][0]["identity"]["principal"] == "arn"


# --------------------------------------------------------------------- graph
def _fleet():
    """A small cross-platform fleet with a shared MCP and an RPA robot."""
    mcp = {"id": "oaid:mcp:1", "name": "SharePoint MCP",
           "agent": {"platform": "mcp", "agent_type": "mcp_server", "native_id": "h/mcp"},
           "endpoints": [{"url": "https://h/mcp"}],
           "entitlements": [{"resource": "sharepoint:sites", "actions": ["read", "write"]}],
           "risk_hints": {"public_ingress": True, "auth_declared": "unknown"}, "links": []}
    copilot = {"id": "oaid:cp:1", "name": "HR Copilot",
               "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio", "native_id": "hr"},
               "entitlements": [{"resource": "dataverse:contacts", "actions": ["read"]}],
               "links": [{"rel": "calls_mcp", "target": "https://h/mcp"},
                         {"rel": "authenticates_as", "target": "mi:shared"}]}
    bedrock = {"id": "oaid:br:1", "name": "Ops Agent",
               "agent": {"platform": "bedrock", "agent_type": "bedrock_agent", "native_id": "ops"},
               "entitlements": [{"resource": "s3:secrets-bucket", "actions": ["read"]}],
               "links": [{"rel": "calls_mcp", "target": "https://h/mcp"},
                         {"rel": "authenticates_as", "target": "mi:shared"}]}
    robot = {"id": "oaid:rpa:1", "name": "FinanceBot",
             "agent": {"platform": "uipath", "agent_type": "rpa_robot", "native_id": "fin"},
             "entitlements": [{"resource": "uipath:asset:SapCred", "actions": ["read"]}],
             "risk_hints": {"credential_assets": 1}, "links": []}
    salesforce = {"id": "oaid:sf:1", "name": "Service Agent",
                  "agent": {"platform": "salesforce", "agent_type": "agentforce", "native_id": "svc"},
                  "entitlements": [{"resource": "salesforce:crm", "actions": ["read", "write"]}],
                  "links": [{"rel": "invokes", "target": "oaid:rpa:1"},
                            {"rel": "authenticates_as", "target": "mi:shared"}]}
    return [mcp, copilot, bedrock, robot, salesforce]


def test_graph_resolves_calls_mcp_to_real_node():
    g = TrustGraph.from_descriptors(_fleet())
    # copilot -> the real MCP node, not a synthetic one
    edges = g.out["oaid:cp:1"]
    assert any(e.dst == "oaid:mcp:1" and e.rel == "calls_mcp" for e in edges)


def test_blast_radius_scores_and_bands():
    g = TrustGraph.from_descriptors(_fleet())
    b = g.blast_radius("oaid:cp:1")
    assert b["reachable_total"] > 0
    assert b["severity"] in ("low", "medium", "high", "critical")
    # copilot reaches the MCP which reaches sharepoint (sensitive)
    assert "sharepoint:sites" in b["sensitive_resources"]


def test_cross_platform_pivot_detected():
    g = TrustGraph.from_descriptors(_fleet())
    pivots = g.cross_platform_pivots()
    assert pivots, "shared MCP reachable from copilot_studio + bedrock should surface"
    shared = pivots[0]["shared_by"]
    assert "copilot_studio" in shared and "bedrock" in shared


def test_identity_fan_in_rule_fires():
    g = TrustGraph.from_descriptors(_fleet())
    blasts = g.rank_blast()
    findings = agent_graph_rules.evaluate(g, blasts, g.cross_platform_pivots())
    rules = {f["rule"] for f in findings}
    assert "OAID-G006" in rules  # mi:shared used by 3 agents
    assert "OAID-G002" in rules  # cross-platform pivot
    assert "OAID-G004" in rules  # salesforce -> rpa robot


def test_rank_blast_orders_descending():
    g = TrustGraph.from_descriptors(_fleet())
    ranked = g.rank_blast()
    scores = [r["score"] for r in ranked]
    assert scores == sorted(scores, reverse=True)


# ------------------------------------------------------------------ exports
def test_ocsf_export_is_ndjson_with_risk_score():
    desc = _fleet()
    g = TrustGraph.from_descriptors(desc)
    blasts = g.rank_blast()
    out = cisco_ocsf.to_ocsf(desc, blasts)
    lines = [l for l in out.splitlines() if l]
    assert lines
    ev = json.loads(lines[0])
    assert ev["class_uid"] == 2004
    assert "risk_score" in ev


def test_ai_defense_context_has_blast_and_owner():
    desc = _fleet()
    g = TrustGraph.from_descriptors(desc)
    blasts = g.rank_blast()
    ctx = json.loads(cisco_ocsf.to_ai_defense_context(desc, blasts))
    assert ctx["schema"] == "openaid.ai_defense_context.v1"
    cp = [a for a in ctx["assets"] if a["asset_id"] == "oaid:cp:1"][0]
    assert cp["owner_identity"] == "mi:shared"
    assert cp["blast_severity"] in ("low", "medium", "high", "critical")


# --------------------------------------------------------------- orchestrator
def test_orchestrator_runs_offline_and_reports_coverage():
    # nothing configured -> everything skips, coverage honest, no crash
    r = discover_v2.discover(make_fetch([]), tokens={}, config={})
    assert r["coverage"]["blind"] is True
    assert isinstance(r["graph_findings"], list)
    assert "ocsf_ndjson" in r["exports"]


def test_orchestrator_folds_in_existing_descriptors():
    r = discover_v2.discover(make_fetch([]), existing_descriptors=_fleet(), tokens={}, config={})
    assert any(f["rule"] == "OAID-G002" for f in r["graph_findings"])
    assert r["blast_radius"]


# --------------------------------------------------- hierarchy (child agents)
from openaid.collectors import copilot_studio, foundry_agents  # noqa: E402
from openaid.collectors._shared import _stable_id  # noqa: E402


def test_copilot_emits_child_and_connected_links():
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [
                {"botid": "p1", "name": "Main", "schemaname": "main", "authenticationmode": 1},
                {"botid": "c1", "name": "Child One", "schemaname": "child1", "authenticationmode": 2}]}
        if "botcomponents?" in url:
            return {"value": [
                {"botcomponentid": "x1", "name": "child ref", "schemaname": "child1",
                 "componenttype": "connectedagent", "_parentbotid_value": "p1"}]}
        return {}
    r = copilot_studio.collect(fetch, token="t", dataverse_urls=["https://org.crm.dynamics.com"])
    main = [d for d in r["descriptors"] if d["name"] == "Main"][0]
    # child1 is an inventoried bot -> resolves to a connects_to edge whose
    # target is the DESCRIPTOR id (raw botids never match a graph node)
    tgt = _stable_id("copilot_studio", "c1")
    assert any(l["rel"] == "connects_to" and l["target"] == tgt for l in main["links"])
    assert main["risk_hints"]["anonymous"] is True  # authmode 1 == no auth


def test_foundry_emits_delegates_to_from_connected_agent_tool():
    routes = [("assistants", {"data": [
        {"id": "a-main", "name": "Orchestrator", "model": "gpt-4o",
         "tools": [{"type": "connected_agent", "connected_agent": {"name": "Analyst"}}]},
        {"id": "a-sub", "name": "Analyst", "model": "gpt-4o",
         "metadata": {"agent_identity": "sub-id-123"}}]})]
    r = foundry_agents.collect(make_fetch(routes), token="t", endpoints=["https://proj.services.ai.azure.com"])
    main = [d for d in r["descriptors"] if d["name"] == "Orchestrator"][0]
    tgt = _stable_id("azure_foundry", "a-sub")
    assert any(l["rel"] == "connects_to" and l["target"] == tgt for l in main["links"])
    sub = [d for d in r["descriptors"] if d["name"] == "Analyst"][0]
    assert sub["risk_hints"]["has_own_identity"] is True


def test_graph_hierarchies_nests_children_under_parent():
    from openaid.sample_fleet import sample_descriptors
    g = TrustGraph.from_descriptors(sample_descriptors())
    hs = {h["parent_name"]: h for h in g.hierarchies()}
    assert "IT Helpdesk (main)" in hs
    kinds = {c["type"] for c in hs["IT Helpdesk (main)"]["children"]}
    assert kinds == {"child", "connected"}
    assert "Research Orchestrator (Foundry)" in hs


def test_hierarchy_rules_fire():
    from openaid.sample_fleet import sample_descriptors
    g = TrustGraph.from_descriptors(sample_descriptors())
    blasts = g.rank_blast()
    findings = agent_graph_rules.evaluate(g, blasts, g.cross_platform_pivots())
    rules = {f["rule"] for f in findings}
    assert "OAID-G007" in rules   # Foundry subagent out-privileges parent (s3/sql)
    assert "OAID-G010" in rules   # anonymous Copilot parent drives children


def test_orchestrator_includes_hierarchies():
    r = discover_v2.discover(make_fetch([]), existing_descriptors=_fleet(), tokens={}, config={})
    assert "hierarchies" in r


def test_attack_view_maps_owasp_and_paths():
    from openaid.sample_fleet import sample_descriptors
    from openaid.attacks import build_attack_view
    g = TrustGraph.from_descriptors(sample_descriptors())
    av = build_attack_view(sample_descriptors(), g)
    ids = {t["id"] for t in av["techniques"]}
    assert "ASI01" in ids and "ASI10" in ids  # full ASI catalog present
    # at least one agent exposed, and at least one attack path to a sensitive store
    assert av["agents"] and av["agents"][0]["exposure"] > 0
    assert av["paths"], "expected an anonymous->sensitive attack path"


def test_auth_module_demo_mode(monkeypatch):
    monkeypatch.delenv("OPENAID_CLIENT_ID", raising=False)
    from openaid import auth
    assert auth.configured() is False
    r = auth.start_device_flow()
    assert r["ok"] is False and "not configured" in r["error"].lower()
    st = auth.status()
    assert st["signed_in"] is False and st["configured"] is False


def test_global_discovery_lists_envs_without_bap():
    from openaid.collectors import dataverse_discovery
    def fetch(method, url, **kw):
        assert "globaldisco" in url
        return {"value": [{"ApiUrl": "https://org.api.crm.dynamics.com",
                           "FriendlyName": "Org", "Id": "e1"}]}
    rep, urls, index = dataverse_discovery.collect(fetch, token="t")
    assert urls == ["https://org.api.crm.dynamics.com"]
    assert index["https://org.api.crm.dynamics.com"]["name"] == "Org"


def test_copilot_detects_connected_agents_from_component_data():
    """Connected/child agents are referenced inside botcomponent.data (YAML/JSON),
    not by a component-type name — detect by cross-reference, ignore topics."""
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [
                {"botid": "b1", "name": "Main", "schemaname": "cr_main", "authenticationmode": 1},
                {"botid": "b2", "name": "Sub One", "schemaname": "cr_sub1", "authenticationmode": 2}]}
        if "botcomponents?" in url:
            return {"value": [
                {"botcomponentid": "c1", "name": "gpt", "schemaname": "cr_gpt",
                 "componenttype": 15, "_parentbotid_value": "b1",
                 "data": "kind: CustomGPT\nagents:\n  - cr_sub1\n"},
                {"botcomponentid": "c2", "name": "topic", "schemaname": "cr_t",
                 "componenttype": 0, "_parentbotid_value": "b1", "data": "kind: Topic"}]}
        return {}
    r = copilot_studio.collect(fetch, token="t", dataverse_urls=["https://org.crm.dynamics.com"])
    main = [d for d in r["descriptors"] if d["name"] == "Main"][0]
    links = [(l["rel"], l["target"]) for l in main["links"]]
    assert ("connects_to", _stable_id("copilot_studio", "b2")) in links
    assert len(links) == 1  # the plain topic must NOT create a link


def test_env_dropdown_values_always_match_agent_rows():
    """Regression: the dropdown listed friendly names while agent rows held raw
    Dataverse URLs, so selecting an environment showed zero agents."""
    from openaid.inventory import build_inventory
    descriptors = [{
        "id": "a1", "name": "Agent One",
        "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent"},
        "scope": {"kind": "copilot_environment", "dataverse": "https://contoso.crm.dynamics.com"},
    }]
    scopes = [{"kind": "powerplatform_env", "id": "e1", "name": "Contoso Prod",
               "dataverse_url": "https://contoso.crm.dynamics.com", "status": "read"}]
    inv = build_inventory(descriptors, scopes, [])
    # agent row carries the friendly name, not the URL
    assert inv["agents"][0]["environment"] == "Contoso Prod"
    # all_environments is now a de-duplicated [{name,id}] list, and every
    # option's NAME matches at least one agent row
    for env in inv["all_environments"]:
        assert isinstance(env, dict) and "name" in env
        assert [a for a in inv["agents"] if a["environment"] == env["name"]]
    assert inv["environments"][0]["agents"] == 1


def test_all_environments_never_duplicates_a_value():
    from openaid.inventory import build_inventory
    # two agents in the SAME env, reached via org-url and api-url variants
    descriptors = [
        {"id": "a1", "name": "A1", "agent": {"platform": "copilot_studio", "agent_type": "x"},
         "scope": {"kind": "copilot_environment", "environment": "Contoso Prod",
                   "environment_id": "env-1"}},
        {"id": "a2", "name": "A2", "agent": {"platform": "copilot_studio", "agent_type": "x"},
         "scope": {"kind": "copilot_environment", "environment": "Contoso Prod",
                   "environment_id": "env-1"}},
    ]
    inv = build_inventory(descriptors, [], [])
    names = [e["name"] for e in inv["all_environments"]]
    assert names == ["Contoso Prod"]          # exactly one, not two
    assert inv["all_environments"][0]["id"] == "env-1"


def test_device_flow_scopes_exclude_msal_reserved_scopes():
    """MSAL raises ValueError if openid/profile/offline_access are passed in —
    it adds them itself. Regression: sign-in failed with 'You cannot use any
    scope value that is reserved'."""
    import inspect
    from openaid import auth
    src = inspect.getsource(auth.start_device_flow)
    call = src[src.find("initiate_device_flow"):src.find("initiate_device_flow") + 250]
    for reserved in ("openid", "offline_access", "profile"):
        assert f"'{reserved}'" not in call and f'"{reserved}"' not in call, \
            f"reserved scope {reserved} must not be passed to initiate_device_flow"


def test_crowdstrike_export_shapes():
    from openaid.sample_fleet import sample_descriptors
    from openaid.attacks import build_attack_view
    from openaid.inventory import build_inventory
    from openaid.exports import crowdstrike
    import json as _json
    desc = sample_descriptors()
    g = TrustGraph.from_descriptors(desc)
    blasts = g.rank_blast(top=50)
    inv = build_inventory(desc, [], blasts, graph=g)
    atk = build_attack_view(desc, g)
    out = crowdstrike.build(inv, atk)
    lines = [l for l in out["falcon_ngsiem_ndjson"].splitlines() if l.strip()]
    assert lines, "expected Falcon events"
    ev = _json.loads(lines[0])
    assert ev["#event_simpleName"] == "AiAgentIdentity"
    assert "BlastRadiusScore" in ev and "OwaspAgenticTechniques" in ev
    assert any(_json.loads(l)["#event_simpleName"] == "AiAgentAttackPath" for l in lines)
    for ioc in out["falcon_iocs"]:
        assert ioc["type"] == "domain" and ioc["action"] == "detect"


def test_copilot_no_false_children_from_mcp_or_common_names():
    """Regression: matching bot *display names* as substrings made every
    component containing a common word (e.g. an agent named "Agent") a child of
    every agent, and MCP tool components were mislabelled as child agents."""
    def fetch(method, url, **kw):
        if "bots?" in url and "expand" in url:
            return {"value": []}
        if "bots?" in url:
            return {"value": [
                {"botid": "b1", "name": "Parent", "schemaname": "cr_parent", "authenticationmode": 2},
                {"botid": "b2", "name": "Agent", "schemaname": "cr_generic", "authenticationmode": 2},
                {"botid": "b3", "name": "Real Child", "schemaname": "cr_realchild", "authenticationmode": 2}]}
        if "botcomponents?" in url:
            return {"value": [
                {"botcomponentid": "c1", "schemaname": "cr_mcp", "componenttype": 15,
                 "_parentbotid_value": "b1",
                 "data": "kind: InvokeExternalAgentTaskAction\nserverUrl: https://mcp.example.com/mcp"},
                {"botcomponentid": "c2", "schemaname": "cr_greet", "componenttype": 0,
                 "_parentbotid_value": "b1", "data": "kind: Topic\nmessage: I am an Agent"},
                {"botcomponentid": "c3", "schemaname": "cr_conn", "componenttype": 15,
                 "_parentbotid_value": "b1", "data": "kind: CustomGPT\nagents:\n  - cr_realchild\n"}]}
        return {}
    r = copilot_studio.collect(fetch, token="t", dataverse_urls=["https://org.crm.dynamics.com"])
    parent = [d for d in r["descriptors"] if d["name"] == "Parent"][0]
    kids = [l for l in parent["links"] if l["rel"] in ("delegates_to", "connects_to")]
    mcp = [l for l in parent["links"] if l["rel"] == "calls_mcp"]
    assert [k["label"] for k in kids] == ["Real Child"]
    assert len(mcp) == 1 and mcp[0]["target"].startswith("https://")


def test_drift_detects_shadow_agents_and_privilege_growth():
    from openaid import drift
    drift._snapshots.clear()
    drift.record({"agents": [{"id": "a1", "name": "A", "platform": "copilot_studio",
                              "environment": "prod", "anonymous": False, "blast_score": 20,
                              "resources": ["r1"], "child_count": 0, "connected_count": 0,
                              "calls_mcp": 0}]})
    drift.record({"agents": [
        {"id": "a1", "name": "A", "platform": "copilot_studio", "environment": "prod",
         "anonymous": True, "blast_score": 60, "resources": ["r1", "r2"],
         "child_count": 1, "connected_count": 0, "calls_mcp": 0},
        {"id": "a2", "name": "Shadow", "platform": "copilot_studio", "environment": "dev",
         "anonymous": False, "blast_score": 5, "resources": [], "child_count": 0,
         "connected_count": 0, "calls_mcp": 0}]})
    d = drift.diff()
    kinds = {c["kind"] for c in d["changes"]}
    assert "became_anonymous" in kinds and "new_agent" in kinds
    assert "new_resource_access" in kinds and "blast_radius_increase" in kinds
    assert d["changes"][0]["severity"] == "critical"  # anonymous ranks first


def test_copilot_uses_correct_expand_relationship_name():
    """Regression: the bot->components relationship is `botcomponent_parent_bot`.
    Using `bot_botcomponent` returns bots with no components, so children were
    silently zero."""
    def fetch(method, url, **kw):
        if "bot_botcomponent" in url:
            raise Exception("Could not find a property named 'bot_botcomponent'")
        if "botcomponent_parent_bot" in url:
            return {"value": [{"botid": "b1", "botcomponent_parent_bot": [
                {"botcomponentid": "c1", "schemaname": "cr_gpt", "componenttype": 15,
                 "data": "kind: CustomGPT\nconnectedAgents:\n  - cr_lookup\n"}]}]}
        if "bots?" in url:
            return {"value": [
                {"botid": "b1", "name": "Parent", "schemaname": "cr_parent", "authenticationmode": 2},
                {"botid": "b2", "name": "Lookup", "schemaname": "cr_lookup", "authenticationmode": 2}]}
        return {}
    r = copilot_studio.collect(fetch, token="t", dataverse_urls=["https://org.crm.dynamics.com"])
    parent = [d for d in r["descriptors"] if d["name"] == "Parent"][0]
    kids = [l for l in parent["links"] if l["rel"] in ("delegates_to", "connects_to")]
    assert [k["label"] for k in kids] == ["Lookup"]


def test_foundry_discovery_not_limited_by_account_kind():
    """Regression: filtering accounts to kind in (AIServices, OpenAI) and
    hardcoding project name 'default' missed real Foundry projects."""
    from openaid.collectors import foundry_discovery
    def fetch(method, url, **kw):
        if "CognitiveServices/accounts?" in url:
            return {"value": [{
                "name": "power-2089-resource", "kind": "CognitiveServices",
                "id": "/subscriptions/s1/resourceGroups/rg-x/providers/"
                      "Microsoft.CognitiveServices/accounts/power-2089-resource",
                "properties": {"endpoint": "https://power-2089-resource.services.ai.azure.com/"}}]}
        if "/projects?" in url:
            return {"value": [{"name": "power-2089-resource/power-2089"}]}
        return {}
    _rep, eps, meta = foundry_discovery.collect(fetch, token="t", subscription_ids=["s1"])
    assert eps == ["https://power-2089-resource.services.ai.azure.com/api/projects/power-2089"]
    m = meta[eps[0]]
    assert m["project"] == "power-2089" and m["subscription_id"] == "s1"
    assert m["arm_id"].endswith("/accounts/power-2089-resource")


# ------------------------------------------- v0.2.1 hierarchy-fix regressions
def test_copilot_detects_true_child_agents_from_agentdialog_yaml():
    """Root cause of 'Child / Connected (0)': REAL child agents are
    botcomponents with kind: AgentDialog + beginDialog OnToolSelected — they
    are NOT bots, so schema-name cross-referencing can never find them."""
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [
                {"botid": "p1", "name": "Parent", "schemaname": "cr_parent",
                 "authenticationmode": 2}]}
        if "botcomponents?" in url:
            return {"value": [
                {"botcomponentid": "k1", "name": "Order Lookup",
                 "schemaname": "cr_child", "componenttype": 9,
                 "_parentbotid_value": "p1",
                 "data": "kind: AgentDialog\nbeginDialog:\n  kind: OnToolSelected\n"}]}
        return {}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"])
    parent = [d for d in r["descriptors"] if d["name"] == "Parent"][0]
    kids = [l for l in parent["links"] if l["rel"] == "delegates_to"]
    assert len(kids) == 1
    assert kids[0]["kind"] == "child"
    assert kids[0]["label"] == "Order Lookup"
    assert parent["risk_hints"]["child_count"] == 1


def test_copilot_connected_by_guid_reference():
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [
                {"botid": "11111111-2222-3333-4444-555555555555", "name": "Main",
                 "schemaname": "cr_main", "authenticationmode": 2},
                {"botid": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", "name": "Lookup",
                 "schemaname": "cr_lookup", "authenticationmode": 2}]}
        if "botcomponents?" in url:
            return {"value": [
                {"botcomponentid": "c1", "name": "conn", "schemaname": "cr_c",
                 "componenttype": 15,
                 "_parentbotid_value": "11111111-2222-3333-4444-555555555555",
                 "data": "kind: TaskDialog\naction:\n  kind: InvokeConnectedAgentTaskAction\n"
                         "  botId: aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee\n"}]}
        return {}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"])
    main = [d for d in r["descriptors"] if d["name"] == "Main"][0]
    conns = [l for l in main["links"] if l["rel"] == "connects_to"]
    assert len(conns) == 1 and conns[0]["label"] == "Lookup"
    assert conns[0]["target"] == _stable_id(
        "copilot_studio", "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")


def test_copilot_portal_links_use_environment_id():
    env_index = {"https://org.crm.dynamics.com":
                 {"id": "env-guid-1", "name": "Prod"}}
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [{"botid": "b1", "name": "A", "schemaname": "cr_a",
                               "authenticationmode": 2}]}
        return {"value": []}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    d = r["descriptors"][0]
    assert d["scope"]["portal_url"] == (
        "https://copilotstudio.microsoft.com/environments/env-guid-1/copilots/b1/details")
    assert d["scope"]["environment"] == "Prod"


def test_foundry_falls_back_from_agents_v1_to_assistants():
    calls = []
    def fetch(method, url, **kw):
        calls.append(url)
        if "agents?api-version" in url:
            raise Exception("404")
        if "assistants?" in url:
            return {"data": [{"id": "a1", "name": "Legacy", "model": "gpt-4o"}]}
        return {}
    r = foundry_agents.collect(fetch, token="t",
                               endpoints=["https://x.services.ai.azure.com/api/projects/p"])
    assert [d["name"] for d in r["descriptors"]] == ["Legacy"]
    assert any("agents?api-version=v1" in c for c in calls)  # tried modern first


def test_foundry_portal_link_and_subscription_attribution():
    meta = {"https://x.services.ai.azure.com/api/projects/p": {
        "arm_id": "/subscriptions/s1/resourceGroups/rg/providers/"
                  "Microsoft.CognitiveServices/accounts/x",
        "project": "p", "subscription_id": "s1", "subscription_name": "Sub One"}}
    def fetch(method, url, **kw):
        if "agents?api-version=v1" in url:
            return {"value": [{"id": "asst_1", "name": "Orch", "model": "gpt-4o"}]}
        return {}
    r = foundry_agents.collect(fetch, token="t",
                               endpoints=list(meta), ep_meta=meta)
    d = r["descriptors"][0]
    assert d["scope"]["subscription"] == "s1"
    # GROUNDED in Foundry's azd output: the playground addresses an agent by
    # NAME with a version, not by assistant id.
    assert d["scope"]["portal_url"] == (
        "https://ai.azure.com/build/agents/Orch/build"
        "?wsid=/subscriptions/s1/resourceGroups/rg/providers/"
        "Microsoft.CognitiveServices/accounts/x/projects/p&version=1")


def test_subscriptions_rollup_counts_and_portal():
    from openaid.inventory import build_inventory
    descriptors = [{
        "id": "f1", "name": "Orch",
        "agent": {"platform": "azure_foundry", "agent_type": "foundry_agent",
                  "native_id": "asst_1"},
        "scope": {"kind": "foundry_project", "subscription": "s1"},
        "identity": {}, "entitlements": [], "endpoints": [], "links": [],
        "risk_hints": {},
    }]
    scopes = [{"kind": "azure_subscription", "id": "s1", "name": "Sub One",
               "state": "Enabled", "status": "read",
               "portal_url": "https://portal.azure.com/#@/resource/subscriptions/s1/overview"}]
    inv = build_inventory(descriptors, scopes, [])
    sub = inv["subscriptions"][0]
    assert sub["agents"] == 1
    assert sub["portal_url"].endswith("/subscriptions/s1/overview")


def test_hierarchies_carry_portal_urls():
    descs = [
        {"id": "oaid:copilot_studio:p", "name": "Parent",
         "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent",
                   "native_id": "p"},
         "scope": {"portal_url": "https://copilotstudio.microsoft.com/environments/e/bots/p/overview"},
         "identity": {}, "entitlements": [], "endpoints": [],
         "links": [{"rel": "delegates_to", "target": "child:k1", "kind": "child",
                    "label": "Order Lookup"}],
         "risk_hints": {}},
    ]
    g = TrustGraph.from_descriptors(descs)
    hs = g.hierarchies()
    assert len(hs) == 1
    assert hs[0]["portal_url"].endswith("/bots/p/overview")
    assert hs[0]["children"][0]["name"] == "Order Lookup"
    assert hs[0]["children"][0]["type"] == "child"


# --------------------------------------------- v0.2.2 all Foundry agent types
def test_foundry_discovers_all_agent_types():
    """Prompt, hosted, and workflow agents come from the preview /agents route
    (with the HostedAgents feature header); classic agents from v1; all merged
    and classified without double-counting."""
    def fetch(method, url, **kw):
        h = kw.get("headers", {})
        if "agents?api-version=v1" in url:
            return {"value": [{"id": "a1", "name": "Classic", "model": "gpt-4o"}]}
        if "agents?api-version=2025-11-15-preview" in url:
            assert h.get("Foundry-Features") == "HostedAgents=V1Preview"
            return {"value": [
                {"id": "a1", "name": "Classic", "model": "gpt-4o"},  # dupe of v1
                {"name": "helper", "definition": {"kind": "PromptAgentDefinition"}},
                {"name": "worker", "definition": {"kind": "HostedAgentDefinition",
                                                  "image": "acr.io/worker:v2"}},
                {"name": "pipeline", "definition": {"kind": "WorkflowAgentDefinition"}}]}
        if "assistants?" in url and "/openai/" not in url:
            return {"data": [{"id": "asst_9", "name": "LegacyAsst", "model": "gpt-4o"}]}
        return {}
    r = foundry_agents.collect(fetch, token="t",
                               endpoints=["https://x.services.ai.azure.com/api/projects/p"])
    types = {d["name"]: d["agent"]["agent_type"] for d in r["descriptors"]}
    assert types["Classic"] == "foundry_agent"
    assert types["helper"] == "foundry_prompt_agent"
    assert types["worker"] == "foundry_hosted_agent"
    assert types["pipeline"] == "foundry_workflow_agent"
    assert types["LegacyAsst"] == "foundry_agent"  # project /assistants IS the GA agents list
    names = [d["name"] for d in r["descriptors"]]
    assert names.count("Classic") == 1  # deduped across surfaces
    scope = [s for s in r["scopes"] if s.get("agent_types")][0]
    assert scope["agent_types"]["foundry_hosted_agent"] == 1


def test_foundry_sweeps_aoai_assistants_per_account():
    """Azure OpenAI Assistants live on the ACCOUNT root (/openai/assistants) —
    swept once per account even with multiple projects, deduped vs project agents."""
    calls = []
    def fetch(method, url, **kw):
        calls.append(url)
        if "/openai/assistants" in url:
            return {"data": [{"id": "asst_ao1", "name": "AccountAsst", "model": "gpt-4o"}]}
        if "agents?api-version=v1" in url:
            return {"value": [{"id": "a1", "name": "Classic", "model": "gpt-4o"}]}
        return {}
    eps = ["https://x.services.ai.azure.com/api/projects/p1",
           "https://x.services.ai.azure.com/api/projects/p2"]
    r = foundry_agents.collect(fetch, token="t", endpoints=eps)
    aoai = [d for d in r["descriptors"] if d["agent"]["platform"] == "azure_openai"]
    assert len(aoai) == 1 and aoai[0]["name"] == "AccountAsst"
    assert aoai[0]["agent"]["agent_type"] == "openai_assistant"
    # exactly ONE account-level sweep despite two projects
    assert sum(1 for c in calls if "/openai/assistants" in c) == 1


def test_foundry_one_dead_route_never_hides_other_surfaces():
    def fetch(method, url, **kw):
        if "agents?api-version=v1" in url:
            raise Exception("404")
        if "agents?api-version=2025-05-01" in url:
            raise Exception("404")
        if "agents?api-version=2025-11-15-preview" in url:
            return {"value": [{"name": "hosted-only",
                               "definition": {"kind": "HostedAgentDefinition"}}]}
        return {}
    r = foundry_agents.collect(fetch, token="t",
                               endpoints=["https://x.services.ai.azure.com/api/projects/p"])
    assert [d["name"] for d in r["descriptors"] if d["agent"]["platform"] == "azure_foundry"] == ["hosted-only"]


# ---------------------------------------------- v0.2.3 foundry host fix
def test_foundry_discovery_never_uses_legacy_cognitiveservices_host():
    """ARM properties.endpoint is the legacy cognitiveservices host — it 404s
    for /agents. Endpoints must be built on services.ai.azure.com."""
    from openaid.collectors import foundry_discovery
    def fetch(method, url, **kw):
        if "CognitiveServices/accounts?" in url:
            return {"value": [{
                "name": "myacct", "kind": "AIServices",
                "id": "/subscriptions/s1/resourceGroups/rg/providers/"
                      "Microsoft.CognitiveServices/accounts/myacct",
                "properties": {"endpoint": "https://myacct.cognitiveservices.azure.com/"}}]}
        if "/projects?" in url:
            return {"value": [{"name": "myacct/proj1"}]}
        return {}
    _rep, eps, meta = foundry_discovery.collect(fetch, token="t", subscription_ids=["s1"])
    assert eps == ["https://myacct.services.ai.azure.com/api/projects/proj1"]
    # legacy host preserved separately for the AOAI assistants sweep
    assert meta[eps[0]]["aoai_base"] == "https://myacct.cognitiveservices.azure.com"


def test_foundry_discovery_prefers_explicit_ai_foundry_api_endpoint():
    from openaid.collectors import foundry_discovery
    def fetch(method, url, **kw):
        if "CognitiveServices/accounts?" in url:
            return {"value": [{
                "name": "acct2", "kind": "AIServices",
                "id": "/subscriptions/s1/resourceGroups/rg/providers/"
                      "Microsoft.CognitiveServices/accounts/acct2",
                "properties": {
                    "endpoint": "https://acct2.cognitiveservices.azure.com/",
                    "endpoints": {"AI Foundry API": "https://acct2.services.ai.azure.com/api/projects"}}}]}
        if "/projects?" in url:
            return {"value": []}
        return {}
    _rep, eps, _meta = foundry_discovery.collect(fetch, token="t", subscription_ids=["s1"])
    assert eps == ["https://acct2.services.ai.azure.com/api/projects/acct2"]


def test_aoai_sweep_falls_back_to_legacy_host():
    meta = {"https://x.services.ai.azure.com/api/projects/p": {
        "arm_id": "/subs/s1/rg/rg/acc/x", "project": "p",
        "subscription_id": "s1", "subscription_name": "S",
        "aoai_base": "https://x.openai.azure.com"}}
    def fetch(method, url, **kw):
        if url.startswith("https://x.services.ai.azure.com/openai/assistants"):
            raise Exception("404")
        if url.startswith("https://x.openai.azure.com/openai/assistants"):
            return {"data": [{"id": "asst_L", "name": "LegacyHostAsst", "model": "gpt-4o"}]}
        if "agents?api-version=v1" in url:
            return {"value": []}
        return {}
    r = foundry_agents.collect(fetch, token="t", endpoints=list(meta), ep_meta=meta)
    aoai = [d for d in r["descriptors"] if d["agent"]["platform"] == "azure_openai"]
    assert [d["name"] for d in aoai] == ["LegacyHostAsst"]


# ------------------------------------------ v0.2.4 project recovery + cogsvc
def test_foundry_recovers_real_project_names_from_data_plane():
    """When ARM listed no projects, the account NAME was guessed as the project
    — wrong guess = every /agents call 404s. The collector must ask the data
    plane for real projects and sweep those instead."""
    def fetch(method, url, **kw):
        if "/api/projects/guessedname/" in url:
            raise Exception("404 project not found")
        if url.endswith("/api/projects?api-version=v1"):
            return {"value": [{"name": "acct/realproj"}]}
        if "/api/projects/realproj/agents?api-version=v1" in url:
            return {"value": [{"id": "a9", "name": "Recovered", "model": "gpt-4o"}]}
        return {}
    r = foundry_agents.collect(
        fetch, token="t",
        endpoints=["https://acct.services.ai.azure.com/api/projects/guessedname"])
    names = [d["name"] for d in r["descriptors"]]
    assert names == ["Recovered"]
    assert any(s.get("recovered") for s in r["scopes"])
    assert not r["errors"]


def test_aoai_assistants_use_cogsvc_audience_token():
    seen = {}
    def fetch(method, url, **kw):
        if "/openai/assistants" in url:
            seen["auth"] = kw.get("headers", {}).get("Authorization", "")
            return {"data": [{"id": "asst_c", "name": "CogAsst", "model": "gpt-4o"}]}
        if "agents?api-version=v1" in url:
            return {"value": []}
        return {}
    r = foundry_agents.collect(
        fetch, token="foundry-tok",
        endpoints=["https://x.services.ai.azure.com/api/projects/p"],
        cogsvc_token="cogsvc-tok")
    assert seen["auth"] == "Bearer cogsvc-tok"  # NOT the foundry token
    assert [d["name"] for d in r["descriptors"] if d["agent"]["platform"] == "azure_openai"] == ["CogAsst"]


# --------------------------------------------- v0.3.0 remediation + validation
def test_remediate_require_auth_patches_dataverse():
    calls = {}
    def fetch(method, url, **kw):
        calls["method"], calls["url"], calls["json"] = method, url, kw.get("json")
        return {}
    from openaid import remediation
    r = remediation.execute("copilot_require_auth", fetch=fetch,
                            org_url="https://org.crm.dynamics.com",
                            bot_id="b1", dataverse_token="tok")
    assert r["ok"] is True
    assert calls["method"] == "PATCH"
    assert calls["url"] == "https://org.crm.dynamics.com/api/data/v9.2/bots(b1)"
    assert calls["json"] == {"authenticationmode": 2}


def test_remediate_disable_and_missing_token():
    from openaid import remediation
    def fetch(method, url, **kw):
        assert kw["json"] == {"statecode": 1, "statuscode": 2}
        return {}
    ok = remediation.execute("copilot_disable", fetch=fetch,
                             org_url="https://o.crm.dynamics.com", bot_id="b2",
                             dataverse_token="t")
    assert ok["ok"] is True
    bad = remediation.execute("copilot_require_auth", fetch=fetch,
                              org_url="https://o.crm.dynamics.com", bot_id="b2",
                              dataverse_token="")
    assert bad["ok"] is False and "Dataverse token" in bad["detail"]


def test_playbooks_cover_agent_and_mcp_risks():
    from openaid import remediation
    for rule in ("anonymous_agent", "high_blast_radius", "mcp_public",
                 "mcp_no_auth", "cross_platform_pivot", "shared_identity"):
        pb = remediation.playbook_for(rule)
        assert pb["steps"], rule
    # unknown rule still returns something usable
    assert remediation.playbook_for("nope")["steps"]


def test_connection_validate_calls_platform_api():
    from openaid import connections as conn
    seen = {}
    def fetch(method, url, **kw):
        seen["url"] = url
        return {}
    r = conn.validate("webex", "tok", "", fetch)
    assert r["ok"] and "webexapis.com/v1/people/me" in seen["url"]
    r2 = conn.validate("servicenow", "tok", "", fetch)
    assert r2["ok"] is False and "URL required" in r2["detail"]
    def fetch_fail(method, url, **kw):
        raise Exception("401 unauthorized")
    r3 = conn.validate("gcp", "bad", "", fetch_fail)
    assert r3["ok"] is False and "401" in r3["detail"]


# ------------------------------------------- v0.3.1 grounded routes + hub agents
def test_project_assistants_v1_is_swept_first():
    """GA docs: agents list at {endpoint}/assistants?api-version=v1. This exact
    route MUST be in the sweep — it was missing, so classic agents never listed."""
    hits = []
    def fetch(method, url, **kw):
        hits.append(url)
        if "assistants?api-version=v1" in url and "/openai/" not in url:
            return {"data": [{"id": "asst_ga", "name": "ClassicGA", "model": "gpt-4o"}]}
        raise Exception("404")
    r = foundry_agents.collect(fetch, token="t",
                               endpoints=["https://x.services.ai.azure.com/api/projects/p"])
    assert [d["name"] for d in r["descriptors"] if d["agent"]["platform"] == "azure_foundry"] == ["ClassicGA"]
    assert any(u.endswith("/assistants?api-version=v1") for u in hits)


def test_hub_based_projects_swept_via_legacy_aml_route():
    """Hub projects 404 on services.ai ('Project not found') — they must be
    discovered through {region}.api.azureml.ms/agents/v1.0/{workspaceId}/assistants
    with the ml.azure.com-audience token."""
    from openaid.collectors import foundry_hub_agents
    seen = {}
    def fetch(method, url, **kw):
        if "MachineLearningServices/workspaces?" in url:
            return {"value": [
                {"name": "hub1", "kind": "Hub", "location": "eastus",
                 "id": "/subscriptions/s1/resourceGroups/rg/providers/Microsoft.MachineLearningServices/workspaces/hub1"},
                {"name": "proj1", "kind": "Project", "location": "East US",
                 "id": "/subscriptions/s1/resourceGroups/rg/providers/Microsoft.MachineLearningServices/workspaces/proj1"}]}
        if "api.azureml.ms/agents/v1.0" in url:
            seen["url"] = url
            seen["auth"] = kw.get("headers", {}).get("Authorization", "")
            return {"data": [{"id": "asst_hub", "name": "HubAgent", "model": "gpt-4o"}]}
        return {}
    r = foundry_hub_agents.collect(fetch, arm_token="arm", ml_token="mltok",
                                   subscription_ids=["s1"])
    names = [d["name"] for d in r["descriptors"]]
    assert names == ["HubAgent"]  # the Hub itself is skipped, its project swept
    assert r["descriptors"][0]["agent"]["agent_type"] == "foundry_hub_agent"
    assert seen["url"].startswith("https://eastus.api.azureml.ms/agents/v1.0/subscriptions/s1/")
    assert seen["url"].endswith("/workspaces/proj1/assistants?api-version=2024-12-01-preview")
    assert seen["auth"] == "Bearer mltok"


def test_hub_collector_skips_without_ml_token():
    from openaid.collectors import foundry_hub_agents
    r = foundry_hub_agents.collect(lambda *a, **k: {}, arm_token="arm",
                                   ml_token=None, subscription_ids=["s1"])
    assert r["scopes"][0]["status"] == "skipped"


# ---------------------------------------- v0.3.3 hierarchy enrichment
def test_hierarchy_children_inherit_env_and_parent_portal():
    descs = [
        {"id": "oaid:copilot_studio:p", "name": "Parent",
         "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent",
                   "native_id": "p"},
         "scope": {"environment": "prod101", "portal_url": "https://copilotstudio.microsoft.com/environments/e/bots/p/overview"},
         "identity": {}, "entitlements": [], "endpoints": [],
         "links": [{"rel": "delegates_to", "target": "child:k1", "kind": "child",
                    "label": "prod101child"}],
         "risk_hints": {}},
    ]
    g = TrustGraph.from_descriptors(descs)
    h = g.hierarchies()[0]
    assert h["environment"] == "prod101"
    assert h["child_n"] == 1 and h["connected_n"] == 0
    kid = h["children"][0]
    # embedded child opens the PARENT's Agents page and inherits the environment
    assert kid["portal_url"].endswith("/bots/p/agents")
    assert kid["environment"] == "prod101"


# -------------------------------------------------- v0.4.0 usage analytics
def test_usage_aggregate_joins_agent_names_and_envs():
    from openaid import usage
    agents = [
        {"native_id": "b1", "name": "Helpdesk", "environment": "prod101",
         "platform": "copilot_studio", "portal_url": "https://x/overview", "id": "i1"},
        {"native_id": "b2", "name": "Sales", "environment": "DEV2",
         "platform": "copilot_studio", "portal_url": "", "id": "i2"},
    ]
    out = usage.aggregate(
        [{"bot_id": "b1", "sessions": 40}, {"bot_id": "b2", "sessions": 9}],
        [{"account": "acct1", "tokens": 5000, "subscription": "Sub"}],
        agents)
    assert out["top_agents"][0]["name"] == "Helpdesk"
    assert out["top_agents"][0]["environment"] == "prod101"
    # environments now carry BOTH sessions and tokens
    prod = [e for e in out["environments"] if e["environment"] == "prod101"][0]
    assert prod["sessions"] == 40
    assert out["foundry_tokens"][0]["tokens"] == 5000
    assert out["totals"]["sessions"] == 49 and out["totals"]["tokens"] == 5000


def test_usage_copilot_sessions_groups_by_bot():
    from openaid import usage
    def fetch(method, url, **kw):
        assert "conversationtranscripts" in url and "createdon ge" in url
        return {"value": [
            {"_bot_conversationtranscriptid_value": "B1"},
            {"_bot_conversationtranscriptid_value": "b1"},
            {"_bot_conversationtranscriptid_value": "b2"}]}
    rows = usage.copilot_sessions(fetch, "https://o.crm.dynamics.com", "t")
    d = {r["bot_id"]: r["sessions"] for r in rows}
    assert d == {"b1": 2, "b2": 1}


def test_usage_foundry_tokens_sums_metric_series():
    from openaid import usage
    def fetch(method, url, **kw):
        assert "microsoft.insights/metrics" in url and "TokenTransaction" in url
        return {"value": [{"timeseries": [{"data": [{"total": 100}, {"total": 250}, {}]}]}]}
    rows = usage.foundry_tokens(fetch, "arm", [{"id": "/subs/x/acc/a1", "name": "a1",
                                                "subscription": "S"}])
    assert rows == [{"account": "a1", "tokens": 350, "subscription": "S"}]


def test_usage_top_users_ranked():
    from openaid import usage
    out = usage.aggregate(
        [{"bot_id": "b1", "sessions": 5}], [], [],
        user_rows=[{"user": "a@x.com", "sessions": 3}, {"user": "b@x.com", "sessions": 12}])
    assert [u["user"] for u in out["top_users"]] == ["b@x.com", "a@x.com"]


def test_usage_users_collector_counts_by_createdby():
    from openaid import usage
    def fetch(method, url, **kw):
        assert "_createdby_value" in url
        return {"value": [
            {"_createdby_value": "u1", "_createdby_value@OData.Community.Display.V1.FormattedValue": "Alice"},
            {"_createdby_value": "u1"},
            {"_createdby_value": "u2", "_createdby_value@OData.Community.Display.V1.FormattedValue": "Bob"}]}
    rows = usage.copilot_users(fetch, "https://o.crm.dynamics.com", "t")
    d = {r["user"]: r["sessions"] for r in rows}
    assert d.get("Alice") == 2 and d.get("Bob") == 1


def test_new_integrations_registered_and_validated():
    from openaid import connections as conn
    ids = {p["id"] for p in conn.PLATFORMS}
    for i in ("openai", "anthropic", "slack", "github", "atlassian", "zendesk"):
        assert i in ids, i
        assert i in conn.CONNECT_GUIDE, i
    seen = {}
    def fetch(method, url, **kw):
        seen["url"] = url; return {}
    assert conn.validate("github", "tok", "", fetch)["ok"]
    assert "api.github.com/user" in seen["url"]
    assert conn.validate("openai", "sk-x", "", fetch)["ok"]
    assert "api.openai.com/v1/models" in seen["url"]


# ------------------------------------------- v0.4.2 hierarchy filter + risk + export
def test_hierarchy_carries_risk_and_env_id_for_filter():
    descs = [
        {"id": "oaid:copilot_studio:p", "name": "Parent",
         "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent", "native_id": "p"},
         "scope": {"environment": "prod101", "environment_id": "env-guid-9",
                   "portal_url": "https://copilotstudio.microsoft.com/environments/env-guid-9/bots/cr_p/overview"},
         "identity": {}, "entitlements": [], "endpoints": [],
         "links": [{"rel": "delegates_to", "target": "child:1", "kind": "child", "label": "c1"},
                   {"rel": "delegates_to", "target": "child:2", "kind": "child", "label": "c2"},
                   {"rel": "delegates_to", "target": "child:3", "kind": "child", "label": "c3"}],
         "risk_hints": {"anonymous": True}},
    ]
    h = TrustGraph.from_descriptors(descs).hierarchies()[0]
    assert h["environment_id"] == "env-guid-9"
    assert h["anonymous"] is True and h["risk"] == "high"
    # child link points at the parent's /agents page
    assert h["children"][0]["portal_url"].endswith("/bots/cr_p/agents")


# ------------------------------------------- v0.4.3 industry posture report
def test_posture_maps_findings_to_industry_frameworks():
    from openaid import posture
    findings = [
        {"rule": "anonymous_agent", "severity": "high", "title": "Anon", "detail": "x"},
        {"rule": "mcp_public", "severity": "critical", "title": "Public MCP", "detail": "y"},
    ]
    agents = [{"anonymous": True}, {"anonymous": False}]
    r = posture.build_report(findings, agents, "healthcare")
    assert r["industry_label"].startswith("Healthcare")
    assert "HIPAA" in r["frameworks"]
    hipaa = [f for f in r["framework_impact"] if f["label"] == "HIPAA"][0]
    assert hipaa["count"] >= 2  # both findings map to HIPAA controls
    assert r["totals"]["anonymous_agents"] == 1
    assert r["grade"] in ("A", "B", "C", "D", "F")


def test_posture_score_clean_is_A():
    from openaid import posture
    r = posture.build_report([], [{"anonymous": False}], "finance")
    assert r["score"] == 100 and r["grade"] == "A"
    assert "PCI-DSS" in r["frameworks"]


def test_posture_score_drops_with_criticals():
    from openaid import posture
    findings = [{"rule": "mcp_public", "severity": "critical"} for _ in range(3)]
    s = posture.posture_score(findings)
    assert s["score"] <= 20 and s["grade"] in ("D", "F")


def test_hierarchy_env_resolves_to_friendly_name_matching_dropdown():
    """Live regression: Copilot hierarchy scope fell back to the raw Dataverse
    URL, so the env label on the card never matched a dropdown option (which
    uses the friendly name). The shared resolver must fix both to the SAME name."""
    from openaid.discover_v2 import discover
    from openaid.inventory import build_env_resolver
    # simulate scopes carrying the friendly name for that dataverse url
    scopes = [{"kind": "powerplatform_env", "id": "e1", "name": "Contoso Prod",
               "dataverse_url": "https://org41d104fb.api.crm.dynamics.com"}]
    resolve = build_env_resolver(scopes)
    # a hierarchy that came back with the raw URL...
    assert resolve("https://org41d104fb.api.crm.dynamics.com") == "Contoso Prod"
    # ...and the org-url variant collapses too
    assert resolve("https://org41d104fb.crm.dynamics.com") == "Contoso Prod"


# ------------------------------------------- v0.5.0 blast simulator
def test_simulate_isolation_reduces_reach():
    from openaid.graph.trust_graph import TrustGraph
    descs = [
        {"id": "A", "name": "Orchestrator", "agent": {"platform": "copilot_studio", "agent_type": "x", "native_id": "a"},
         "scope": {}, "identity": {"kind": "copilot_agent", "principal": "svc-a"},
         "entitlements": [{"resource": "crm:contacts", "actions": ["read"], "sensitive": True}],
         "endpoints": [], "links": [{"rel": "delegates_to", "target": "B", "kind": "child"}], "risk_hints": {}},
        {"id": "B", "name": "Child", "agent": {"platform": "copilot_studio", "agent_type": "x", "native_id": "b"},
         "scope": {}, "identity": {"kind": "copilot_agent", "principal": "svc-b"},
         "entitlements": [{"resource": "sql:orders", "actions": ["read"]}],
         "endpoints": [], "links": [], "risk_hints": {}},
    ]
    g = TrustGraph.from_descriptors(descs)
    base = g.blast_radius("A")
    saved = g.out.get("A", [])
    g.out["A"] = []
    iso = g.blast_radius("A")
    g.out["A"] = saved
    assert base["reachable_total"] > iso["reachable_total"]
    # restoring edges leaves the graph unchanged for the next query
    assert g.blast_radius("A")["reachable_total"] == base["reachable_total"]


# ------------------------------------- v0.6.0 lethal trifecta injection audit
def _desc(name, ents=(), links=(), anon=False, auth="authenticated"):
    return {"id": name, "name": name,
            "agent": {"platform": "copilot_studio", "agent_type": "copilot_studio_agent",
                      "native_id": name},
            "scope": {"environment": "prod101", "portal_url": "https://x/overview"},
            "identity": {"kind": "copilot_agent", "auth": auth},
            "entitlements": list(ents), "endpoints": [], "links": list(links),
            "risk_hints": {"anonymous": anon}}


def test_trifecta_flags_all_three_legs_as_exploitable():
    from openaid import trifecta
    d = _desc("HR Bot",
              ents=[{"resource": "sharepoint:hr-files", "actions": ["read"], "sensitive": True},
                    {"resource": "outlook:mail", "actions": ["send"]}],
              anon=True)
    r = trifecta.analyze_agent(d)
    assert r["status"] == "exploitable"
    assert set(r["legs_present"]) == {"private_data", "untrusted_content", "external_comms"}
    # cheapest leg to cut is the untrusted entry point, not the private data
    assert r["recommendation"]["cut"] == "untrusted_content"


def test_trifecta_two_legs_is_one_away_with_watch_guidance():
    """Private data + an outbound send, but NO untrusted input path: dangerous
    only if someone later exposes it. Must be flagged 'one away', not clean."""
    from openaid import trifecta
    d = _desc("Reporter", ents=[{"resource": "sql:orders", "actions": ["read"]},
                                {"resource": "smtp:digest", "actions": ["send"]}])
    r = trifecta.analyze_agent(d)
    assert r["leg_count"] == 2 and r["status"] == "one_away"
    assert r["recommendation"]["watch"] == "untrusted_content"


def test_trifecta_readonly_agent_is_not_over_flagged():
    """Guard against false positives: read-only private access alone is one
    leg, never exploitable."""
    from openaid import trifecta
    r = trifecta.analyze_agent(_desc("Reporter", ents=[{"resource": "sql:orders",
                                                        "actions": ["read"]}]))
    assert r["leg_count"] == 1 and r["status"] == "limited"


def test_trifecta_mcp_link_adds_untrusted_and_exfil_legs():
    from openaid import trifecta
    d = _desc("MCP User", ents=[{"resource": "crm:contacts", "actions": ["read"]}],
              links=[{"rel": "calls_mcp", "target": "https://mcp.example.com"}])
    r = trifecta.analyze_agent(d)
    assert r["status"] == "exploitable"
    assert "mcp" in r["legs"]["untrusted_content"]["evidence"]


def test_trifecta_fleet_picks_highest_leverage_single_cut():
    from openaid import trifecta
    fleet = [
        _desc("A", ents=[{"resource": "sql:x", "actions": ["read"]},
                         {"resource": "mail:out", "actions": ["send"]}], anon=True),
        _desc("B", ents=[{"resource": "crm:y", "actions": ["read"]},
                         {"resource": "webhook:z", "actions": ["post"]}], anon=True),
    ]
    out = trifecta.analyze_fleet(fleet)
    assert out["totals"]["exploitable"] == 2
    assert out["totals"]["exploitable_pct"] == 100
    assert out["fleet_cut"]["defuses"] == 2
    assert out["fleet_cut"]["leg"] == "untrusted_content"


def test_trifecta_contained_agent_has_no_recommendation():
    from openaid import trifecta
    d = {"id": "q", "name": "Quiet", "agent": {"platform": "copilot_studio", "agent_type": "t"},
         "scope": {}, "identity": {}, "entitlements": [], "endpoints": [], "links": [],
         "risk_hints": {}}
    r = trifecta.analyze_agent(d)
    assert r["status"] == "contained" and r["recommendation"] is None


# ------------------------------------- v0.6.1 URL correctness + per-agent fix
def test_foundry_portal_never_built_from_data_plane_host():
    """Regression: the fallback built ai-portal links off the DATA-PLANE host
    (acct.services.ai.azure.com/build/agents?project=/p), which is an API
    endpoint, not a page. Portal links must always be ai.azure.com."""
    from openaid.inventory import _portal_link
    d = {"agent": {"platform": "azure_foundry", "native_id": "asst_7"},
         "scope": {"endpoint": "https://acct.services.ai.azure.com/api/projects/p",
                   "arm_id": "/subscriptions/s/resourceGroups/rg/providers/"
                             "Microsoft.CognitiveServices/accounts/acct",
                   "project": "p"},
         "risk_hints": {}}
    u = _portal_link(d)
    assert u.startswith("https://ai.azure.com/build/agents/asst_7/build?wsid=")
    assert "services.ai.azure.com" not in u


def test_copilot_portal_fallback_uses_bot_id_guid():
    """The agent is addressed by its BOT ID GUID (never the schema name), on
    the CANONICAL current route — the shape Microsoft's own deepLinkUrl
    metadata emits: /environments/{envId}/copilots/{botId}/details."""
    from openaid.inventory import _portal_link
    d = {"agent": {"platform": "copilot_studio", "native_id": "bot-guid-1"},
         "scope": {"environment_id": "env-9", "schema_name": "cr123_agent"},
         "risk_hints": {}}
    assert _portal_link(d) == (
        "https://copilotstudio.microsoft.com/environments/env-9/copilots/bot-guid-1/details")


def test_scan_agent_lists_issues_and_one_click_fixes():
    from openaid import remediation
    agent = {"id": "a1", "name": "Anon Bot", "platform": "copilot_studio",
             "environment": "prod101", "anonymous": True, "blast_score": 72,
             "native_id": "b1", "org_url": "https://o.crm.dynamics.com"}
    tri = {"id": "a1", "status": "exploitable",
           "recommendation": {"label": "Untrusted content exposure", "advice": "gate it"}}
    out = remediation.scan_agent(agent, [], tri)
    rules = [i["rule"] for i in out["issues"]]
    assert "anonymous_agent" in rules and "high_blast_radius" in rules
    assert "lethal_trifecta" in rules
    # critical issues sort first
    assert out["issues"][0]["severity"] == "critical"
    # the anonymous issue offers a real one-click write
    anon = [i for i in out["issues"] if i["rule"] == "anonymous_agent"][0]
    assert anon["fixable"] and any(a["id"] == "copilot_require_auth" for a in anon["actions"])
    assert out["summary"]["one_click_fixable"] >= 1


def test_scan_agent_clean_agent_has_no_issues():
    from openaid import remediation
    out = remediation.scan_agent(
        {"id": "ok", "name": "Clean", "platform": "copilot_studio",
         "anonymous": False, "blast_score": 5, "owner_id": "user-1"}, [], None)
    assert out["issues"] == [] and out["summary"]["total"] == 0


def test_scan_agent_does_not_offer_copilot_fixes_to_foundry_agents():
    from openaid import remediation
    out = remediation.scan_agent(
        {"id": "f1", "name": "Foundry", "platform": "azure_foundry",
         "anonymous": True, "blast_score": 10}, [], None)
    anon = [i for i in out["issues"] if i["rule"] == "anonymous_agent"][0]
    assert anon["actions"] == []      # Dataverse PATCH is meaningless here
    assert anon["steps"]              # but guided steps are still provided


# ------------------------- v0.6.2 Copilot Studio new-GUI URL resolution
def test_copilot_emits_ordered_portal_candidates_for_both_experiences():
    """Copilot Studio ships classic AND new agent experiences on different
    routes. One hard-coded path can 404, so the collector must emit ordered
    candidates ending in an always-valid environment fallback."""
    env_index = {"https://org.crm.dynamics.com": {"id": "env-7", "name": "Prod"}}
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [{"botid": "bot-guid-1", "name": "A",
                               "schemaname": "cr123_agentA", "authenticationmode": 2}]}
        return {"value": []}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    root = "https://copilotstudio.microsoft.com/environments/env-7"
    # CANONICAL current form first (/copilots/{id}/details), the previously
    # proven classic form (/bots/{id}/overview) immediately after
    assert c[0] == f"{root}/copilots/bot-guid-1/details"
    assert c[1] == f"{root}/bots/bot-guid-1/overview"
    assert f"{root}/agents/bot-guid-1/overview" in c
    assert f"{root}/bots/cr123_agentA/overview" in c        # schema last resort
    assert c[-1] == f"{root}/home"                          # VERIFIED fallback
    # every candidate is a real portal host, never a Dataverse/API host
    assert all(u.startswith("https://copilotstudio.microsoft.com/") for u in c)


def test_copilot_candidates_degrade_safely_without_environment_id():
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [{"botid": "b", "name": "A", "schemaname": "cr_a",
                               "authenticationmode": 2}]}
        return {"value": []}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"])
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert c == ["https://copilotstudio.microsoft.com/"]


def _now_iso():
    import datetime as dt
    return dt.datetime.now(dt.timezone.utc).isoformat()


# ---------------------------------------- v0.7.0 sprawl / shadow-AI detection
def test_sprawl_flags_orphaned_stale_dormant_duplicate():
    from openaid import sprawl
    old = "2020-01-01T00:00:00Z"
    agents = [
        {"id": "1", "name": "Ghost", "environment": "prod", "owner_id": "",
         "modified_on": old, "statecode": 0, "anonymous": True},
        {"id": "2", "name": "Dupe", "environment": "prod", "owner_id": "u1",
         "modified_on": old, "statecode": 1},
        {"id": "3", "name": "Dupe", "environment": "prod", "owner_id": "u1",
         "modified_on": old, "statecode": 0},
        {"id": "4", "name": "Healthy", "environment": "prod", "owner_id": "u1",
         "modified_on": _now_iso(), "statecode": 0},
    ]
    out = sprawl.analyze(agents)
    by = {r["id"]: r for r in out["rows"]}
    assert "orphaned" in by["1"]["flags"] and "stale" in by["1"]["flags"]
    # orphaned + anonymous = worst combination
    assert by["1"]["priority"] == "critical"
    assert "dormant" in by["2"]["flags"] and "duplicate" in by["2"]["flags"]
    assert "duplicate" in by["3"]["flags"]
    assert "4" not in by                       # healthy agent not flagged
    assert out["totals"]["flagged"] == 3 and out["totals"]["clean"] == 1


def test_sprawl_respects_custom_stale_window():
    from openaid import sprawl
    import datetime as dt
    ts = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=45)).isoformat()
    a = [{"id": "x", "name": "Mid", "environment": "e", "owner_id": "u",
          "modified_on": ts, "statecode": 0}]
    assert sprawl.analyze(a, stale_days=90)["totals"]["flagged"] == 0
    assert sprawl.analyze(a, stale_days=30)["totals"]["flagged"] == 1


def test_sprawl_handles_missing_and_bad_timestamps():
    from openaid import sprawl
    a = [{"id": "x", "name": "NoDate", "environment": "e", "owner_id": "u",
          "modified_on": "not-a-date", "statecode": 0}]
    out = sprawl.analyze(a)
    assert out["totals"]["flagged"] == 0      # unknown age never false-flags


# ============ v0.8.0 continuous scanning / auto-remediation / reporting ======
def _snap(rules_agents, at="2026-01-01T00:00:00+00:00"):
    from openaid import continuous
    findings = [{"rule": r, "agent_id": a, "severity": s, "detail": "d"}
                for r, a, s in rules_agents]
    return continuous.snapshot(findings, None, None, None, at=at)


def test_scan_diff_reports_new_fixed_and_persisting():
    from openaid import continuous
    prev = _snap([("anonymous_agent", "a1", "critical"),
                  ("high_blast_radius", "a2", "high")], at="2026-01-01T00:00:00+00:00")
    cur = _snap([("high_blast_radius", "a2", "high"),
                 ("mcp_public", "a3", "critical")], at="2026-01-02T00:00:00+00:00")
    d = continuous.diff(prev, cur)
    assert [i["rule"] for i in d["new"]] == ["mcp_public"]
    assert [i["rule"] for i in d["fixed"]] == ["anonymous_agent"]
    assert [i["rule"] for i in d["persisting"]] == ["high_blast_radius"]
    assert d["counts"] == {"new": 1, "fixed": 1, "persisting": 1, "total": 2}
    # a persisting issue keeps its original first-seen date
    assert d["persisting"][0]["first_seen"] == "2026-01-01T00:00:00+00:00"


def test_issue_ids_are_stable_across_scans():
    from openaid import continuous
    assert (continuous.issue_id("anonymous_agent", "a1")
            == continuous.issue_id("anonymous_agent", "a1"))
    assert (continuous.issue_id("anonymous_agent", "a1")
            != continuous.issue_id("anonymous_agent", "a2"))


def test_auto_remediation_is_opt_in_and_capped():
    from openaid import continuous
    issues = [{"id": str(i), "rule": "anonymous_agent", "severity": "critical",
               "agent_id": f"a{i}", "agent": f"A{i}"} for i in range(10)]
    idx = {f"a{i}": {"environment": "prod", "org_url": "https://o", "native_id": f"b{i}"}
           for i in range(10)}
    # disabled by default → nothing planned
    assert continuous.plan_auto_remediation(issues, None, idx)["planned"] == []
    # enabled but capped
    plan = continuous.plan_auto_remediation(
        issues, {"enabled": True, "max_per_run": 3}, idx)
    assert len(plan["planned"]) == 3
    assert all(p["action"] == "copilot_require_auth" for p in plan["planned"])


def test_auto_remediation_skips_unsafe_rules_and_low_severity():
    from openaid import continuous
    issues = [
        {"id": "1", "rule": "high_blast_radius", "severity": "critical", "agent_id": "a"},
        {"id": "2", "rule": "anonymous_agent", "severity": "medium", "agent_id": "b"},
    ]
    plan = continuous.plan_auto_remediation(issues, {"enabled": True}, {})
    assert plan["planned"] == []
    reasons = {s["id"]: s["reason"] for s in plan["skipped"]}
    assert reasons["1"] == "rule not in policy"
    assert reasons["2"] == "below severity floor"


def test_dry_run_never_writes_but_still_reports_intent():
    from openaid import continuous
    calls = []
    def ex(action, org, bot):
        calls.append(action); return {"ok": True, "detail": "done"}
    plan = continuous.plan_auto_remediation(
        [{"id": "1", "rule": "anonymous_agent", "severity": "critical", "agent_id": "a"}],
        {"enabled": True, "dry_run": True}, {"a": {"org_url": "o", "native_id": "b"}})
    res = continuous.apply_auto_remediation(plan, ex)
    assert calls == []                       # nothing executed
    assert res[0]["ok"] is None and "dry run" in res[0]["detail"]
    # with dry_run off it DOES execute
    plan["policy"]["dry_run"] = False
    res2 = continuous.apply_auto_remediation(plan, ex)
    assert calls == ["copilot_require_auth"] and res2[0]["ok"] is True


def test_report_and_webhook_dispatch():
    from openaid import continuous
    prev = _snap([("anonymous_agent", "a1", "critical")])
    cur = _snap([("mcp_public", "a3", "critical")], at="2026-01-02T00:00:00+00:00")
    d = continuous.diff(prev, cur)
    rep = continuous.build_report(d, [{"agent": "A1", "action": "copilot_require_auth",
                                       "ok": True, "detail": "auth required"}],
                                  {"score": 62, "grade": "C"})
    assert "1 new, 1 fixed" in rep["headline"] and "auto-remediated" in rep["headline"]
    assert rep["posture"]["grade"] == "C"
    html = continuous.render_html(rep)
    assert "New issues" in html and "Automatic remediation" in html
    sent = {}
    def fetch(method, url, **kw):
        sent["url"] = url; sent["payload"] = kw.get("json"); return {}
    assert continuous.dispatch(rep, "https://hooks.slack.com/x", fetch)["ok"]
    assert "text" in sent["payload"]                      # slack shape
    continuous.dispatch(rep, "https://outlook.office.com/webhook/x", fetch)
    assert sent["payload"]["@type"] == "MessageCard"      # teams shape
    assert continuous.dispatch(rep, "", fetch)["ok"] is False


def test_defender_normalizes_unhealthy_ai_assessments_only():
    from openaid import defender
    def fetch(method, url, **kw):
        if "/assessments?" in url:
            return {"value": [
                {"name": "mi-check", "id": "/a1", "properties": {
                    "status": {"code": "Unhealthy"},
                    "displayName": "Accounts should use managed identity",
                    "metadata": {"severity": "High", "remediationDescription": "Enable MI"},
                    "resourceDetails": {"Id": "/subscriptions/s/resourceGroups/rg/providers/"
                                              "Microsoft.CognitiveServices/accounts/acct"}}},
                {"name": "healthy", "id": "/a2", "properties": {
                    "status": {"code": "Healthy"},
                    "resourceDetails": {"Id": "/subscriptions/s/providers/"
                                              "Microsoft.CognitiveServices/accounts/x"}}},
                {"name": "unrelated", "id": "/a3", "properties": {
                    "status": {"code": "Unhealthy"},
                    "metadata": {"severity": "High"},
                    "resourceDetails": {"Id": "/subscriptions/s/providers/"
                                              "Microsoft.Sql/servers/db1"}}}]}
        return {"value": []}
    out = defender.collect(fetch, "arm", ["s"])
    assert out["counts"]["assessments"] == 1        # healthy + non-AI excluded
    i = out["items"][0]
    assert i["severity"] == "critical" and i["remediation"] == "Enable MI"
    assert i["source"] == "defender_for_cloud"


def test_defender_alerts_skip_resolved_and_feed_snapshot():
    from openaid import defender, continuous
    def fetch(method, url, **kw):
        if "/alerts?" in url:
            return {"value": [
                {"properties": {"status": "Active", "severity": "Medium",
                                "alertDisplayName": "Suspicious egress",
                                "resourceIdentifiers": [{"azureResourceId":
                                    "/subscriptions/s/providers/Microsoft.App/containerApps/ca1"}]}},
                {"properties": {"status": "Resolved", "severity": "High",
                                "alertDisplayName": "Old",
                                "resourceIdentifiers": [{"azureResourceId":
                                    "/subscriptions/s/providers/Microsoft.App/containerApps/ca1"}]}}]}
        return {"value": []}
    out = defender.collect(fetch, "arm", ["s"])
    assert out["counts"]["alerts"] == 1
    # defender items flow into the unified scan snapshot
    snap = continuous.snapshot(None, None, None, out["items"])
    assert snap["counts"]["total"] == 1
    assert list(snap["issues"].values())[0]["source"] == "defender"


def test_scan_store_persists_and_trims(tmp_path):
    from openaid import continuous
    path = str(tmp_path / "scans.json")
    s = continuous.ScanStore(path=path, keep=3)
    for n in range(5):
        snap = _snap([("r", f"a{n}", "high")], at=f"2026-01-0{n+1}T00:00:00+00:00")
        d = continuous.diff(s.latest(), snap)
        s.add(snap, d, continuous.build_report(d))
    assert len(s.history(99)) == 3               # trimmed to keep=3
    reloaded = continuous.ScanStore(path=path, keep=3)
    assert len(reloaded.history(99)) == 3        # survived a restart
    assert reloaded.latest()["at"] == "2026-01-05T00:00:00+00:00"


# ================== v0.9.0 red team / exports / universal links =============
def test_redteam_plan_is_targeted_to_discovered_facts():
    from openaid import redteam
    agent = {"id": "a1", "name": "HR Bot", "platform": "copilot_studio",
             "environment": "prod", "anonymous": True}
    tri = {"id": "a1", "status": "exploitable",
           "legs_present": ["private_data", "untrusted_content", "external_comms"],
           "legs": {"untrusted_content": {"evidence": ["email", "web", "mcp"]},
                    "private_data": {"evidence": ["sharepoint"]}}}
    p = redteam.plan_for_agent(agent, tri, has_mcp=True, child_count=2)
    ids = [t["id"] for t in p["tests"]]
    assert "unauthenticated_access" in ids        # because anonymous
    assert "indirect_prompt_injection" in ids     # because untrusted content
    assert "data_exfiltration_loop" in ids        # private + external comms
    assert "delegation_privilege_gap" in ids      # has children
    assert "mcp_tool_poisoning" in ids            # calls MCP
    # criticals sort first, and every test carries framework references
    assert p["tests"][0]["severity"] == "critical"
    assert all(t["owasp"] and t["atlas"] for t in p["tests"])


def test_redteam_minimal_agent_gets_only_universal_test():
    from openaid import redteam
    p = redteam.plan_for_agent({"id": "q", "name": "Quiet", "platform": "copilot_studio"},
                               None, has_mcp=False, child_count=0)
    assert [t["id"] for t in p["tests"]] == ["system_prompt_extraction"]


def test_redteam_fleet_totals_and_owasp_coverage():
    from openaid import redteam
    agents = [{"id": "a1", "name": "A", "platform": "copilot_studio", "anonymous": True},
              {"id": "a2", "name": "B", "platform": "azure_foundry"}]
    tri = {"agents": [{"id": "a1", "status": "exploitable",
                       "legs_present": ["private_data", "untrusted_content", "external_comms"],
                       "legs": {"untrusted_content": {"evidence": ["web"]}}}]}
    out = redteam.plan_fleet(agents, tri, [])
    assert out["totals"]["agents"] == 2 and out["totals"]["critical"] >= 2
    assert any("LLM01" in k for k in out["owasp_coverage"])
    # the riskiest agent sorts first
    assert out["plans"][0]["agent"] == "A"
    assert "does not execute attacks" in out["safety_note"]


def test_auth_probe_is_passive_and_reads_401_as_protected():
    from openaid import redteam
    def open_ep(method, url, **kw):
        return {"ok": True}
    def protected(method, url, **kw):
        raise Exception("401 Unauthorized")
    assert redteam.auth_probe("https://x", open_ep)["requires_auth"] is False
    assert redteam.auth_probe("https://x", protected)["requires_auth"] is True
    assert redteam.auth_probe("", open_ep)["checked"] is False


def test_foundry_agents_emit_portal_candidates_for_resolver():
    meta = {"https://x.services.ai.azure.com/api/projects/p": {
        "arm_id": "/subscriptions/a9307114-91f9-4e69-ab19-3fec0b52ef70"
                  "/resourceGroups/rg/providers/"
                  "Microsoft.CognitiveServices/accounts/x",
        "project": "p", "subscription_id": "a9307114-91f9-4e69-ab19-3fec0b52ef70",
        "subscription_name": "S"}}
    def fetch(method, url, **kw):
        if "assistants?api-version=v1" in url:
            return {"data": [{"id": "asst_1", "name": "Orch", "model": "gpt-4o"}]}
        return {}
    r = foundry_agents.collect(fetch, token="t", endpoints=list(meta), ep_meta=meta)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert len(c) > 1
    # PRIMARY is the New Foundry nextgen form; classic wsid forms follow
    assert c[0].startswith("https://ai.azure.com/nextgen/r/")
    assert "/build/agents/Orch/playground" in c[0]
    assert any("/build/agents/Orch/build" in u for u in c)
    assert any("wsid=" in u and "version=1" in u for u in c)
    assert all(u.startswith("https://ai.azure.com/") for u in c)


def test_nextgen_skipped_when_subscription_is_not_a_guid():
    """Defensive: a non-GUID subscription must NOT produce a fabricated
    nextgen link — fall back to the classic wsid form instead."""
    meta = {"https://x.services.ai.azure.com/api/projects/p": {
        "arm_id": "/subscriptions/not-a-guid/resourceGroups/rg/providers/"
                  "Microsoft.CognitiveServices/accounts/x",
        "project": "p", "subscription_name": "S"}}
    def fetch(method, url, **kw):
        if "assistants?api-version=v1" in url:
            return {"data": [{"id": "a1", "name": "N", "model": "m"}]}
        return {}
    r = foundry_agents.collect(fetch, token="t", endpoints=list(meta), ep_meta=meta)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert not any("/nextgen/r/" in u for u in c)
    assert c[0].startswith("https://ai.azure.com/build/agents/")


def test_pdf_report_renders_all_sections(tmp_path, monkeypatch):
    """Regression: a nested {{}} inside the f-string produced a set-of-dict and
    500'd the whole report.

    Needs the web stack, which is present in the container but not necessarily
    on an operator's workstation — skip cleanly rather than block a deploy."""
    pytest.importorskip("fastapi", reason="web deps not installed locally")
    monkeypatch.setenv("OPENAID_DEMO", "1")
    from fastapi.testclient import TestClient
    import importlib, app.server as S
    importlib.reload(S)
    c = TestClient(S.app)
    r = c.get("/api/exports/report.pdf.html?demo=1")
    assert r.status_code == 200
    for section in ("Executive summary", "Compliance framework impact",
                    "lethal trifecta", "Sprawl", "Recommended penetration tests"):
        assert section in r.text


def test_universal_csv_export_covers_every_screen(monkeypatch):
    pytest.importorskip("fastapi", reason="web deps not installed locally")
    monkeypatch.setenv("OPENAID_DEMO", "1")
    from fastapi.testclient import TestClient
    import importlib, app.server as S
    importlib.reload(S)
    c = TestClient(S.app)
    for ds in ("agents", "findings", "hierarchy", "trifecta", "sprawl",
               "redteam", "subscriptions"):
        r = c.get(f"/api/exports/{ds}.csv?demo=1")
        assert r.status_code == 200, ds
        assert "attachment" in r.headers.get("content-disposition", ""), ds
        assert r.text.strip() and r.text.strip() != "no rows", ds


# ================== v1.0.0 OWASP scan + orphan reassign =====================
def test_owasp_scan_maps_evidence_to_categories():
    from openaid import owasp
    findings = [{"rule": "anonymous_agent", "agent_name": "A"},
                {"rule": "mcp_no_auth", "agent_name": "B"}]
    tri = {"agents": [{"id": "c", "name": "C", "status": "exploitable"}]}
    spr = {"rows": [{"name": "D", "flags": ["orphaned"]}]}
    out = owasp.scan(findings, tri, spr)
    by = {c["id"]: c for c in out["categories"]}
    assert by["LLM01"]["status"] == "exposed"       # injection: anon + trifecta
    assert "A" in by["LLM01"]["agents"] and "C" in by["LLM01"]["agents"]
    assert by["LLM03"]["status"] == "exposed"       # supply chain: mcp + orphan
    assert by["LLM09"]["status"] == "clear"         # nothing evidences it
    assert len(out["categories"]) == 10
    assert out["totals"]["exposed"] + out["totals"]["clear"] == 10


def test_owasp_clean_estate_is_full_coverage():
    from openaid import owasp
    out = owasp.scan([], None, None)
    assert out["totals"]["exposed"] == 0
    assert out["totals"]["coverage_pct"] == 100
    assert all(c["status"] == "clear" for c in out["categories"])


def test_reassign_orphaned_agent_uses_documented_pp_api():
    from openaid import remediation
    seen = {}
    def fetch(method, url, **kw):
        seen.update(method=method, url=url, json=kw.get("json"))
        return {}
    r = remediation.execute("copilot_reassign_owner", fetch=fetch,
                            environment_id="env-1", bot_id="bot-1",
                            new_owner="user-9", pp_token="t")
    assert r["ok"] is True
    assert seen["method"] == "POST"
    assert seen["url"] == ("https://api.powerplatform.com/copilotstudio/environments/"
                           "env-1/bots/bot-1/api/botAdminOperations/reassign?api-version=1")
    assert seen["json"] == {"newOwnerId": "user-9"}


def test_reassign_reports_classic_chatbot_405_clearly():
    from openaid import remediation
    def fetch(method, url, **kw):
        raise Exception("405 Method Not Allowed")
    r = remediation.execute("copilot_reassign_owner", fetch=fetch,
                            environment_id="e", bot_id="b",
                            new_owner="u", pp_token="t")
    assert r["ok"] is False and "classic chatbot" in r["detail"]


def test_orphaned_agent_scan_offers_reassign_action():
    from openaid import remediation
    out = remediation.scan_agent(
        {"id": "a", "name": "Ghost", "platform": "copilot_studio",
         "owner_id": "", "anonymous": False, "blast_score": 3}, [], None)
    orph = [i for i in out["issues"] if i["rule"] == "orphaned_agent"][0]
    assert any(a["id"] == "copilot_reassign_owner" for a in orph["actions"])


# ============ v1.1.0 third-party connectors that actually feed data =========
def test_openai_assistants_become_descriptors():
    from openaid.collectors import third_party as tp
    def fetch(method, url, **kw):
        assert "api.openai.com/v1/assistants" in url
        assert kw["headers"]["OpenAI-Beta"] == "assistants=v2"
        return {"data": [{"id": "asst_1", "name": "Support", "model": "gpt-4o",
                          "tools": [{"type": "file_search"}, {"type": "function"}]}]}
    docs, errs = tp.openai_assistants(fetch, "sk-x")
    assert not errs and len(docs) == 1
    d = docs[0]
    assert d["agent"]["platform"] == "openai" and d["name"] == "Support"
    assert d["risk_hints"]["has_file_search"] is True
    assert any("file_search" in e["resource"] for e in d["entitlements"])


def test_slack_collector_keeps_only_live_bots():
    from openaid.collectors import third_party as tp
    def fetch(method, url, **kw):
        return {"ok": True, "members": [
            {"id": "B1", "is_bot": True, "team_id": "T1",
             "profile": {"real_name": "Deploy Bot", "api_app_id": "A1"}},
            {"id": "B2", "is_bot": True, "deleted": True, "profile": {}},
            {"id": "U1", "is_bot": False, "profile": {"real_name": "Human"}}]}
    docs, errs = tp.slack_bots(fetch, "xoxb-x")
    assert [d["name"] for d in docs] == ["Deploy Bot"]
    assert not errs


def test_slack_surfaces_api_level_error():
    from openaid.collectors import third_party as tp
    docs, errs = tp.slack_bots(lambda *a, **k: {"ok": False, "error": "invalid_auth"},
                               "bad")
    assert docs == [] and errs[0]["error"] == "invalid_auth"


def test_github_app_permissions_become_entitlements():
    from openaid.collectors import third_party as tp
    def fetch(method, url, **kw):
        return {"installations": [{"id": 7, "app_slug": "ci-bot",
                                   "account": {"login": "acme"},
                                   "repository_selection": "all",
                                   "permissions": {"contents": "write",
                                                   "issues": "read"}}]}
    docs, _ = tp.github_apps(fetch, "ghp_x")
    d = docs[0]
    assert d["name"] == "ci-bot" and d["scope"]["environment"] == "acme"
    assert d["risk_hints"]["write_scopes"] == 1
    assert len(d["entitlements"]) == 2


def test_url_required_collectors_fail_clearly_without_url():
    from openaid.collectors import third_party as tp
    for fn in (tp.servicenow_agents, tp.salesforce_agents,
               tp.uipath_robots, tp.zendesk_agents):
        docs, errs = fn(lambda *a, **k: {}, "tok", "")
        assert docs == [] and "required" in errs[0]["error"]


def test_vertex_reasoning_engines_collected():
    from openaid.collectors import third_party as tp
    def fetch(method, url, **kw):
        assert "reasoningEngines" in url and "proj-1" in url
        return {"reasoningEngines": [
            {"name": "projects/proj-1/locations/us-central1/reasoningEngines/99",
             "displayName": "Research Engine"}]}
    docs, _ = tp.vertex_reasoning_engines(fetch, "tok", "proj-1")
    assert docs[0]["name"] == "Research Engine"
    assert docs[0]["agent"]["native_id"] == "99"
    assert docs[0]["agent"]["platform"] == "gcp_vertex"


def test_collect_runs_only_signed_in_platforms_and_isolates_failures():
    from openaid.collectors import third_party as tp
    def fetch(method, url, **kw):
        if "openai" in url:
            return {"data": [{"id": "a", "name": "OK", "model": "m", "tools": []}]}
        raise Exception("boom")
    out = tp.collect(fetch, {"openai": {"token": "t"},
                             "slack": {"token": "t"}})
    names = [d["name"] for d in out["descriptors"]]
    assert names == ["OK"]                     # openai worked
    assert any(e["scope"] == "slack" for e in out["errors"])   # slack failed alone
    by = {s["id"]: s for s in out["scopes"]}
    assert by["openai"]["status"] == "read" and by["slack"]["status"] == "error"


def test_collect_skips_when_nothing_signed_in():
    from openaid.collectors import third_party as tp
    out = tp.collect(lambda *a, **k: {}, {})
    assert out["scopes"][0]["status"] == "skipped"


def test_active_connections_includes_env_seeded_tokens(monkeypatch):
    from openaid import connections as conn
    monkeypatch.setenv("OPENAID_OPENAI_TOKEN", "sk-env")
    monkeypatch.setenv("OPENAID_SERVICENOW_URL", "https://x.service-now.com")
    monkeypatch.setenv("OPENAID_SERVICENOW_TOKEN", "tok")
    out = conn.active_connections()
    assert out["openai"]["token"] == "sk-env"
    assert out["servicenow"]["url"] == "https://x.service-now.com"
    assert "microsoft" not in out


def test_new_connectors_registered_with_validators_and_guides():
    from openaid import connections as conn
    ids = {p["id"] for p in conn.PLATFORMS}
    for i in ("okta", "datadog", "pagerduty", "notion"):
        assert i in ids and i in conn.CONNECT_GUIDE
    seen = {}
    def fetch(method, url, **kw):
        seen["url"] = url; return {}
    assert conn.validate("datadog", "k", "", fetch)["ok"]
    assert "api.datadoghq.com/api/v1/validate" in seen["url"]


# ============ v1.2.0 scheduled scanning + global search =====================
def test_schedule_due_respects_interval():
    from openaid import continuous as C
    import datetime as dt
    now = dt.datetime(2026, 1, 1, 12, 0, tzinfo=dt.timezone.utc)
    assert C.due({"enabled": False, "last_run": None}, now) is False   # opt-in
    assert C.due({"enabled": True, "last_run": None}, now) is True     # never ran
    recent = (now - dt.timedelta(minutes=30)).isoformat()
    assert C.due({"enabled": True, "last_run": recent,
                  "interval_minutes": 360}, now) is False
    old = (now - dt.timedelta(minutes=400)).isoformat()
    assert C.due({"enabled": True, "last_run": old,
                  "interval_minutes": 360}, now) is True


def test_schedule_due_recovers_from_corrupt_timestamp():
    from openaid import continuous as C
    assert C.due({"enabled": True, "last_run": "garbage"}) is True


def test_mark_run_advances_next_run_and_counter():
    from openaid import continuous as C
    import datetime as dt
    now = dt.datetime(2026, 1, 1, 12, 0, tzinfo=dt.timezone.utc)
    s = C.mark_run({"enabled": True, "interval_minutes": 60, "runs": 2},
                   "3 new, 1 fixed", now)
    assert s["runs"] == 3 and s["last_headline"] == "3 new, 1 fixed"
    assert s["next_run"].startswith("2026-01-01T13:00")


def test_global_search_ranks_exact_over_substring():
    from openaid import search as S
    inv = {"agents": [
        {"id": "1", "name": "HR Bot", "platform": "copilot_studio",
         "environment": "prod", "anonymous": True},
        {"id": "2", "name": "HR Bot Helper", "platform": "copilot_studio",
         "environment": "dev"}]}
    out = S.search("HR Bot", inv)
    assert out["results"][0]["title"] == "HR Bot"        # exact first
    assert out["results"][0]["badge"] == "anonymous"
    assert out["totals"]["matches"] == 2


def test_global_search_spans_every_dataset():
    from openaid import search as S
    inv = {"agents": [{"id": "1", "name": "Atlas", "platform": "openai"}],
           "mcp_servers": [{"url": "https://atlas-mcp.io", "callers": 2, "auth": "none"}],
           "subscriptions": [{"id": "s1", "name": "Atlas Sub", "agents": 3}]}
    findings = [{"rule": "anonymous_agent", "title": "Atlas is anonymous",
                 "severity": "critical", "agent_id": "1"}]
    hier = [{"parent_name": "Atlas", "children": [
        {"id": "c1", "name": "Atlas Child", "type": "child"}]}]
    out = S.search("atlas", inv, findings, hier)
    kinds = out["totals"]["by_kind"]
    for k in ("agent", "finding", "relationship", "mcp_server", "subscription"):
        assert kinds.get(k), k
    assert all("tab" in r for r in out["results"])       # every hit is navigable


def test_global_search_empty_query_returns_nothing():
    from openaid import search as S
    out = S.search("", {"agents": [{"id": "1", "name": "X"}]})
    assert out["results"] == [] and out["totals"]["matches"] == 0


# ====== v1.3.0 Foundry new features + Bedrock + Anthropic SDK agents ========
def test_foundry_url_uses_agent_name_and_version():
    """Microsoft's azd deploy prints:
    https://ai.azure.com/.../build/agents/{agentName}/build?version=1"""
    meta = {"https://x.services.ai.azure.com/api/projects/p": {
        "arm_id": "/subscriptions/s/resourceGroups/rg/providers/"
                  "Microsoft.CognitiveServices/accounts/x",
        "project": "p", "subscription_id": "s", "subscription_name": "S"}}
    def fetch(method, url, **kw):
        if "assistants?api-version=v1" in url:
            return {"data": [{"id": "asst_9", "name": "basic-agent",
                              "model": "gpt-4o", "version": 3}]}
        return {}
    r = foundry_agents.collect(fetch, token="t", endpoints=list(meta), ep_meta=meta)
    u = r["descriptors"][0]["scope"]["portal_url"]
    assert "/build/agents/basic-agent/build" in u
    assert "version=3" in u


def test_foundry_flags_browser_automation_as_untrusted_content():
    from openaid.collectors import foundry_agents as F
    agent = {"tools": [{"type": "browser_automation"}, {"type": "code_interpreter"}]}
    rt = F.risky_tools(agent)
    assert "browser_automation" in rt and "code_interpreter" in rt


def test_foundry_detects_hosted_agent_framework():
    from openaid.collectors import foundry_agents as F
    assert F.framework_of({"definition": {"kind": "HostedAgentDefinition",
                                          "image": "acr.io/my-anthropic-agent"}}) \
        == "anthropic_agent_sdk"
    assert F.framework_of({"framework": "LangGraph"}) == "langgraph"
    assert F.framework_of({"definition": {"kind": "PromptAgentDefinition"}}) == ""


def test_bedrock_agents_collected_with_console_link():
    from openaid.collectors import third_party as tp
    def fetch(method, url, **kw):
        if "bedrock-agentcore-control" in url:      # new second surface (v1.9.2)
            return {"agentRuntimes": []}
        assert "bedrock-agent.eu-west-1.amazonaws.com/agents" in url
        return {"agentSummaries": [{"agentId": "AG123", "agentName": "OrderBot",
                                    "agentStatus": "PREPARED",
                                    "foundationModel": "anthropic.claude-3"}]}
    docs, errs = tp.bedrock_agents(fetch, "tok", "eu-west-1")
    assert not errs and docs[0]["name"] == "OrderBot"
    assert docs[0]["agent"]["platform"] == "aws_bedrock"
    assert "AG123" in docs[0]["scope"]["portal_url"]
    assert docs[0]["scope"]["environment"] == "aws:eu-west-1"


def test_bedrock_defaults_region_when_blank():
    from openaid.collectors import third_party as tp
    seen = {}
    def fetch(method, url, **kw):
        seen["url"] = url; return {"agentSummaries": []}
    tp.bedrock_agents(fetch, "tok", "")
    assert "us-east-1" in seen["url"]


def test_anthropic_workspaces_use_x_api_key_header():
    from openaid.collectors import third_party as tp
    seen = {}
    def fetch(method, url, **kw):
        seen["hdr"] = kw.get("headers", {})
        return {"data": [{"id": "wrkspc_1", "name": "Prod Claude"}]}
    docs, errs = tp.anthropic_agents(fetch, "sk-ant-x")
    assert not errs and docs[0]["name"] == "Prod Claude"
    # Anthropic authenticates with x-api-key, NOT a bearer token
    assert seen["hdr"]["x-api-key"] == "sk-ant-x"
    assert seen["hdr"]["anthropic-version"]


def test_bedrock_and_anthropic_registered_in_collector_registry():
    from openaid.collectors import third_party as tp
    assert tp.COLLECTORS["aws"][1] is True        # needs region in url field
    assert tp.COLLECTORS["anthropic"][1] is False


def test_browser_automation_tool_completes_the_trifecta():
    """Foundry's Browser Automation tool ingests fully untrusted web content
    AND provides an egress path — it must register on both legs."""
    from openaid import trifecta
    d = {"id": "f1", "name": "Web Agent",
         "agent": {"platform": "azure_foundry", "agent_type": "foundry_agent"},
         "scope": {}, "identity": {},
         "entitlements": [{"resource": "sharepoint:docs", "actions": ["read"]}],
         "endpoints": [], "links": [],
         "risk_hints": {"browser_automation": True,
                        "risky_tools": "browser_automation"}}
    r = trifecta.analyze_agent(d)
    assert r["status"] == "exploitable"
    assert "browser-automation" in r["legs"]["untrusted_content"]["evidence"]
    assert "browser-automation" in r["legs"]["external_comms"]["evidence"]


# ====== v1.4.0 New Foundry (nextgen) portal URL — verified against live =====
def test_encode_sub_uses_big_endian_guid_bytes():
    """VERIFIED against a real portal URL:
    a9307114-91f9-4e69-ab19-3fec0b52ef70 -> qTBxFJH5TmmrGT_sC1LvcA
    (.NET little-endian byte order gives FHEwqfmRaU6... and a broken link.)"""
    from openaid.collectors.foundry_agents import encode_sub
    assert encode_sub("a9307114-91f9-4e69-ab19-3fec0b52ef70") == "qTBxFJH5TmmrGT_sC1LvcA"
    assert encode_sub("not-a-guid") == ""
    assert "=" not in encode_sub("a9307114-91f9-4e69-ab19-3fec0b52ef70")  # unpadded


def test_nextgen_url_matches_live_portal_url_exactly():
    from openaid.collectors.foundry_agents import nextgen_url
    u = nextgen_url("a9307114-91f9-4e69-ab19-3fec0b52ef70", "rg-power-2089",
                    "power-2089-resource", "power-2089", "agentfoundary",
                    "e6c360d6-57a5-473e-9188-3bfac0e3250e")
    assert u == ("https://ai.azure.com/nextgen/r/qTBxFJH5TmmrGT_sC1LvcA,"
                 "rg-power-2089,,power-2089-resource,power-2089"
                 "/build/agents/agentfoundary/build"
                 "?tid=e6c360d6-57a5-473e-9188-3bfac0e3250e")


def test_nextgen_url_degrades_without_agent_or_tenant():
    from openaid.collectors.foundry_agents import nextgen_url
    u = nextgen_url("a9307114-91f9-4e69-ab19-3fec0b52ef70", "rg", "acct", "proj")
    assert u.endswith("/build/agents")          # project-level agent list
    assert "?tid=" not in u
    assert nextgen_url("", "rg", "a", "p", "x") == ""   # no sub -> no guess


def test_parse_arm_id_extracts_sub_rg_account():
    from openaid.collectors.foundry_agents import parse_arm_id
    a = parse_arm_id("/subscriptions/S1/resourceGroups/RG1/providers/"
                     "Microsoft.CognitiveServices/accounts/ACCT1")
    assert a == {"subscription": "S1", "resource_group": "RG1", "account": "ACCT1"}


def test_foundry_agent_primary_link_is_nextgen():
    meta = {"https://x.services.ai.azure.com/api/projects/power-2089": {
        "arm_id": "/subscriptions/a9307114-91f9-4e69-ab19-3fec0b52ef70"
                  "/resourceGroups/rg-power-2089/providers/"
                  "Microsoft.CognitiveServices/accounts/power-2089-resource",
        "project": "power-2089", "subscription_id": "a9307114-91f9-4e69-ab19-3fec0b52ef70",
        "subscription_name": "S", "tenant_id": "e6c360d6-57a5-473e-9188-3bfac0e3250e"}}
    def fetch(method, url, **kw):
        if "assistants?api-version=v1" in url:
            return {"data": [{"id": "asst_1", "name": "agentfoundary", "model": "gpt-4.1"}]}
        return {}
    r = foundry_agents.collect(fetch, token="t", endpoints=list(meta), ep_meta=meta)
    sc = r["descriptors"][0]["scope"]
    # primary now targets the agent PLAYGROUND (operator ask); build form
    # remains a candidate and is asserted byte-exact elsewhere.
    assert sc["portal_url"] == (
        "https://ai.azure.com/nextgen/r/qTBxFJH5TmmrGT_sC1LvcA,rg-power-2089,,"
        "power-2089-resource,power-2089/build/agents/agentfoundary/playground"
        "?tid=e6c360d6-57a5-473e-9188-3bfac0e3250e")
    # classic wsid forms remain as fallbacks in the resolver
    assert any("wsid=" in u for u in sc["portal_candidates"])


def test_copilot_emits_default_tenant_environment_variant():
    """PROVEN from a live portal URL:
    copilotstudio.microsoft.com/environments/Default-{tenantId}/home
    The default environment is addressed as Default-{tenantId}, not as the
    BAP environment GUID — so both spellings must be offered."""
    env_index = {"https://org.crm.dynamics.com": {
        "id": "eab176b4-5425-eb51-b36e-1aaec97da702", "name": "Prod",
        "tenant_id": "e6c360d6-57a5-473e-9188-3bfac0e3250e"}}
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [{"botid": "b1", "name": "A", "schemaname": "cr_a",
                               "authenticationmode": 2}]}
        return {"value": []}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert any("/environments/eab176b4-5425-eb51-b36e-1aaec97da702/" in u for u in c)
    assert any("/environments/Default-e6c360d6-57a5-473e-9188-3bfac0e3250e/" in u
               for u in c)
    # the verified-working /home form is present for BOTH spellings
    homes = [u for u in c if u.endswith("/home")]
    assert len(homes) == 2


# ================== v1.5.0 live platform feature news =======================
def test_news_parses_rss_and_filters_to_agent_topics():
    from openaid import news
    xml = """<rss><channel>
      <item><title>Foundry Agent Service adds Browser Automation</title>
        <link>https://a</link><description>New agent tool</description>
        <pubDate>Mon, 01 Jan 2026</pubDate></item>
      <item><title>Copilot Studio authentication changes</title>
        <link>https://b</link><description>Entra identity for agents</description></item>
      <item><title>Managed disks price cut</title><link>https://c</link>
        <description>storage</description></item>
    </channel></rss>"""
    out = news.parse_feed(xml, "Azure updates")
    titles = [i["title"] for i in out]
    assert len(out) == 2                      # unrelated storage item dropped
    assert any("Foundry" in t for t in titles)
    assert out[0]["source"] == "Azure updates"


def test_news_flags_security_relevant_items():
    from openaid import news
    topics, sec = news.classify("Copilot Studio agent update",
                                "adds Entra authentication and RBAC")
    assert "copilot_studio" in topics and sec is True
    topics2, sec2 = news.classify("Bedrock agents new region", "availability")
    assert "bedrock" in topics2 and sec2 is False


def test_news_parses_atom_feeds_too():
    from openaid import news
    atom = """<feed xmlns="http://www.w3.org/2005/Atom">
      <entry><title>Amazon Bedrock AgentCore now GA</title>
        <link href="https://aws.example/x"/>
        <summary>ai agent runtime</summary></entry></feed>"""
    out = news.parse_feed(atom, "AWS What's New")
    assert len(out) == 1 and out[0]["url"] == "https://aws.example/x"
    assert "bedrock" in out[0]["topics"]


def test_news_survives_malformed_feed_and_dead_source():
    from openaid import news
    assert news.parse_feed("<not xml", "X") == []
    def fetch_text(url):
        if "aws" in url:
            raise Exception("timeout")
        return """<rss><channel><item><title>Foundry agents update</title>
                  <link>https://a</link><description>agents</description>
                  </item></channel></rss>"""
    out = news.collect(fetch_text)
    assert out["totals"]["items"] >= 1          # working feeds still returned
    assert any(e["error"] == "timeout" for e in out["errors"])


def test_news_sorts_security_items_first():
    from openaid import news
    def fetch_text(url):
        return """<rss><channel>
          <item><title>Bedrock agents new region</title><link>https://a</link>
            <description>availability</description></item>
          <item><title>Foundry agent permissions hardening</title><link>https://b</link>
            <description>rbac and entra identity</description></item>
        </channel></rss>"""
    out = news.collect(fetch_text)
    assert out["items"][0]["security"] is True


def test_debug_links_reports_missing_url_inputs(monkeypatch):
    """A wrong portal link is almost always a MISSING INPUT (no tenant id, no
    schema name, no project). The diagnostic must name the missing field."""
    pytest.importorskip("fastapi", reason="web deps not installed locally")
    monkeypatch.setenv("OPENAID_DEMO", "1")
    monkeypatch.delenv("OPENAID_TENANT_ID", raising=False)
    from fastapi.testclient import TestClient
    import importlib, app.server as S
    importlib.reload(S)
    c = TestClient(S.app)
    r = c.get("/api/debug/links?demo=1")
    assert r.status_code == 200
    j = r.json()
    assert j["tenant_id_env"] is False
    assert j["agents"], "should list agents"
    a = j["agents"][0]
    for k in ("name", "platform", "primary_url", "candidates", "inputs", "missing"):
        assert k in a
    # with no tenant id configured, every agent flags it
    assert any("tenant_id" in x["missing"] for x in j["agents"])


# ========== v1.6.0 URLs verified against a live tenant (ground truth) ========
def test_copilot_primary_url_matches_live_working_url():
    """GROUND TRUTH from the operator's tenant:
    copilotstudio.microsoft.com/environments/eab176b4-5425-eb51-b36e-1aaec97da702
        /bots/dcbbdf14-aa93-f111-8075-70a8a59c3e95/overview
    BAP environment GUID + BOT ID. Not Default-{tenantId}. Not /agents/.
    Not the schema name."""
    env_index = {"https://org.crm.dynamics.com": {
        "id": "eab176b4-5425-eb51-b36e-1aaec97da702", "name": "DEV2",
        "tenant_id": "e6c360d6-57a5-473e-9188-3bfac0e3250e"}}
    def fetch(method, url, **kw):
        if "bots?" in url:
            return {"value": [{"botid": "dcbbdf14-aa93-f111-8075-70a8a59c3e95",
                               "name": "sentinalmcptestproject",
                               "schemaname": "cr6bd_sentinal",
                               "authenticationmode": 2}]}
        return {"value": []}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    sc = r["descriptors"][0]["scope"]
    expected = ("https://copilotstudio.microsoft.com/environments/"
                "eab176b4-5425-eb51-b36e-1aaec97da702/copilots/"
                "dcbbdf14-aa93-f111-8075-70a8a59c3e95/details")
    assert sc["portal_url"] == expected
    assert sc["portal_candidates"][0] == expected     # first thing tried


def test_foundry_nextgen_link_always_carries_tid(monkeypatch):
    """The New Foundry portal REDIRECTS to the project home when ?tid= is
    missing — which looks exactly like a wrong URL. The tenant id must be
    guaranteed even when discovery metadata lacked it."""
    monkeypatch.setenv("OPENAID_TENANT_ID", "e6c360d6-57a5-473e-9188-3bfac0e3250e")
    from openaid.inventory import _portal_link
    d = {"agent": {"platform": "azure_foundry", "native_id": "asst_1"},
         "scope": {"portal_url": ("https://ai.azure.com/nextgen/r/enc,rg,,acct,proj"
                                  "/build/agents/agentfoundary/build")},
         "risk_hints": {}}
    u = _portal_link(d)
    assert u.endswith("?tid=e6c360d6-57a5-473e-9188-3bfac0e3250e")
    # already-tagged links are not double-tagged
    d["scope"]["portal_url"] = u
    assert _portal_link(d).count("tid=") == 1


# ============== v1.6.0 DLP coverage (top Power Platform community ask) ======
def test_dlp_flags_environments_with_no_policy_holding_agents():
    from openaid import dlp
    policies = [{"displayName": "Corp", "environmentType": "OnlyEnvironments",
                 "environments": {"environmentType": "OnlyEnvironments",
                                  "environments": [{"name": "e1"}]},
                 "connectorGroups": [
                     {"classification": "Blocked", "connectors": [{"name": "shared_twitter"}]},
                     {"classification": "General", "connectors": [{"name": "shared_sendmail"}]}]}]
    envs = [{"id": "e1", "name": "Prod"}, {"id": "e2", "name": "Dev"}]
    agents = [{"environment_id": "e2"}, {"environment_id": "e1"}]
    out = dlp.analyze(policies, envs, agents)
    by = {r["environment"]: r for r in out["rows"]}
    assert by["Dev"]["covered"] is False and by["Dev"]["risk"] == "critical"
    assert by["Prod"]["covered"] is True
    assert out["totals"]["agents_without_dlp"] == 1
    assert out["totals"]["coverage_pct"] == 50
    # uncovered environments sort to the top
    assert out["rows"][0]["environment"] == "Dev"


def test_dlp_scope_kinds_all_only_except():
    from openaid import dlp
    all_env = {"environmentType": "AllEnvironments"}
    only = {"environmentType": "OnlyEnvironments",
            "environments": {"environmentType": "OnlyEnvironments",
                             "environments": [{"name": "e1"}]}}
    exc = {"environmentType": "ExceptEnvironments",
           "environments": {"environmentType": "ExceptEnvironments",
                            "environments": [{"name": "e1"}]}}
    assert dlp.applies_to(all_env, "anything") is True
    assert dlp.applies_to(only, "e1") is True and dlp.applies_to(only, "e2") is False
    assert dlp.applies_to(exc, "e1") is False and dlp.applies_to(exc, "e2") is True


def test_dlp_surfaces_risky_allowed_connectors():
    from openaid import dlp
    policies = [{"displayName": "P", "environmentType": "AllEnvironments",
                 "connectorGroups": [{"classification": "General",
                                      "connectors": [{"name": "shared_sendmail"},
                                                     {"name": "shared_office365"},
                                                     {"name": "shared_kusto"}]}]}]
    out = dlp.analyze(policies, [{"id": "e1", "name": "E"}], [])
    r = out["rows"][0]
    assert r["covered"] and r["risk"] == "medium"
    assert any("sendmail" in c for c in r["risky_allowed"])


def test_dlp_reports_missing_token_cleanly():
    from openaid import dlp
    pol, errs = dlp.fetch_policies(lambda *a, **k: {}, "")
    assert pol == [] and "no Power Platform token" in errs[0]["error"]


# ------------------------------------------------- v1.6.1 URL + tid fixes
def test_with_tid_scoped_to_foundry_only(monkeypatch):
    """tid is REQUIRED on ai.azure.com (multi-directory bounce) but must NOT
    touch Copilot Studio links: Microsoft's own deepLinkUrl metadata carries
    no tid, and an unknown param is one more way to bounce home."""
    monkeypatch.setenv("OPENAID_TENANT_ID", "tid-42")
    from openaid.inventory import _with_tid
    assert _with_tid("https://ai.azure.com/build/agents/a1/build?wsid=/s/x"
                     ).endswith("&tid=tid-42")
    cs = "https://copilotstudio.microsoft.com/environments/e/copilots/b/details"
    assert _with_tid(cs) == cs
    already = "https://ai.azure.com/x?tid=other"
    assert _with_tid(already) == already
    other = "https://console.aws.amazon.com/bedrock/home"
    assert _with_tid(other) == other


def test_go_agent_appends_tid_to_classic_foundry_and_copilot(monkeypatch):
    pytest.importorskip("fastapi")   # server deps live in the container image
    monkeypatch.setenv("OPENAID_TENANT_ID", "tid-77")
    from app import server
    import re as _re
    html = server.go_agent(agent_id=_first_agent_id(server), demo=1).body.decode()
    links = _re.findall(r"https://(?:ai\.azure\.com|copilotstudio\.microsoft\.com)[^'\"<]+", html)
    assert links, "resolver page shows no Microsoft portal links"
    assert all("tid=tid-77" in u for u in links)


def _first_agent_id(server):
    g = server.api_graph(demo=1)
    agents = (g.get("inventory") or {}).get("agents", [])
    a = next((x for x in agents if (x.get("portal_candidates") or [])), agents[0])
    return a["id"]


def test_child_swap_handles_canonical_details_suffix():
    u = "https://copilotstudio.microsoft.com/environments/e/copilots/b/details"
    assert u.replace("/overview", "/agents").replace("/details", "/agents").endswith(
        "/copilots/b/agents")


def test_news_endpoint_serves_digest_and_timestamp(monkeypatch):
    """/api/news must answer from the warm cache with a digest (the SSE
    stream keys off it) and a refreshed_at stamp (the UI 'updated Xs ago')."""
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    fake = {"items": [{"url": "https://x/a", "title": "T"}], "totals": {"items": 1}}
    monkeypatch.setattr(server.news_mod, "collect", lambda _f: dict(fake))
    data = server.api_news(refresh=1)
    assert data["digest"] and len(data["digest"]) == 16
    assert data["refreshed_at"]
    # warm-cache path returns the same object without re-collecting
    monkeypatch.setattr(server.news_mod, "collect",
                        lambda _f: (_ for _ in ()).throw(RuntimeError("must not pull")))
    assert server.api_news()["digest"] == data["digest"]


def test_news_digest_changes_when_items_change(monkeypatch):
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setattr(server.news_mod, "collect",
                        lambda _f: {"items": [{"url": "https://x/a", "title": "A"}]})
    d1 = server.api_news(refresh=1)["digest"]
    monkeypatch.setattr(server.news_mod, "collect",
                        lambda _f: {"items": [{"url": "https://x/b", "title": "B"}]})
    d2 = server.api_news(refresh=1)["digest"]
    assert d1 != d2


def test_news_stream_route_registered():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    paths = [r.path for r in server.app.routes]
    assert "/api/news/stream" in paths


# --------------------------------------------- v1.6.2 empirical link resolver
def test_default_env_copilot_candidates_lead_with_default_addressing():
    """Agents in the DEFAULT environment bounce to the Copilot Studio home
    page when addressed by the BAP GUID — Default-{tenantId} must go first."""
    from openaid.collectors import copilot_studio

    def fetch(method, url, headers=None, **kw):
        if "bots" in url and "botcomponents" not in url:
            return {"value": [{"botid": "bot-1", "name": "A", "schemaname": "cr1_a",
                               "publishedon": "2026-01-01"}]}
        return {"value": []}

    env_index = {"https://org.crm.dynamics.com": {
        "id": "env-guid-5", "name": "Contoso (default)",
        "tenant_id": "tid-9", "is_default": True}}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert c[0] == ("https://copilotstudio.microsoft.com/environments/"
                    "Default-tid-9/copilots/bot-1/details")
    # GUID addressing still present as fallback
    assert any("/environments/env-guid-5/" in u for u in c)


def test_named_env_copilot_candidates_lead_with_guid():
    from openaid.collectors import copilot_studio

    def fetch(method, url, headers=None, **kw):
        if "bots" in url and "botcomponents" not in url:
            return {"value": [{"botid": "bot-1", "name": "A", "schemaname": "cr1_a",
                               "publishedon": "2026-01-01"}]}
        return {"value": []}

    env_index = {"https://org.crm.dynamics.com": {
        "id": "env-guid-6", "name": "Prod", "tenant_id": "tid-9",
        "is_default": False}}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert c[0] == ("https://copilotstudio.microsoft.com/environments/"
                    "env-guid-6/copilots/bot-1/details")


def test_foundry_candidates_include_ga_root_variant():
    """Portal GA'd July 2026; GA portals drop the preview prefix — the same
    addressing without /nextgen must be one of the candidates."""
    from openaid.collectors.foundry_agents import nextgen_url
    ng = nextgen_url("a9307114-91f9-4e69-ab19-3fec0b52ef70", "rg", "acct",
                     "proj", "agentA", "tid-1")
    assert "/nextgen/r/" in ng
    ga = ng.replace("/nextgen/r/", "/r/")
    assert "/nextgen/" not in ga and "ai.azure.com/r/" in ga


def test_link_shape_classifier_and_prefs(tmp_path, monkeypatch):
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setattr(server, "_LINK_PREFS_PATH", str(tmp_path / "p.json"))
    if hasattr(server._link_prefs, "_cache"):
        del server._link_prefs._cache
    assert server._link_shape(
        "https://ai.azure.com/nextgen/r/x,rg,,a,p/build/agents/n/build?tid=t"
    ) == "foundry_nextgen_agent"
    assert server._link_shape(
        "https://copilotstudio.microsoft.com/environments/Default-t/copilots/b/details"
    ) == "cs_new_default"
    out = server.api_links_prefer(platform="copilot_studio", shape="cs_new_default")
    assert out["prefs"]["copilot_studio"] == "cs_new_default"
    out = server.api_links_prefer(platform="copilot_studio", shape="")
    assert "copilot_studio" not in out["prefs"]


def test_go_agent_leads_with_learned_shape(monkeypatch, tmp_path):
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setattr(server, "_LINK_PREFS_PATH", str(tmp_path / "p.json"))
    if hasattr(server._link_prefs, "_cache"):
        del server._link_prefs._cache
    aid = _first_agent_id(server)
    g = server.api_graph(demo=1)
    a = next(x for x in (g["inventory"]["agents"]) if x["id"] == aid)
    shapes = [server._link_shape(u) for u in (a.get("portal_candidates") or [])]
    if len(set(shapes)) < 2:
        pytest.skip("demo agent has a single link shape")
    target = shapes[-1]
    server.api_links_prefer(platform=a.get("platform", ""), shape=target)
    html = server.go_agent(agent_id=aid, demo=1).body.decode()
    first_url = html.split("id='p' href='", 1)[1].split("'", 1)[0]
    assert server._link_shape(first_url) == target


def test_foundry_nextgen_matches_live_tenant_url_byte_for_byte():
    """GROUND TRUTH pasted from the live portal on 2026-08-23. If this ever
    fails, the portal moved again — update nextgen_url, not the test."""
    from openaid.collectors.foundry_agents import nextgen_url
    u = nextgen_url("a9307114-91f9-4e69-ab19-3fec0b52ef70", "rg-power-2089",
                    "power-2089-resource", "power-2089", "agentfoundary",
                    "e6c360d6-57a5-473e-9188-3bfac0e3250e")
    assert u == ("https://ai.azure.com/nextgen/r/qTBxFJH5TmmrGT_sC1LvcA,"
                 "rg-power-2089,,power-2089-resource,power-2089/build/agents/"
                 "agentfoundary/build?tid=e6c360d6-57a5-473e-9188-3bfac0e3250e")


def test_foundry_unnamed_agent_leads_with_project_list_not_id_in_name_slot():
    """An agent with no name must NOT be addressed as /build/agents/asst_x/
    (name slot) — that bounces to the portal home. Project list goes first."""
    from openaid.collectors import foundry_agents as fa

    calls = {"n": 0}
    def fetch(method, url, headers=None, **kw):
        if "/assistants" in url or "/agents" in url:
            return {"data": [{"id": "asst_9", "name": "", "model": "gpt-4o"}]}
        return {}
    ep = "https://acct.services.ai.azure.com/api/projects/power-2089"
    meta = {ep: {"arm_id": "/subscriptions/a9307114-91f9-4e69-ab19-3fec0b52ef70/"
                           "resourceGroups/rg-power-2089/providers/"
                           "Microsoft.CognitiveServices/accounts/power-2089-resource",
                 "project": "power-2089", "subscription_id": "a9307114",
                 "tenant_id": "t1"}}
    r = fa.collect(fetch, token="tok", endpoints=[ep], ep_meta=meta)
    d = [x for x in r["descriptors"] if x["agent"]["native_id"] == "asst_9"][0]
    c = d["scope"]["portal_candidates"]
    assert "/build/agents/asst_9/build" not in c[0]
    assert c[0].endswith("?tid=t1") and "/nextgen/r/" in c[0]
    # the id-addressed classic form is still available as a late fallback
    assert any("asst_9" in u for u in c)


def _fake_jwt(exp_offset_s: int) -> str:
    import base64, json, time
    hdr = base64.urlsafe_b64encode(b'{"alg":"none"}').decode().rstrip("=")
    body = base64.urlsafe_b64encode(json.dumps(
        {"exp": int(time.time()) + exp_offset_s}).encode()).decode().rstrip("=")
    return f"{hdr}.{body}.x"


def test_token_expiry_report_flags_dead_tokens(monkeypatch):
    """Dead deploy-injected tokens make agents silently vanish — the report
    (and the red UI banner it feeds) must name exactly which scope died."""
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setenv("OPENAID_DATAVERSE_TOKEN", _fake_jwt(-300))   # dead
    monkeypatch.setenv("OPENAID_FOUNDRY_TOKEN", _fake_jwt(1800))     # alive
    monkeypatch.delenv("OPENAID_ARM_TOKEN", raising=False)
    r = server._token_expiry_report()
    assert "Dataverse (Copilot Studio agents)" in r["expired"]
    assert all("Foundry" not in e for e in r["expired"])
    assert r["min_minutes_left"] is not None and r["min_minutes_left"] <= 0
    assert server.api_auth_tokens() == r


def test_foundry_named_agent_keeps_groundtruth_primary_with_id_fallback():
    from openaid.collectors import foundry_agents as fa
    def fetch(method, url, headers=None, **kw):
        if "/assistants" in url or "/agents" in url:
            return {"data": [{"id": "asst_7", "name": "agentfoundary",
                              "model": "gpt-4o"}]}
        return {}
    ep = "https://acct.services.ai.azure.com/api/projects/power-2089"
    meta = {ep: {"arm_id": "/subscriptions/a9307114-91f9-4e69-ab19-3fec0b52ef70/"
                           "resourceGroups/rg-power-2089/providers/"
                           "Microsoft.CognitiveServices/accounts/power-2089-resource",
                 "project": "power-2089", "subscription_id": "a9307114",
                 "tenant_id": "e6c360d6-57a5-473e-9188-3bfac0e3250e"}}
    r = fa.collect(fetch, token="tok", endpoints=[ep], ep_meta=meta)
    d = [x for x in r["descriptors"] if x["agent"]["native_id"] == "asst_7"][0]
    c = d["scope"]["portal_candidates"]
    # PRIMARY: the agent's PLAYGROUND (sibling route of the proven build page)
    assert c[0] == ("https://ai.azure.com/nextgen/r/qTBxFJH5TmmrGT_sC1LvcA,"
                    "rg-power-2089,,power-2089-resource,power-2089/build/agents/"
                    "agentfoundary/playground?tid=e6c360d6-57a5-473e-9188-3bfac0e3250e")
    # the byte-proven /build URL remains a candidate, unchanged
    assert ("https://ai.azure.com/nextgen/r/qTBxFJH5TmmrGT_sC1LvcA,"
            "rg-power-2089,,power-2089-resource,power-2089/build/agents/"
            "agentfoundary/build?tid=e6c360d6-57a5-473e-9188-3bfac0e3250e") in c
    assert any("/build/agents/asst_7/build?tid=" in u and "/nextgen/" in u for u in c)


# ---------------------------------- v1.6.5 inventory-API ground-truth ids
def test_inventory_agent_id_overrides_botid_in_primary():
    """REGRESSION LOCK (v1.9.1): the Dataverse botid form is the one
    CONFIRMED WORKING in the live tenant. The Inventory API id is a
    different identifier space — it broke working links when it led, so it
    must trail as a fallback and NEVER be the primary."""
    from openaid.collectors import copilot_studio

    def fetch(method, url, headers=None, **kw):
        if "resourcequery" in url:
            return {"data": [{"name": "inv-agent-77", "properties": {
                "displayName": "A", "schemaName": "cr1_a",
                "environmentId": "env-guid-9"}}]}
        if "bots" in url and "botcomponents" not in url:
            return {"value": [{"botid": "bot-dv-1", "name": "A",
                               "schemaname": "cr1_a",
                               "publishedon": "2026-01-01"}]}
        return {"value": []}

    env_index = {"https://org.crm.dynamics.com": {
        "id": "env-guid-9", "name": "Prod", "tenant_id": "t", "is_default": False}}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index, pp_token="pp-tok")
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    # PRIMARY = the proven Dataverse botid form
    assert c[0] == ("https://copilotstudio.microsoft.com/environments/"
                    "env-guid-9/copilots/bot-dv-1/details")
    # inventory id present as a LATE fallback, after every botid form
    inv = [i for i, u in enumerate(c) if "inv-agent-77" in u]
    bot = [i for i, u in enumerate(c) if "bot-dv-1" in u]
    assert inv and bot and min(inv) > max(bot)


def test_inventory_failure_never_breaks_collection():
    from openaid.collectors import copilot_studio

    def fetch(method, url, headers=None, **kw):
        if "resourcequery" in url:
            raise RuntimeError("403 from inventory")
        if "bots" in url and "botcomponents" not in url:
            return {"value": [{"botid": "b1", "name": "A", "schemaname": "s",
                               "publishedon": "2026-01-01"}]}
        return {"value": []}

    env_index = {"https://org.crm.dynamics.com": {"id": "e", "name": "Prod",
                                                  "tenant_id": "t"}}
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index, pp_token="pp-tok")
    assert r["descriptors"], "inventory outage must not hide agents"


def test_all_agent_anchor_sites_route_through_resolver():
    """AUDIT, frozen as a test: no screen may link an agent's raw portal_url
    — every anchor goes through hrefById/agentHref so the learning resolver
    covers the whole app."""
    import re as _re
    html = (pathlib.Path(__file__).resolve().parents[1]
            / "app" / "static" / "index.html").read_text(encoding="utf-8")
    raw = _re.findall(r'href="\$\{esc\((?:a|t|r|c|h)\.portal_url\)\}"', html)
    assert raw == [], f"raw agent portal_url anchors found: {raw}"


# ------------------------------------------------ v1.7 Agent Hygiene Center
def test_hygiene_flags_orphaned_inactive_anonymous():
    from datetime import datetime, timezone
    from openaid import hygiene
    now = datetime(2026, 8, 23, tzinfo=timezone.utc)
    agents = [
        {"id": "a1", "name": "NoOwner", "platform": "copilot_studio",
         "owner_id": "", "modified_on": "2026-08-01T00:00:00Z",
         "anonymous": False},
        {"id": "a2", "name": "Sleepy", "platform": "copilot_studio",
         "owner_id": "u1", "modified_on": "2025-12-01T00:00:00Z",
         "anonymous": False},
        {"id": "a3", "name": "OpenDoor", "platform": "copilot_studio",
         "owner_id": "u2", "modified_on": "2026-08-20T00:00:00Z",
         "anonymous": True},
        {"id": "a4", "name": "Healthy", "platform": "copilot_studio",
         "owner_id": "u3", "modified_on": "2026-08-22T00:00:00Z",
         "anonymous": False},
        {"id": "a5", "name": "FoundryNoOwnerField", "platform": "azure_foundry",
         "owner_id": "", "modified_on": "", "anonymous": False},
    ]
    rep = hygiene.analyze(agents, now=now)
    assert [r["name"] for r in rep["orphaned"]] == ["NoOwner"]
    assert [r["name"] for r in rep["inactive"]] == ["Sleepy"]
    assert [r["name"] for r in rep["anonymous"]] == ["OpenDoor"]
    # foundry without ownership data must NOT be counted orphaned
    assert all(r["platform"] != "azure_foundry" for r in rep["orphaned"])
    assert rep["score"] == 100 - 12 - 4 - 15
    assert rep["grade"] in ("A", "B", "C", "D", "F")
    assert rep["totals"]["clean"] == 2


def test_hygiene_perfect_tenant_scores_100():
    from openaid import hygiene
    rep = hygiene.analyze([{"id": "a", "name": "x", "platform": "copilot_studio",
                            "owner_id": "u", "modified_on": "2099-01-01T00:00:00Z",
                            "anonymous": False}])
    assert rep["score"] == 100 and rep["grade"] == "A"
    assert "clean" in rep["headline"].lower()


def test_api_hygiene_endpoint_serves_report():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    rep = server.api_hygiene(demo=1)
    for key in ("score", "grade", "orphaned", "inactive", "anonymous", "totals"):
        assert key in rep
    assert 0 <= rep["score"] <= 100


# --------------------------------------------- v1.7.1 Foundry X-Ray + playground
def test_foundry_xray_traces_every_surface_attempt():
    from openaid.collectors import foundry_agents as fa

    def fetch(method, url, headers=None, **kw):
        if "agents?api-version=v1" in url:
            return {"data": [{"id": "asst_1", "name": "A", "model": "gpt-4o"}]}
        raise RuntimeError("404 route gone")
    ep = "https://acct.services.ai.azure.com/api/projects/p"
    meta = {ep: {"arm_id": "/subscriptions/a9307114-91f9-4e69-ab19-3fec0b52ef70/"
                           "resourceGroups/rg/providers/Microsoft.CognitiveServices/"
                           "accounts/x", "project": "p", "tenant_id": "t"}}
    r = fa.collect(fetch, token="t", endpoints=[ep], ep_meta=meta)
    assert r["descriptors"], "agents must list from the new /agents surface"
    assert fa.XRAY, "X-Ray must trace attempts"
    oks = [x for x in fa.XRAY if x["result"].startswith("OK")]
    errs = [x for x in fa.XRAY if x["result"].startswith("ERROR")]
    assert oks and errs
    assert any("agents?api-version=v1" in x["surface"] for x in oks)


def test_new_agents_surface_swept_before_retired_assistants():
    from openaid.collectors.foundry_agents import _SURFACES
    paths = [p for p, _, _ in _SURFACES]
    first_agents = next(i for i, p in enumerate(paths) if p.startswith("agents"))
    first_assist = next(i for i, p in enumerate(paths) if p.startswith("assistants"))
    assert first_agents < first_assist, (
        "Assistants API retires 2026-08-26 — /agents must be swept first")
    assert "agents?api-version=2025-11-15-preview" in paths


def test_playground_shape_labels():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    u = ("https://ai.azure.com/nextgen/r/x,rg,,a,p/build/agents/n/playground?tid=t")
    assert server._link_shape(u) == "foundry_nextgen_playground"
    assert "PLAYGROUND" in server._SHAPE_LABEL["foundry_nextgen_playground"]


def test_api_debug_foundry_reports_shape():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    r = server.api_debug_foundry(demo=1)
    for k in ("foundry_agents_found", "token_audience", "expected_audience",
              "attempts", "note"):
        assert k in r


# ------------------------------------------------- v1.8 Agent Pipelines
def _pipe_fetch_factory(store):
    def fetch(method, url, headers=None, json=None, **kw):
        store.setdefault("calls", []).append((method, url))
        if method == "GET" and "/bots(" in url:
            return {"botid": "src-bot", "name": "Sales Agent",
                    "schemaname": "cr1_sales", "language": 1033}
        if method == "GET" and "botcomponents" in url:
            return {"value": [
                {"name": "Greeting", "schemaname": "cr1_greet",
                 "componenttype": 0, "content": "{...}"},
                {"name": "Escalate", "schemaname": "cr1_esc",
                 "componenttype": 0, "content": "{...}"}]}
        if method == "POST" and url.endswith("/bots"):
            store["bot_body"] = json
            return {"botid": "new-bot-9"}
        if method == "POST" and url.endswith("/botcomponents"):
            store.setdefault("comps", []).append(json)
            return {}
        return {}
    return fetch


def test_pipeline_copilot_clone_copies_bot_and_components():
    from openaid import pipelines
    store = {}
    r = pipelines.copilot_clone(
        _pipe_fetch_factory(store),
        source_org_url="https://src.crm.dynamics.com", bot_id="src-bot",
        target_org_url="https://dst.crm.dynamics.com",
        source_token="s", target_token="t", new_name="Sales Agent (UAT)")
    assert r["ok"] and r["new_bot_id"] == "new-bot-9"
    assert store["bot_body"]["name"] == "Sales Agent (UAT)"
    assert store["bot_body"]["schemaname"] != "cr1_sales"  # clash-proof
    assert len(store["comps"]) == 2
    assert all(c["parentbotid@odata.bind"] == "/bots(new-bot-9)"
               for c in store["comps"])
    assert any("environment-scoped" in st for st in r["steps"])


def test_pipeline_copilot_refuses_same_environment():
    from openaid import pipelines
    r = pipelines.copilot_clone(
        lambda **k: {}, source_org_url="https://x.crm.dynamics.com",
        bot_id="b", target_org_url="https://x.crm.dynamics.com/",
        source_token="s", target_token="t")
    assert not r["ok"] and "same" in r["detail"]


def test_pipeline_foundry_clone_strips_server_fields():
    from openaid import pipelines
    store = {}
    def fetch(method, url, headers=None, json=None, **kw):
        if method == "GET" and "agents/agt-1" in url:
            return {"id": "agt-1", "name": "Orch", "model": "gpt-4o",
                    "instructions": "help", "created_at": 123,
                    "versions": [{"v": 1}], "object": "agent"}
        if method == "POST" and "agents?api-version=v1" in url:
            store["body"] = json
            return {"id": "agt-new", "name": json.get("name", "")}
        raise RuntimeError("404")
    r = pipelines.foundry_clone(
        fetch, source_endpoint="https://a.services.ai.azure.com/api/projects/p1",
        agent_id="agt-1",
        target_endpoint="https://b.services.ai.azure.com/api/projects/p2",
        token="tok")
    assert r["ok"] and r["new_agent_id"] == "agt-new"
    for f in ("id", "created_at", "versions", "object"):
        assert f not in store["body"]
    assert store["body"]["instructions"] == "help"


def test_pipeline_endpoints_registered():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    paths = [r.path for r in server.app.routes]
    assert "/api/pipeline/targets" in paths
    assert "/api/pipeline/deploy" in paths


# ------------------------------------------- v1.8.1 pipeline fixes + upgrades
def test_pipeline_preflight_copilot_reachable_and_clash():
    from openaid import pipelines
    def fetch(method, url, headers=None, **kw):
        if "WhoAmI" in url:
            return {"UserId": "u-1"}
        if "startswith(schemaname" in url:
            return {"value": [{"botid": "x"}]}
        return {}
    r = pipelines.copilot_preflight(fetch, target_org_url="https://d.crm.dynamics.com",
                                    target_token="t", schema_hint="cr1_sales")
    assert r["ok"]
    clash = [c for c in r["checks"] if c["check"] == "name clash in target"][0]
    assert not clash["ok"] and "1 similar" in clash["detail"]


def test_pipeline_preflight_foundry_unreachable():
    from openaid import pipelines
    def fetch(method, url, headers=None, **kw):
        raise RuntimeError("403 Forbidden")
    r = pipelines.foundry_preflight(fetch, target_endpoint="https://x/api/projects/p",
                                    token="t")
    assert not r["ok"] and all(not c["ok"] for c in r["checks"])


def test_pipeline_bulk_deploy_and_history(monkeypatch, tmp_path):
    pytest.importorskip("fastapi")   # server deps live in the container image
    import asyncio
    from app import server
    monkeypatch.setattr(server, "_PIPE_HISTORY_PATH", str(tmp_path / "h.json"))
    if hasattr(server._pipe_history, "_cache"):
        del server._pipe_history._cache
    monkeypatch.setattr(server.pipelines, "foundry_clone",
                        lambda *a, **k: {"ok": True, "steps": ["s"],
                                         "detail": "cloned",
                                         "new_agent_id": "n1"})

    class _Req:
        async def json(self):
            return {"agents": [
                {"platform": "azure_foundry", "agent_id": "a1",
                 "agent_name": "One", "source_endpoint": "https://s/api/projects/p",
                 "target_endpoint": "https://t/api/projects/q"},
                {"platform": "azure_openai", "agent_id": "a2",
                 "agent_name": "Two", "source_endpoint": "https://s/api/projects/p",
                 "target_endpoint": "https://t/api/projects/q"}]}

    out = asyncio.get_event_loop().run_until_complete(
        server.api_pipeline_deploy(_Req()))
    assert out["ok"] and len(out["results"]) == 2
    hist = server.api_pipeline_history()["runs"]
    assert [h["agent"] for h in hist[:2]] == ["Two", "One"]
    assert all(h["ok"] for h in hist[:2])


def test_pipeline_picker_includes_azure_openai_assistants():
    """REGRESSION: assistants collected under platform azure_openai are
    deployable via the Foundry lane and must never vanish from the picker."""
    html = (pathlib.Path(__file__).resolve().parents[1]
            / "app" / "static" / "index.html").read_text(encoding="utf-8")
    assert "'copilot_studio','azure_foundry','azure_openai'" in html
    assert "envUrlMap" in html          # source-url fallback exists
    assert "pipePreflight" in html and "pipeHistoryHtml" in html


# ---------------------------------------- v1.8.2 pipeline progress + targets
def test_pipeline_clone_emits_monotonic_progress():
    from openaid import pipelines
    store, events = {}, []
    r = pipelines.copilot_clone(
        _pipe_fetch_factory(store),
        source_org_url="https://src.crm.dynamics.com", bot_id="src-bot",
        target_org_url="https://dst.crm.dynamics.com",
        source_token="s", target_token="t",
        emit=lambda step, pct: events.append((step, pct)))
    assert r["ok"] and events
    pcts = [p for _, p in events]
    assert pcts == sorted(pcts), "progress must never go backwards"
    assert pcts[-1] == 100 and pcts[0] <= 20


def test_pipeline_targets_unions_bap_and_inventory(monkeypatch):
    """A dead BAP token must never empty the target dropdown — inventory
    environments fill in, and the BAP error is surfaced, not swallowed."""
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setenv("OPENAID_BAP_TOKEN", "dead-token")
    from openaid.collectors import powerplatform_envs as ppe
    monkeypatch.setattr(ppe, "collect",
                        lambda *a, **k: (_ for _ in ()).throw(
                            RuntimeError("401 token expired")))
    out = server.api_pipeline_targets(demo=1)
    assert "401" in out["bap_error"]
    assert isinstance(out["powerplatform"], list)
    assert all(e.get("org_url") for e in out["powerplatform"])


def test_pipeline_deploy_stream_yields_ndjson_events(monkeypatch, tmp_path):
    pytest.importorskip("fastapi")   # server deps live in the container image
    import json
    from fastapi.testclient import TestClient
    from app import server
    monkeypatch.setattr(server, "_PIPE_HISTORY_PATH", str(tmp_path / "h.json"))
    if hasattr(server._pipe_history, "_cache"):
        del server._pipe_history._cache

    def fake_clone(*a, emit=None, **k):
        if emit:
            emit("reading", 35)
            emit("creating", 90)
        return {"ok": True, "steps": ["reading", "creating"], "detail": "cloned",
                "new_agent_id": "n1"}
    monkeypatch.setattr(server.pipelines, "foundry_clone", fake_clone)
    c = TestClient(server.app)
    with c.stream("POST", "/api/pipeline/deploy_stream", json={"agents": [
            {"platform": "azure_foundry", "agent_id": "a1", "agent_name": "One",
             "source_endpoint": "https://s/api/projects/p",
             "target_endpoint": "https://t/api/projects/q"}]}) as resp:
        lines = [json.loads(l) for l in resp.iter_lines() if l]
    kinds = [l["event"] for l in lines]
    assert kinds[:2] == ["step", "step"]
    assert "done" in kinds and kinds[-1] == "all_done"
    done = [l for l in lines if l["event"] == "done"][0]
    assert done["ok"] and done["agent"] == "One"


# -------------------------------------------------- v1.9 Command Center
def test_analytics_build_daily_series_and_wow_delta():
    from datetime import datetime, timedelta, timezone
    from openaid import analytics
    now = datetime(2026, 8, 23, 12, tzinfo=timezone.utc)
    rows = []
    # 3/day this week, 1/day previous week for one agent
    for d in range(7):
        rows.append({"bot_id": "b1", "createdon":
                     (now - timedelta(days=d)).isoformat()})
        rows.append({"bot_id": "b1", "createdon":
                     (now - timedelta(days=d, hours=1)).isoformat()})
        rows.append({"bot_id": "b1", "createdon":
                     (now - timedelta(days=d, hours=2)).isoformat()})
    for d in range(7, 14):
        rows.append({"bot_id": "b1", "createdon":
                     (now - timedelta(days=d)).isoformat()})
    agents = [{"id": "a1", "native_id": "b1", "name": "Sales",
               "platform": "copilot_studio", "environment": "Prod",
               "created_on": "2026-06-05T00:00:00Z"}]
    out = analytics.build(rows, agents, hygiene_score=88, now=now)
    assert out["kpis"]["sessions_7d"] == 21
    assert out["kpis"]["sessions_prev_7d"] == 7
    assert out["kpis"]["delta_pct"] == 200
    assert sum(out["daily"]) == 28 and len(out["daily"]) == analytics.DAYS
    assert sum(sum(r) for r in out["heatmap"]) == 28
    lead = out["leaderboard"][0]
    assert lead["name"] == "Sales" and lead["sessions_7d"] == 21
    assert len(lead["spark"]) == analytics.DAYS
    assert out["environments"][0]["environment"] == "Prod"
    assert out["kpis"]["active_agents"] == 1
    assert any(a["month"] == "2026-06" and a["created"] == 1
               for a in out["adoption"])


def test_analytics_demo_rows_deterministic():
    from openaid import analytics
    agents = [{"id": "a1", "native_id": "b1", "name": "X",
               "platform": "copilot_studio"}]
    from datetime import datetime, timezone
    now = datetime(2026, 8, 23, 12, tzinfo=timezone.utc)
    r1 = analytics.demo_rows(agents, now=now)
    r2 = analytics.demo_rows(agents, now=now)
    assert r1 and [x["createdon"] for x in r1] == [x["createdon"] for x in r2]


def test_api_analytics_serves_command_center():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    server._ANALYTICS_CACHE.update(at=0.0, key="", data=None)
    out = server.api_analytics(demo=1)
    for k in ("kpis", "daily", "heatmap", "platform_mix",
              "leaderboard", "environments", "adoption"):
        assert k in out
    assert out["kpis"]["sessions_7d"] > 0     # demo synth keeps it alive
    assert len(out["heatmap"]) == 7 and len(out["heatmap"][0]) == 24


# ----------------------------------------------- v1.9.2 AWS AgentCore support
def test_sigv4_credential_parsing_and_signature_shape():
    from openaid.collectors.aws_sigv4 import parse_credentials, sigv4_headers
    from datetime import datetime, timezone
    assert parse_credentials("AKIAXXXX:secret") == ("AKIAXXXX", "secret", "")
    assert parse_credentials("ASIAXXXX:sec:tok") == ("ASIAXXXX", "sec", "tok")
    assert parse_credentials("bedrock-api-key-base64") is None
    now = datetime(2026, 8, 23, 12, 0, tzinfo=timezone.utc)
    h1 = sigv4_headers("POST", "https://bedrock-agentcore-control.us-east-1"
                       ".amazonaws.com/runtimes/?maxResults=100",
                       service="bedrock-agentcore", region="us-east-1",
                       access_key="AKIAX", secret_key="s1", now=now)
    h2 = sigv4_headers("POST", "https://bedrock-agentcore-control.us-east-1"
                       ".amazonaws.com/runtimes/?maxResults=100",
                       service="bedrock-agentcore", region="us-east-1",
                       access_key="AKIAX", secret_key="s1", now=now)
    h3 = sigv4_headers("POST", "https://bedrock-agentcore-control.us-east-1"
                       ".amazonaws.com/runtimes/?maxResults=100",
                       service="bedrock-agentcore", region="us-east-1",
                       access_key="AKIAX", secret_key="DIFFERENT", now=now)
    assert h1["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=AKIAX/"
                                          "20260823/us-east-1/bedrock-agentcore/")
    assert h1 == h2                      # deterministic
    assert h1["Authorization"] != h3["Authorization"]   # secret matters
    assert "host;x-amz-content-sha256;x-amz-date" in h1["Authorization"]


def test_aws_collector_lists_agentcore_runtimes_as_harness_names():
    from openaid.collectors import third_party as tp

    def fetch(method, url, headers=None, **kw):
        if "bedrock-agent." in url:
            return {"agentSummaries": []}
        if "bedrock-agentcore-control" in url:
            assert method == "POST"
            assert headers["Authorization"].startswith("AWS4-HMAC-SHA256")
            return {"agentRuntimes": [{
                "agentRuntimeId": "harness_awsbedrocktest1-hNBQWeCsHm",
                "agentRuntimeName": "harness_awsbedrocktest1",
                "agentRuntimeArn": "arn:aws:bedrock-agentcore:us-east-1:950119650120:"
                                   "runtime/harness_awsbedrocktest1-hNBQWeCsHm",
                "status": "READY"}]}
        raise RuntimeError("unexpected " + url)

    docs, errors = tp.bedrock_agents(fetch, "AKIAXXXX:secretkey", "us-east-1")
    assert not errors
    rt = [d for d in docs if d["agent"]["agent_type"] == "agentcore_runtime"][0]
    assert rt["name"] == "awsbedrocktest1"               # harness display name
    assert "bedrock-agentcore/runtimes/harness_awsbedrocktest1-hNBQWeCsHm" in (
        rt["scope"]["portal_url"])
    assert any(x["surface"].endswith("/runtimes") and x["auth"] == "sigv4"
               and x["result"].startswith("OK: 1") for x in tp.AWS_XRAY)


def test_aws_collector_bearer_still_works_for_classic():
    from openaid.collectors import third_party as tp

    def fetch(method, url, headers=None, **kw):
        if "bedrock-agent." in url:
            assert headers["Authorization"] == "Bearer bedrock-key"
            return {"agentSummaries": [{"agentId": "AG1", "agentName": "Classic"}]}
        raise RuntimeError("403 agentcore needs sigv4")

    docs, errors = tp.bedrock_agents(fetch, "bedrock-key", "us-east-1")
    assert [d["name"] for d in docs] == ["Classic"]
    assert errors and "agentcore" in errors[0]["scope"]
    assert any(x["result"].startswith("ERROR") for x in tp.AWS_XRAY)


def test_api_debug_aws_endpoint():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    out = server.api_debug_aws()
    assert "attempts" in out and "SigV4" in out["note"]


# ------------------------------------------------ v1.10 n8n connector
def test_n8n_workflows_tag_ai_agents():
    from openaid.collectors import third_party as tp

    def fetch(method, url, headers=None, **kw):
        assert headers["X-N8N-API-KEY"] == "k1"
        assert url.startswith("https://n8n.corp.io/api/v1/workflows")
        return {"data": [
            {"id": "7", "name": "Support triage",
             "active": True, "updatedAt": "2026-08-01",
             "nodes": [{"type": "@n8n/n8n-nodes-langchain.agent"},
                       {"type": "n8n-nodes-base.slack"}]},
            {"id": "9", "name": "CSV cleanup", "active": False,
             "nodes": [{"type": "n8n-nodes-base.spreadsheetFile"}]}]}

    docs, errors = tp.n8n_workflows(fetch, "k1", "https://n8n.corp.io/")
    assert not errors
    ai = [d for d in docs if d["agent"]["agent_type"] == "n8n_ai_agent"]
    wf = [d for d in docs if d["agent"]["agent_type"] == "n8n_workflow"]
    assert [d["name"] for d in ai] == ["Support triage"]
    assert [d["name"] for d in wf] == ["CSV cleanup"]
    assert ai[0]["scope"]["portal_url"] == "https://n8n.corp.io/workflow/7"
    assert ai[0]["risk_hints"]["ai_nodes"] == 1


def test_n8n_requires_base_url_and_is_registered():
    from openaid.collectors import third_party as tp
    from openaid import connections
    docs, errors = tp.n8n_workflows(lambda **k: {}, "k", "")
    assert not docs and "base URL" in errors[0]["error"]
    assert "n8n" in tp.COLLECTORS and tp.COLLECTORS["n8n"][1] is True
    assert any(p["id"] == "n8n" for p in connections.PLATFORMS)


# ------------------------------------- v1.10.1 AWS connect-chain fixes
def test_aws_validation_sigv4_probes_agentcore():
    from openaid import connections as cx
    seen = {}
    def fetch(method, url, headers=None, **kw):
        seen["method"], seen["url"], seen["hdr"] = method, url, headers
        return {"agentRuntimes": []}
    r = cx.validate("aws", "AKIAXXXX:secret", "us-east-1", fetch)
    assert r["ok"] and "AgentCore" in r["detail"]
    assert seen["method"] == "POST"
    assert "bedrock-agentcore-control.us-east-1" in seen["url"]
    assert seen["hdr"]["Authorization"].startswith("AWS4-HMAC-SHA256")


def test_aws_validation_bearer_warns_about_agentcore():
    from openaid import connections as cx
    def fetch(method, url, headers=None, **kw):
        assert headers["Authorization"] == "Bearer bedrock-key"
        assert "bedrock-agent.eu-west-1" in url
        return {"agentSummaries": []}
    r = cx.validate("aws", "bedrock-key", "eu-west-1", fetch)
    assert r["ok"] and "WARNING" in r["detail"] and "AgentCore" in r["detail"]


def test_aws_validation_rejects_bad_sigv4():
    from openaid import connections as cx
    def fetch(method, url, headers=None, **kw):
        raise RuntimeError("403 AccessDenied")
    r = cx.validate("aws", "AKIAXXXX:wrong", "us-east-1", fetch)
    assert not r["ok"] and "403" in r["detail"]


def test_aws_card_has_region_field_and_banner_wired():
    from openaid import connections as cx
    aws = [p for p in cx.PLATFORMS if p["id"] == "aws"][0]
    assert aws["kind"] == "token_url"          # region field now shown
    assert "ACCESS_KEY_ID:SECRET_ACCESS_KEY" in aws.get("hint", "")
    html = (pathlib.Path(__file__).resolve().parents[1]
            / "app" / "static" / "index.html").read_text(encoding="utf-8")
    assert "AWS is connected but 0 AWS agents" in html
    assert "third_party_connected" in html


# --------------------------------------- v1.11 self-healing auth
def test_jwt_minutes_left_and_alive():
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    assert server._jwt_minutes_left("not-a-jwt") == -1
    assert not server._alive("")
    dead = _fake_jwt(-300)
    live = _fake_jwt(1800)
    assert server._jwt_minutes_left(dead) < 0 and not server._alive(dead)
    assert server._jwt_minutes_left(live) > 25 and server._alive(live)


def test_live_session_beats_dead_env_token_for_dataverse(monkeypatch):
    """REGRESSION LOCK: a DEAD deploy-injected Dataverse token must never
    outrank the live signed-in session — that ordering blanked the console
    with a 401 wall."""
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    dead = _fake_jwt(-300)
    monkeypatch.setenv("OPENAID_DATAVERSE_TOKEN", dead)
    monkeypatch.setenv("OPENAID_ARM_TOKEN", dead)
    monkeypatch.setattr(server.connections, "ms_token", lambda r: "")
    monkeypatch.setattr(server.auth, "get_token",
                        lambda res: "session-token-" + str(res)[:8])
    monkeypatch.setattr(server.auth, "status",
                        lambda: {"signed_in": True})
    src = open(server.__file__).read()
    # structural locks on the fixed ordering
    assert "if dv_pasted and _alive(dv_pasted):" in src
    assert "return auth.get_token(url) or dv_pasted" in src
    assert 'auth.get_token("https://globaldisco.crm.dynamics.com")' in src


def test_auth_refresh_endpoint_reports_per_resource(monkeypatch):
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setenv("OPENAID_DATAVERSE_URLS",
                       "https://org1.crm.dynamics.com,https://org2.crm.dynamics.com")
    monkeypatch.setattr(server.auth, "status", lambda: {"signed_in": True})
    monkeypatch.setattr(server.auth, "get_token",
                        lambda res: _fake_jwt(3000) if "org1" not in str(res) else "")
    out = server.api_auth_refresh()
    assert out["signed_in"] and out["total"] >= 9
    assert out["resources"]["arm"]["ok"]
    assert not out["resources"]["dataverse org1"]["ok"]
    assert "re-minted" in out["detail"]


def test_auth_refresh_when_not_signed_in(monkeypatch):
    pytest.importorskip("fastapi")   # server deps live in the container image
    from app import server
    monkeypatch.setattr(server.auth, "status", lambda: {"signed_in": False})
    out = server.api_auth_refresh()
    assert out["refreshed"] == 0 and "Sign in" in out["detail"]


def test_banner_catches_401_wall_with_refresh_button():
    html = (pathlib.Path(__file__).resolve().parents[1]
            / "app" / "static" / "index.html").read_text(encoding="utf-8")
    assert "Authentication expired" in html
    assert "refreshTokens" in html and "/api/auth/refresh" in html


# --------------------------------- v1.11.1 AWS credential guidance fixes
def test_bedrock_api_key_gets_truthful_rejection():
    """A 'bedrock-api-key-...' paste authenticates core Bedrock but can never
    list agents — the popup must say so instead of a bare 403."""
    from openaid import connections as cx
    def fetch(method, url, headers=None, **kw):
        assert "bedrock.us-east-1.amazonaws.com/foundation-models" in url
        return {"models": []}
    r = cx.validate("aws", "bedrock-api-key-YmVkcm9jaw", "us-east-1", fetch)
    assert not r["ok"]
    assert "CANNOT list agents" in r["detail"]
    assert "ACCESS_KEY_ID:SECRET_ACCESS_KEY" in r["detail"]


def test_bedrock_api_key_rejected_still_names_the_fix():
    from openaid import connections as cx
    def fetch(method, url, headers=None, **kw):
        raise RuntimeError("403 Forbidden")
    r = cx.validate("aws", "bedrock-api-key-xyz", "us-east-1", fetch)
    assert not r["ok"] and "ACCESS_KEY:SECRET" in r["detail"]


def test_aws_guide_shows_triplet_command_and_formats():
    from openaid import connections as cx
    g = cx.CONNECT_GUIDE["aws"]
    # v1.11.3: CloudShell-first — export-credentials prints the ready triplet
    # (sts get-session-token fails for assumed-role/CloudShell identities)
    assert "export-credentials" in g["cmd"]
    steps = " ".join(g["steps"])
    assert "ACCESS_KEY_ID:SECRET_ACCESS_KEY" in steps
    assert "ACCESS:SECRET:SESSION" in steps
    assert "bedrock-api-key" in steps


# ------------------------- v1.11.2 copilot URL resilience under BAP outage
def test_default_env_inferred_from_globaldisco_name():
    """BAP down -> env metadata comes from globaldisco with only {id, name}.
    The FriendlyName still says "(default)" — Default-first addressing must
    survive on name inference alone."""
    from openaid.collectors import copilot_studio

    def fetch(method, url, headers=None, **kw):
        if "bots" in url and "botcomponents" not in url:
            return {"value": [{"botid": "b1", "name": "A", "schemaname": "s1",
                               "publishedon": "2026-01-01"}]}
        return {"value": []}

    env_index = {"https://org.crm.dynamics.com": {
        "id": "env-guid-3", "name": "microsoft (default)"}}   # no is_default!
    import os
    os.environ["OPENAID_TENANT_ID"] = "tid-77"
    r = copilot_studio.collect(fetch, token="t",
                               dataverse_urls=["https://org.crm.dynamics.com"],
                               env_index=env_index)
    c = r["descriptors"][0]["scope"]["portal_candidates"]
    assert c[0] == ("https://copilotstudio.microsoft.com/environments/"
                    "Default-tid-77/copilots/b1/details")


def test_env_index_merge_never_stomps_bap_metadata():
    """REGRESSION LOCK: globaldisco's poor {id,name} entries must MERGE into
    BAP's rich entries, not overwrite them — the blind update() silently
    downgraded Copilot deep links whenever both sources ran."""
    src = (pathlib.Path(__file__).resolve().parents[1]
           / "openaid" / "discover_v2.py").read_text(encoding="utf-8")
    assert "env_index.update(gd_index)" not in src
    assert "_cur.setdefault(_k, _v)" in src


def test_envmeta_cache_backfills_on_bap_outage(tmp_path, monkeypatch):
    from openaid import discover_v2 as dv
    monkeypatch.setattr(dv, "_ENVMETA_PATH", str(tmp_path / "m.json"))
    rich = {"https://o.crm.dynamics.com": {
        "id": "e1", "name": "Prod", "tenant_id": "t9", "is_default": True}}
    dv._envmeta_save(rich)
    poor = {"https://o.crm.dynamics.com": {"id": "e1", "name": "Prod"}}
    out = dv._envmeta_backfill(poor)
    assert out["https://o.crm.dynamics.com"]["tenant_id"] == "t9"
    assert out["https://o.crm.dynamics.com"]["is_default"] is True


# ------------------------------ v1.11.3 AWS CloudShell flow + sanitizer
def test_aws_token_sanitizer_handles_console_pastes():
    from openaid.connections import _clean_aws_token
    assert _clean_aws_token(
        "export AWS_BEARER_TOKEN_BEDROCK=bedrock-api-key-abc\n"
    ) == "bedrock-api-key-abc"
    assert _clean_aws_token("  'AKIAX:secret:tok'  ") == "AKIAX:secret:tok"
    assert _clean_aws_token("AKIAX:sec ret\n:tok") == "AKIAX:secret:tok"


def test_aws_sanitizer_applied_on_save_and_validate(monkeypatch):
    from openaid import connections as cx
    cx.set_connection("aws", "export AWS_BEARER_TOKEN_BEDROCK=bedrock-api-key-q", "us-east-1")
    assert cx.active_connections()["aws"]["token"] == "bedrock-api-key-q"
    seen = {}
    def fetch(method, url, headers=None, **kw):
        seen["url"] = url
        return {}
    r = cx.validate("aws", "export AWS_BEARER_TOKEN_BEDROCK=bedrock-api-key-q",
                    "us-east-1", fetch)
    assert not r["ok"] and "foundation-models" in seen["url"]
    cx.set_connection("aws", "", "")   # clean up shared state


def test_aws_guide_is_cloudshell_first():
    from openaid.connections import CONNECT_GUIDE
    g = CONNECT_GUIDE["aws"]
    assert "cloudshell" in g["token_url"]
    assert "export-credentials" in g["cmd"]
    steps = " ".join(g["steps"])
    assert "CloudShell" in steps and "ACCESS:SECRET:SESSION" in steps
    assert "bedrock-api-key" in steps

"""Standalone OpenAID-Graph server.

Self-contained: serves the attack-path API and a zero-build HTML UI. Runs the
v0.2 collectors (each self-gating on env config), builds the trust graph, ranks
blast radius, finds cross-platform pivots, and emits the Cisco exports. No v0.1
codebase required.

Endpoints:
  GET /                 -> the single-page UI (static/index.html)
  GET /api/health       -> liveness
  GET /api/graph        -> live discovery; falls back to the sample fleet when
                           no platform tokens are configured (?demo=1 forces it)
  GET /api/exports/ocsf -> OCSF NDJSON for Splunk / Cisco XDR
"""
from __future__ import annotations

import os
from pathlib import Path

import httpx
from fastapi import FastAPI, Query, Request, Response
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse

from openaid import analytics, hygiene, pipelines
from openaid import (auth, connections, continuous, defender, discover_v2, dlp, drift,
                     news as news_mod, owasp, posture, redteam, remediation,
                     search as search_mod,
                     sprawl, trifecta, usage)
from openaid.sample_fleet import sample_descriptors

app = FastAPI(title="OpenAID Graph", version="1.11.4")
STATIC = Path(__file__).parent / "static"


def _fetch(method: str, url: str, headers=None, **kw):
    with httpx.Client(timeout=30) as c:
        r = c.request(method, url, headers=headers or {}, **kw)
        r.raise_for_status()
        if r.headers.get("content-type", "").startswith("application/json"):
            return r.json()
        return {}


# ---- interactive sign-in (device code) -------------------------------------
@app.get("/api/auth/status")
def auth_status():
    return auth.status()


@app.post("/api/auth/signin")
def auth_signin():
    return auth.start_device_flow()


@app.post("/api/auth/signout")
def auth_signout():
    return auth.sign_out()


@app.get("/api/auth/diag")
def auth_diag():
    """Diagnose which Microsoft resource tokens can be acquired after sign-in.
    An empty token here means that permission wasn't consented — the reason
    live discovery shows nothing."""
    st = auth.status()
    if not st.get("signed_in"):
        return {"signed_in": False, "resources": {}}
    res = {}
    for r in ("arm", "bap", "foundry"):
        tok = auth.get_token(r)
        res[r] = {"acquired": bool(tok), "hint": {
            "arm": "Azure Service Management user_impersonation — needed for subscriptions",
            "bap": "Power Platform API — needed for environments + Copilot Studio",
            "foundry": "Azure ML user_impersonation — needed for Foundry agents",
        }[r]}
    return {"signed_in": True, "account": st.get("account", ""), "resources": res}


# ---- popup sign-in per platform + validation + remediation ------------------
@app.post("/api/connections/test")
async def conn_test(req: Request):
    body = await req.json()
    platform = body.get("platform", "")
    token = body.get("token", "")
    url = body.get("url", "")
    res = connections.validate(platform, token, url, _fetch)
    if res.get("ok"):
        connections.set_connection(platform, token, url)
    return res


@app.post("/api/remediate")
async def remediate(req: Request):
    """One-click fixes. Body: {action, org_url, bot_id}."""
    body = await req.json()
    org_url = body.get("org_url", "")
    dv = (connections.ms_token("dataverse")
          or os.getenv("OPENAID_DATAVERSE_TOKEN", "")
          or (auth.get_token(org_url) if org_url else ""))
    pp = (auth.get_token("https://api.powerplatform.com")
          or os.getenv("OPENAID_PP_TOKEN", "")
          or os.getenv("OPENAID_BAP_TOKEN", ""))
    return remediation.execute(
        body.get("action", ""), fetch=_fetch,
        org_url=org_url, bot_id=body.get("bot_id", ""), dataverse_token=dv,
        environment_id=body.get("environment_id", ""),
        new_owner=body.get("new_owner", ""), pp_token=pp)


@app.get("/api/exports/hierarchy.csv")
def export_hierarchy_csv(demo: int = 0):
    import csv as _csv, io as _io
    g = api_graph(demo=demo)
    hs = g.get("hierarchies", [])
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(["parent", "parent_platform", "environment", "subscription",
                "relation", "child", "child_type", "child_environment", "portal_url"])
    for h in hs:
        for c in h.get("children", []):
            w.writerow([h.get("parent_name", ""), h.get("platform", ""),
                        h.get("environment", ""), h.get("subscription", ""),
                        c.get("type", ""), c.get("name", ""),
                        c.get("agent_type", ""), c.get("environment", ""),
                        c.get("portal_url", "")])
    from fastapi.responses import PlainTextResponse as _PT
    return _PT(buf.getvalue(), media_type="text/csv",
               headers={"Content-Disposition": "attachment; filename=hierarchy.csv"})


@app.get("/api/debug/links")
def debug_links(demo: int = 0, limit: int = 40):
    """Show EXACTLY what portal URL the app built for each agent, plus the raw
    inputs it used. When a link lands on the wrong page this says why —
    a missing agent name, a missing tenant id, or a wrong id — instead of
    leaving anyone guessing."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    out = []
    for a in agents[:limit]:
        d = next((x for x in g.get("descriptors", [])
                  if x.get("id") == a.get("id")), {})
        sc = d.get("scope", {}) or {}
        out.append({
            "name": a.get("name"), "platform": a.get("platform"),
            "primary_url": a.get("portal_url"),
            "candidates": a.get("portal_candidates", []),
            "inputs": {
                "native_id": a.get("native_id"),
                "schema_name": sc.get("schema_name"),
                "environment": sc.get("environment"),
                "environment_id": sc.get("environment_id"),
                "project": sc.get("project"),
                "arm_id": sc.get("arm_id"),
                "tenant_id": sc.get("tenant_id") or os.getenv("OPENAID_TENANT_ID", ""),
            },
            "missing": [k for k, v in {
                "native_id": a.get("native_id"),
                "environment_id": sc.get("environment_id"),
                "tenant_id": sc.get("tenant_id") or os.getenv("OPENAID_TENANT_ID", ""),
                "project": sc.get("project"),
                "arm_id": sc.get("arm_id"),
            }.items() if not v],
        })
    return {"agents": out,
            "tenant_id_env": bool(os.getenv("OPENAID_TENANT_ID", "")),
            "note": ("If 'missing' lists a field, that is why the link is wrong. "
                     "Paste this back with a known-good portal URL to pin the format.")}


_LINK_PREFS_PATH = "/tmp/openaid_link_prefs.json"


def _link_prefs() -> dict:
    """platform -> URL-shape marker the user confirmed WORKS in this tenant.

    The Microsoft portals are mid-rebrand and their deep-link routes keep
    shifting; instead of hard-coding one guess, /go/agent lists every known
    shape and the user's single confirmation click is remembered here — every
    later link for that platform leads with the shape proven to work."""
    import json as _j
    import os as _os
    if not hasattr(_link_prefs, "_cache"):
        try:
            with open(_LINK_PREFS_PATH) as f:
                _link_prefs._cache = _j.load(f)
        except Exception:
            _link_prefs._cache = {}
    return _link_prefs._cache


def _link_prefs_save(prefs: dict) -> None:
    import json as _j
    _link_prefs._cache = prefs
    try:
        with open(_LINK_PREFS_PATH, "w") as f:
            _j.dump(prefs, f)
    except Exception:
        pass


def _link_shape(u: str) -> str:
    """Classify a portal URL into a stable shape marker for preference-matching."""
    if "/nextgen/r/" in u:
        if "/playground" in u:
            return "foundry_nextgen_playground"
        return "foundry_nextgen_agent" if "/build/agents/" in u and not u.rstrip("/").endswith("agents") else "foundry_nextgen_list"
    if "ai.azure.com/r/" in u:
        if "/playground" in u:
            return "foundry_ga_playground"
        return "foundry_ga_agent" if "/build/agents/" in u and not u.rstrip("/").endswith("agents") else "foundry_ga_list"
    if "ai.azure.com/build/agents" in u:
        return "foundry_classic"
    if "ai.azure.com/build/overview" in u:
        return "foundry_project_home"
    if "/copilots/" in u:
        return "cs_new_default" if "/Default-" in u else "cs_new_guid"
    if "/bots/" in u:
        return "cs_classic_default" if "/Default-" in u else "cs_classic_guid"
    if u.rstrip("/").endswith("/home"):
        return "cs_env_home"
    return "other"


_SHAPE_LABEL = {
    "foundry_nextgen_playground": "New Foundry portal — agent PLAYGROUND",
    "foundry_ga_playground": "Foundry GA portal — agent PLAYGROUND",
    "foundry_nextgen_agent": "New Foundry portal — this agent",
    "foundry_nextgen_list": "New Foundry portal — project agents",
    "foundry_ga_agent": "Foundry GA portal — this agent",
    "foundry_ga_list": "Foundry GA portal — project agents",
    "foundry_classic": "Classic Foundry portal",
    "foundry_project_home": "Project home (agent is one click in)",
    "cs_new_default": "New Copilot Studio — default-env addressing",
    "cs_new_guid": "New Copilot Studio",
    "cs_classic_default": "Classic Copilot Studio — default-env addressing",
    "cs_classic_guid": "Classic Copilot Studio",
    "cs_env_home": "Environment home (agent listed there)",
    "other": "Portal",
}


@app.get("/api/links/prefer")
def api_links_prefer(platform: str = "", shape: str = ""):
    """Remember which URL shape WORKED for a platform (one click in the
    resolver page). Empty shape clears the preference."""
    prefs = dict(_link_prefs())
    if platform:
        if shape:
            prefs[platform] = shape
        else:
            prefs.pop(platform, None)
        _link_prefs_save(prefs)
    return {"prefs": prefs}


@app.get("/api/debug/aws")
def api_debug_aws():
    """AWS X-Ray: every Bedrock surface attempted on the last collection with
    its result and auth mode — classic bedrock-agent AND the AgentCore
    control plane where console Harnesses actually live."""
    from openaid.collectors import third_party as _tp
    return {
        "attempts": list(getattr(_tp, "AWS_XRAY", [])),
        "note": ("Console 'Harnesses' are AgentCore runtimes on "
                 "bedrock-agentcore-control — that surface needs SigV4: paste "
                 "ACCESS_KEY_ID:SECRET_ACCESS_KEY in the AWS connection. A "
                 "Bedrock API key (bearer) only covers classic Bedrock Agents."),
    }


@app.get("/api/debug/foundry")
def api_debug_foundry(demo: int = Query(0)):
    """Foundry X-Ray: runs discovery and reports EVERY endpoint x api-surface
    attempt with its result, plus the audience of the Foundry token — so
    "my Foundry agents vanished" self-diagnoses instead of guessing. The
    classic Assistants API retires 2026-08-26; this shows exactly which
    routes your tenant still answers on."""
    import base64 as _b64
    import json as _j
    from openaid.collectors import foundry_agents as _fa
    g = api_graph(demo=demo)
    agents = [a for a in (g.get("inventory") or {}).get("agents", [])
              if a.get("platform") == "azure_foundry"]
    aud = ""
    tok = os.getenv("OPENAID_FOUNDRY_TOKEN", "")
    if tok.count(".") >= 2:
        try:
            pl = tok.split(".")[1]
            pl += "=" * (-len(pl) % 4)
            aud = _j.loads(_b64.urlsafe_b64decode(pl)).get("aud", "")
        except Exception:
            aud = "(undecodable)"
    return {
        "foundry_agents_found": len(agents),
        "token_audience": aud,
        "expected_audience": "https://ai.azure.com",
        "endpoints_configured": [e for e in
            os.getenv("OPENAID_FOUNDRY_ENDPOINTS", "").split(",") if e],
        "attempts": list(_fa.XRAY),
        "note": ("Assistants API retires 2026-08-26. If every assistants "
                 "surface errors and agents surfaces return 0, the agents "
                 "were created in the new portal under a newer api-version — "
                 "paste this JSON back and the exact surface gets added."),
    }


_ANALYTICS_CACHE: dict = {"at": 0.0, "key": "", "data": None}


@app.get("/api/analytics")
def api_analytics(demo: int = Query(0)):
    """Command Center: sessions time-series, WoW delta, busiest-hours heatmap,
    agent leaderboard with sparklines, platform mix, environment league,
    adoption trend — computed from transcripts + inventory. Cached 5 min."""
    import time as _t
    key = f"demo={demo}"
    if (_ANALYTICS_CACHE["data"] is not None and _ANALYTICS_CACHE["key"] == key
            and _t.time() - _ANALYTICS_CACHE["at"] < 300):
        return _ANALYTICS_CACHE["data"]
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    rows: list = []
    tokens_total = 0
    if g.get("mode") == "live":
        import datetime as _d
        since = (_d.datetime.now(_d.timezone.utc)
                 - _d.timedelta(days=analytics.DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")
        dv = connections.ms_token("dataverse") or os.getenv("OPENAID_DATAVERSE_TOKEN", "")
        for u in [x for x in os.getenv("OPENAID_DATAVERSE_URLS", "").split(",") if x]:
            try:
                hdr = {"Authorization": f"Bearer {dv}", "Accept": "application/json",
                       "OData-MaxVersion": "4.0", "OData-Version": "4.0"}
                j = _fetch("GET", (f"{u.rstrip('/')}/api/data/v9.2/conversationtranscripts"
                                   f"?$select=_bot_conversationtranscriptid_value,createdon"
                                   f"&$filter=createdon ge {since}&$top=5000"),
                           headers=hdr) or {}
                rows.extend({"bot_id": (r.get("_bot_conversationtranscriptid_value") or ""),
                             "createdon": r.get("createdon", "")}
                            for r in j.get("value", []))
            except Exception:
                continue
        try:
            u = api_usage(demo=0)
            tokens_total = (u.get("totals") or {}).get("tokens", 0)
        except Exception:
            tokens_total = 0
    if not rows:
        rows = analytics.demo_rows(agents)
    try:
        hscore = hygiene.analyze(agents).get("score")
    except Exception:
        hscore = None
    data = analytics.build(rows, agents, hygiene_score=hscore,
                           foundry_tokens_total=tokens_total)
    data["mode"] = g.get("mode", "")
    _ANALYTICS_CACHE.update(at=_t.time(), key=key, data=data)
    return data


@app.get("/api/pipeline/targets")
def api_pipeline_targets(demo: int = Query(0)):
    """Deployable targets = BAP environment list UNION the environments the
    live inventory already knows. Two sources so a dead BAP token can never
    empty the dropdown again; any BAP error is returned (and shown) instead
    of swallowed."""
    from openaid.collectors import powerplatform_envs
    by_url: dict = {}
    bap_error = ""
    bap = os.getenv("OPENAID_BAP_TOKEN", "")
    if bap:
        try:
            _rep, _urls, idx = powerplatform_envs.collect(_fetch, token=bap)
            for u, m in idx.items():
                by_url[u] = {"org_url": u, "name": (m or {}).get("name", u),
                             "environment_id": (m or {}).get("id", ""),
                             "is_default": bool((m or {}).get("is_default")),
                             "source": "bap"}
        except Exception as exc:
            bap_error = str(exc)[:200]
    else:
        bap_error = "no BAP token — re-run DEPLOY.ps1"
    # UNION: environments the inventory already discovered (agents live there)
    try:
        g = api_graph(demo=demo)
        for e in (g.get("inventory") or {}).get("environments", []):
            u = e.get("dataverse_url", "")
            if u and u not in by_url:
                by_url[u] = {"org_url": u, "name": e.get("name", u),
                             "environment_id": e.get("environment_id", ""),
                             "is_default": False, "source": "inventory"}
    except Exception:
        pass
    foundry = [{"endpoint": e, "name": e.split("//")[-1].split(".")[0]
                + " / " + e.rstrip("/").split("/")[-1]}
               for e in os.getenv("OPENAID_FOUNDRY_ENDPOINTS", "").split(",") if e]
    return {"powerplatform": sorted(by_url.values(), key=lambda x: x["name"].lower()),
            "foundry": foundry, "bap_error": bap_error}


_PIPE_HISTORY_PATH = "/tmp/openaid_pipeline_history.json"


def _pipe_history() -> list:
    import json as _j
    if not hasattr(_pipe_history, "_cache"):
        try:
            with open(_PIPE_HISTORY_PATH) as f:
                _pipe_history._cache = _j.load(f)
        except Exception:
            _pipe_history._cache = []
    return _pipe_history._cache


def _pipe_history_add(entry: dict) -> None:
    import json as _j
    from datetime import datetime as _dt, timezone as _tz
    entry["at"] = _dt.now(_tz.utc).isoformat()
    hist = _pipe_history()
    hist.insert(0, entry)
    del hist[50:]
    try:
        with open(_PIPE_HISTORY_PATH, "w") as f:
            _j.dump(hist, f)
    except Exception:
        pass


@app.get("/api/pipeline/history")
def api_pipeline_history():
    return {"runs": _pipe_history()}


def _pipe_tokens(plat: str, src: str = "", dst: str = ""):
    if plat == "copilot_studio":
        dv = (connections.ms_token("dataverse")
              or os.getenv("OPENAID_DATAVERSE_TOKEN", ""))
        return (dv or auth.get_token(src), dv or auth.get_token(dst))
    tok = (connections.ms_token("foundry")
           or os.getenv("OPENAID_FOUNDRY_TOKEN", "")
           or auth.get_token("https://ai.azure.com"))
    return (tok, tok)


@app.post("/api/pipeline/preflight")
async def api_pipeline_preflight(request: Request):
    """Go/no-go checks against the TARGET before any clone runs."""
    body = await request.json()
    plat = body.get("platform", "")
    if plat == "copilot_studio":
        _stok, ttok = _pipe_tokens(plat, dst=body.get("target_org_url", ""))
        return pipelines.copilot_preflight(
            _fetch, target_org_url=body.get("target_org_url", ""),
            target_token=ttok, schema_hint=body.get("schema_hint", ""))
    if plat in ("azure_foundry", "azure_openai"):
        tok, _ = _pipe_tokens(plat)
        return pipelines.foundry_preflight(
            _fetch, target_endpoint=body.get("target_endpoint", ""), token=tok)
    return {"ok": False, "checks": [],
            "detail": f"unsupported platform: {plat}"}


@app.post("/api/pipeline/deploy_stream")
async def api_pipeline_deploy_stream(request: Request):
    """Same jobs as /deploy but streams NDJSON events as work happens:
      {"agent","event":"step","step","pct"}   live progress
      {"agent","event":"done","ok","detail","steps"}   per-agent result
      {"event":"all_done","ok"}   final
    The UI draws real progress bars from these."""
    import json as _j
    import queue as _q
    import threading as _th
    from fastapi.responses import StreamingResponse
    body = await request.json()
    jobs = body.get("agents") or [body]

    q: _q.Queue = _q.Queue()

    def _run():
        overall_ok = True
        for job in jobs:
            plat = job.get("platform", "")
            name = job.get("agent_name", job.get("bot_id") or job.get("agent_id", ""))

            def _emit(step, pct, _n=name):
                q.put({"agent": _n, "event": "step", "step": step, "pct": pct})

            if plat == "copilot_studio":
                src, dst = job.get("source_org_url", ""), job.get("target_org_url", "")
                stok, ttok = _pipe_tokens(plat, src, dst)
                r = pipelines.copilot_clone(
                    _fetch, source_org_url=src, bot_id=job.get("bot_id", ""),
                    target_org_url=dst, source_token=stok, target_token=ttok,
                    new_name=job.get("new_name", ""), emit=_emit)
            elif plat in ("azure_foundry", "azure_openai"):
                tok, _ = _pipe_tokens(plat)
                r = pipelines.foundry_clone(
                    _fetch, source_endpoint=job.get("source_endpoint", ""),
                    agent_id=job.get("agent_id", ""),
                    target_endpoint=job.get("target_endpoint", ""),
                    token=tok, new_name=job.get("new_name", ""), emit=_emit)
            else:
                r = {"ok": False, "steps": [], "detail": f"unsupported: {plat}"}
            overall_ok = overall_ok and bool(r.get("ok"))
            _pipe_history_add({"agent": name, "platform": plat,
                               "ok": r.get("ok"), "detail": r.get("detail", ""),
                               "target": job.get("target_org_url")
                               or job.get("target_endpoint", "")})
            q.put({"agent": name, "event": "done", "ok": r.get("ok"),
                   "detail": r.get("detail", ""), "steps": r.get("steps", [])})
        q.put({"event": "all_done", "ok": overall_ok})
        q.put(None)

    _th.Thread(target=_run, daemon=True).start()

    def _gen():
        while True:
            item = q.get()
            if item is None:
                break
            yield _j.dumps(item) + "\n"

    return StreamingResponse(_gen(), media_type="application/x-ndjson",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.post("/api/pipeline/deploy")
async def api_pipeline_deploy(request: Request):
    """Run a pipeline. Accepts one agent or a BULK list under "agents":
    each entry {platform, bot_id|agent_id, source_org_url|source_endpoint,
    target_org_url|target_endpoint, new_name}."""
    body = await request.json()
    jobs = body.get("agents") or [body]
    results = []
    for job in jobs:
        plat = job.get("platform", "")
        new_name = job.get("new_name", "")
        if plat == "copilot_studio":
            src = job.get("source_org_url", "")
            dst = job.get("target_org_url", "")
            stok, ttok = _pipe_tokens(plat, src, dst)
            r = pipelines.copilot_clone(
                _fetch, source_org_url=src, bot_id=job.get("bot_id", ""),
                target_org_url=dst, source_token=stok, target_token=ttok,
                new_name=new_name)
        elif plat in ("azure_foundry", "azure_openai"):
            tok, _ = _pipe_tokens(plat)
            r = pipelines.foundry_clone(
                _fetch, source_endpoint=job.get("source_endpoint", ""),
                agent_id=job.get("agent_id", ""),
                target_endpoint=job.get("target_endpoint", ""),
                token=tok, new_name=new_name)
        else:
            r = {"ok": False, "steps": [],
                 "detail": f"unsupported platform: {plat}"}
        r["agent"] = job.get("agent_name", job.get("bot_id") or job.get("agent_id", ""))
        _pipe_history_add({"agent": r["agent"], "platform": plat,
                           "ok": r.get("ok"), "detail": r.get("detail", ""),
                           "target": job.get("target_org_url")
                           or job.get("target_endpoint", "")})
        results.append(r)
    if len(results) == 1 and "agents" not in body:
        return results[0]
    return {"ok": all(r.get("ok") for r in results), "results": results}


@app.get("/api/hygiene")
def api_hygiene(demo: int = Query(0)):
    """Agent Hygiene report: orphaned / inactive / anonymous agents + tenant
    score. Community-requested governance view (orphan + deprecation lists)."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    rep = hygiene.analyze(agents)
    rep["mode"] = g.get("mode", "")
    return rep


@app.get("/go/agent", response_class=HTMLResponse)
def go_agent(agent_id: str = "", demo: int = 0):
    """Portal resolver. Copilot Studio ships classic AND new agent experiences
    on different routes and Microsoft does not document the deep-link path, so
    a single hard-coded URL can 404 for some tenants. This page opens the most
    likely route immediately and keeps the alternates one click away — the user
    always lands on their agent, never on a dead end."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    a = next((x for x in agents if x.get("id") == agent_id), None)
    if not a:
        return HTMLResponse("<h3>Agent not found</h3>", status_code=404)
    cands = a.get("portal_candidates") or ([a["portal_url"]] if a.get("portal_url") else [])
    # The New Foundry portal REDIRECTS to the project home when ?tid= is absent,
    # which is indistinguishable from a wrong URL. Guarantee it here, where the
    # tenant id is always available from the deployment environment.
    tid = os.getenv("OPENAID_TENANT_ID", "")
    if tid:
        fixed = []
        for u in cands:
            # nextgen AND classic Foundry AND Copilot Studio all bounce to the
            # wrong tenant's home without tid when the user spans directories.
            if (("ai.azure.com" in u or "copilotstudio.microsoft.com" in u)
                    and "tid=" not in u):
                u += ("&" if "?" in u else "?") + f"tid={tid}"
            fixed.append(u)
        cands = fixed
    if not cands:
        return HTMLResponse("<h3>No portal link available for this agent</h3>", status_code=404)
    # lead with the shape the user confirmed works in THIS tenant (if any)
    plat = a.get("platform", "")
    pref = _link_prefs().get(plat, "")
    if pref:
        preferred = [u for u in cands if _link_shape(u) == pref]
        cands = preferred + [u for u in cands if u not in preferred]
    rows = []
    for u in cands:
        shape = _link_shape(u)
        label = _SHAPE_LABEL.get(shape, "Portal")
        star = " &#9733;" if (pref and shape == pref) else ""
        rows.append(
            f"<li><a href='{u}' target='_blank' rel='noreferrer'>{label}{star}</a>"
            f" <button class='ok' onclick=\"fetch('/api/links/prefer?platform={plat}&shape={shape}')"
            f".then(()=>location.reload())\" title='Remember this shape as the one that works'>"
            f"this one worked</button>"
            f"<div class='u'>{u}</div></li>")
    primary = cands[0]
    return HTMLResponse(f"""<!doctype html><html><head><meta charset='utf-8'>
<title>Opening {a['name']}…</title>
<style>body{{background:#0b0c0f;color:#e6e8ee;font-family:'Segoe UI',sans-serif;padding:34px;max-width:720px}}
h2{{margin:0 0 6px}} a{{color:#e8c268}} li{{margin:12px 0;font-size:14px;list-style:none}}
ul{{padding:0}} .u{{color:#8a8f9a;font-size:11px;word-break:break-all;margin-top:2px}}
.mut{{color:#8a8f9a;font-size:13px}}
.ok{{background:transparent;border:1px solid #2fbf71;color:#2fbf71;border-radius:5px;
padding:2px 8px;font-size:11px;cursor:pointer;margin-left:8px}}
.go{{display:inline-block;background:#e8c268;color:#0b0c0f;font-weight:700;
border-radius:6px;padding:10px 16px;text-decoration:none;margin:12px 0}}</style></head><body>
<h2>Opening {a['name']}</h2>
<div class='mut'>{a.get('environment','')} &middot; {plat}</div>
<div class='u' style='margin:6px 0'>ids used: native={a.get('native_id','')} &middot; agent={a.get('id','')}</div>
<a class='go' id='p' href='{primary}' target='_blank' rel='noreferrer'>Open agent &#8599;</a>
<p class='mut'>Microsoft is mid-way through renaming these portals and the deep-link routes
keep moving. The top form opens automatically; <b>if it lands on a home page instead of the
agent</b>, try the next one — and press <b>this one worked</b> beside whichever form lands
right. That shape is remembered and every future link for {plat} leads with it.</p>
<ul>{''.join(rows)}</ul>
<script>setTimeout(function(){{document.getElementById('p').click();}}, 250);</script>
</body></html>""")


@app.get("/api/agent/scan")
def api_agent_scan(agent_id: str, demo: int = 0):
    """Everything wrong with ONE agent + the fixes that can be applied to it."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    agent = next((a for a in agents if a.get("id") == agent_id), None)
    if not agent:
        return {"error": "agent not found"}
    tri = trifecta.analyze_fleet(g.get("descriptors", []))
    row = next((r for r in tri["agents"] if r["id"] == agent_id), None)
    return remediation.scan_agent(agent, g.get("graph_findings", []), row)


_SCANS = continuous.ScanStore()
_POLICY: dict = dict(continuous.DEFAULT_POLICY)


def _sub_ids(arm: str) -> list:
    if not arm:
        return []
    try:
        j = _fetch("GET", "https://management.azure.com/subscriptions?api-version=2022-12-01",
                   headers={"Authorization": f"Bearer {arm}"}) or {}
        return [s["subscriptionId"] for s in j.get("value", []) if s.get("subscriptionId")]
    except Exception:
        return []


def _arm_token() -> str:
    return (connections.ms_token("arm")
            or auth.get_token("https://management.azure.com")
            or os.getenv("OPENAID_ARM_TOKEN", ""))


_SCHEDULE: dict = dict(continuous.DEFAULT_SCHEDULE)


_NEWS_CACHE: dict = {"at": 0.0, "data": None, "digest": ""}


def _news_fetch_text(url: str) -> str:
    import httpx as _hx
    with _hx.Client(timeout=20, follow_redirects=True) as c:
        r = c.get(url, headers={"User-Agent": "OpenAID/1.6"})
        r.raise_for_status()
        return r.text


def _news_refresh() -> dict:
    """Pull the feeds once and stamp the cache. Digest changes only when the
    item set changes — the SSE stream keys off it, so the browser is pushed
    the moment a new headline lands and stays silent otherwise."""
    import hashlib as _h
    import time as _t
    from datetime import datetime as _dt, timezone as _tz
    data = news_mod.collect(_news_fetch_text)
    items = data.get("items") or []
    data["digest"] = _h.sha256(
        "|".join(f"{i.get('url','')}{i.get('title','')}" for i in items).encode()
    ).hexdigest()[:16]
    data["refreshed_at"] = _dt.now(_tz.utc).isoformat()
    _NEWS_CACHE.update(at=_t.time(), data=data, digest=data["digest"])
    return data


def _news_loop() -> None:
    import os as _os
    import time as _t
    every = max(30, int(_os.getenv("OPENAID_NEWS_REFRESH", "60")))
    while True:
        try:
            _news_refresh()
        except Exception:
            pass  # a dead feed or offline moment must never kill the thread
        _t.sleep(every)


def _news_start() -> None:
    if _NEWS_CACHE.get("_thread"):
        return
    import threading as _th
    t = _th.Thread(target=_news_loop, daemon=True, name="openaid-news")
    t.start()
    _NEWS_CACHE["_thread"] = t


_news_start()


@app.get("/api/dlp")
def api_dlp(demo: int = 0):
    """DLP policy coverage per environment — including the environments that
    have NO policy and the agents sitting in them."""
    if demo or os.getenv("OPENAID_DEMO") == "1":
        return dlp.analyze(
            [{"displayName": "Corp baseline", "environmentType": "OnlyEnvironments",
              "environments": {"environmentType": "OnlyEnvironments",
                               "environments": [{"name": "env-prod"}]},
              "connectorGroups": [
                  {"classification": "Blocked", "connectors": [{"name": "shared_twitter"}]},
                  {"classification": "General", "connectors": [{"name": "shared_sendmail"},
                                                               {"name": "shared_sharepointonline"}]}]}],
            [{"id": "env-prod", "name": "Contoso (default)"},
             {"id": "env-dev", "name": "Sales Dev"}],
            [{"environment_id": "env-dev"}, {"environment_id": "env-dev"},
             {"environment_id": "env-prod"}])
    g = api_graph(demo=demo)
    inv = g.get("inventory") or {}
    bap = (connections.ms_token("bap") or os.getenv("OPENAID_BAP_TOKEN", "")
           or auth.get_token("https://service.powerapps.com"))
    policies, errors = dlp.fetch_policies(_fetch, bap)
    envs = [{"id": e.get("id", ""), "name": e.get("name", "")}
            for e in (inv.get("environments") or []) if e.get("name")]
    out = dlp.analyze(policies, envs, inv.get("agents", []))
    out["errors"] = errors
    return out


@app.get("/api/news")
def api_news(refresh: int = 0):
    """Live feature news, refreshed every OPENAID_NEWS_REFRESH seconds
    (default 60) by a background thread — this endpoint always answers from
    the warm cache. ?refresh=1 forces an immediate pull."""
    if refresh or _NEWS_CACHE["data"] is None:
        return _news_refresh()
    return _NEWS_CACHE["data"]


@app.get("/api/news/stream")
def api_news_stream():
    """Server-Sent Events: pushes the full news payload the moment the item
    digest changes; heartbeats every 20s keep proxies from closing the pipe."""
    import json as _j
    import time as _t
    from fastapi.responses import StreamingResponse

    def _events():
        last, beat = "", _t.time()
        while True:
            d = _NEWS_CACHE.get("data")
            if d and _NEWS_CACHE.get("digest") and _NEWS_CACHE["digest"] != last:
                last = _NEWS_CACHE["digest"]
                yield f"event: news\ndata: {_j.dumps(d)}\n\n"
                beat = _t.time()
            elif _t.time() - beat > 20:
                yield ": hb\n\n"
                beat = _t.time()
            _t.sleep(2)

    return StreamingResponse(_events(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.get("/api/search")
def api_search(q: str = "", demo: int = 0, limit: int = 25):
    """One search box across agents, findings, relationships, MCP and subs."""
    if not q.strip():
        return {"query": q, "results": [], "totals": {"matches": 0, "by_kind": {}}}
    g = api_graph(demo=demo)
    return search_mod.search(q, g.get("inventory") or {}, g.get("graph_findings", []),
                             g.get("hierarchies", []), limit)


@app.get("/api/schedule")
def get_schedule():
    return {"schedule": _SCHEDULE,
            "due_now": continuous.due(_SCHEDULE)}


@app.post("/api/schedule")
async def set_schedule(req: Request):
    body = await req.json()
    if "enabled" in body:
        _SCHEDULE["enabled"] = bool(body["enabled"])
    if "interval_minutes" in body:
        try:
            _SCHEDULE["interval_minutes"] = max(5, int(body["interval_minutes"]))
        except Exception:
            pass
    return {"schedule": _SCHEDULE}


async def _scheduler_loop():
    """Unattended scanning: wakes every minute, runs a scan when the interval
    has elapsed, and ships the report — nobody has to open the console."""
    import asyncio as _aio
    while True:
        try:
            if continuous.due(_SCHEDULE):
                out = await scan_run(demo=0, dispatch=1)
                continuous.mark_run(_SCHEDULE,
                                    (out.get("report") or {}).get("headline", ""))
        except Exception:  # noqa: BLE001
            pass
        await _aio.sleep(60)


@app.on_event("startup")
async def _start_scheduler():
    import asyncio as _aio
    if os.getenv("OPENAID_SCHEDULE_MINUTES"):
        try:
            _SCHEDULE["interval_minutes"] = max(5, int(os.getenv("OPENAID_SCHEDULE_MINUTES")))
            _SCHEDULE["enabled"] = True
        except Exception:  # noqa: BLE001
            pass
    _aio.create_task(_scheduler_loop())


@app.get("/api/owasp")
def api_owasp(demo: int = 0):
    """Live OWASP Top 10 for LLM Applications coverage across the estate."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    return owasp.scan(g.get("graph_findings", []),
                      trifecta.analyze_fleet(g.get("descriptors", [])),
                      sprawl.analyze(agents))


@app.get("/api/redteam")
def api_redteam(demo: int = 0):
    """Per-agent penetration-test plans mapped to OWASP LLM Top 10 / MITRE ATLAS."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    tri = trifecta.analyze_fleet(g.get("descriptors", []))
    return redteam.plan_fleet(agents, tri, g.get("hierarchies", []))


def _rows_for(dataset: str, demo: int):
    """One place that turns any screen's dataset into flat rows for export."""
    g = api_graph(demo=demo)
    inv = g.get("inventory") or {}
    agents = inv.get("agents", [])
    if dataset == "agents":
        return agents
    if dataset == "findings":
        return g.get("graph_findings", [])
    if dataset == "hierarchy":
        out = []
        for h in g.get("hierarchies", []):
            for c in h.get("children", []):
                out.append({"parent": h.get("parent_name"), "platform": h.get("platform"),
                            "environment": h.get("environment"), "relation": c.get("type"),
                            "child": c.get("name"), "child_environment": c.get("environment"),
                            "portal_url": c.get("portal_url")})
        return out
    if dataset == "trifecta":
        return [{"agent": r["name"], "platform": r["platform"],
                 "environment": r["environment"], "status": r["status"],
                 "legs": "|".join(r["legs_present"]),
                 "recommended_cut": (r.get("recommendation") or {}).get("label", "")}
                for r in trifecta.analyze_fleet(g.get("descriptors", []))["agents"]]
    if dataset == "sprawl":
        return [{"agent": r["name"], "environment": r["environment"],
                 "flags": "|".join(r["flags"]), "priority": r["priority"],
                 "days_since_change": r["days_since_change"]}
                for r in sprawl.analyze(agents)["rows"]]
    if dataset == "redteam":
        tri = trifecta.analyze_fleet(g.get("descriptors", []))
        out = []
        for p in redteam.plan_fleet(agents, tri, g.get("hierarchies", []))["plans"]:
            for t in p["tests"]:
                out.append({"agent": p["agent"], "environment": p["environment"],
                            "severity": t["severity"], "test": t["title"],
                            "owasp": t["owasp"], "atlas": t["atlas"],
                            "rationale": t["rationale"], "procedure": t["test"]})
        return out
    if dataset == "dlp":
        return api_dlp(demo=demo)["rows"]
    if dataset == "owasp":
        return [{"category": c["id"], "name": c["name"], "status": c["status"],
                 "evidence_count": c["count"], "rules": "|".join(c["rules"]),
                 "agents": "|".join(c["agents"])}
                for c in owasp.scan(g.get("graph_findings", []),
                                    trifecta.analyze_fleet(g.get("descriptors", [])),
                                    sprawl.analyze(agents))["categories"]]
    if dataset == "subscriptions":
        return inv.get("subscriptions", [])
    return []


@app.get("/api/exports/{dataset}.csv")
def export_dataset_csv(dataset: str, demo: int = 0):
    """Universal CSV export — every screen, one endpoint."""
    import csv as _csv, io as _io
    rows = _rows_for(dataset, demo)
    buf = _io.StringIO()
    if rows:
        cols = list({k for r in rows for k in r.keys()})
        cols.sort(key=lambda c: (c not in ("name", "agent", "parent"), c))
        w = _csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("|".join(map(str, v)) if isinstance(v, (list, tuple))
                            else v) for k, v in r.items() if k in cols})
    else:
        buf.write("no rows\n")
    return PlainTextResponse(
        buf.getvalue(), media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={dataset}.csv"})


@app.get("/api/exports/report.pdf.html", response_class=HTMLResponse)
def export_pdf_report(demo: int = 0, industry: str = "general"):
    """Print-ready report — open and Ctrl+P > Save as PDF. No extra runtime deps,
    and the browser's own engine produces a clean, paginated document."""
    g = api_graph(demo=demo)
    inv = g.get("inventory") or {}
    agents = inv.get("agents", [])
    findings = g.get("graph_findings", [])
    pos = posture.build_report(findings, agents, industry)
    tri = trifecta.analyze_fleet(g.get("descriptors", []))
    spr = sprawl.analyze(agents)
    rt = redteam.plan_fleet(agents, tri, g.get("hierarchies", []))

    def tbl(headers, rows):
        h = "".join(f"<th>{x}</th>" for x in headers)
        b = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>"
                    for r in rows) or f"<tr><td colspan='{len(headers)}'>None</td></tr>"
        return f"<table><tr>{h}</tr>{b}</table>"

    fw = "".join(f"<li><b>{f['label']}</b> — {f['count']} mapped finding(s)</li>"
                 for f in pos["framework_impact"])
    return HTMLResponse(f"""<!doctype html><html><head><meta charset='utf-8'>
<title>OpenAID security report</title><style>
@page {{ size: A4; margin: 18mm; }}
body {{ font-family: 'Segoe UI',sans-serif; color:#1b1b1b; font-size:12px; }}
h1 {{ margin:0 0 4px; }} h2 {{ margin:22px 0 6px; border-bottom:2px solid #e8c268; padding-bottom:3px; }}
table {{ border-collapse:collapse; width:100%; margin:6px 0 14px; }}
th,td {{ border:1px solid #ccc; padding:5px 7px; text-align:left; vertical-align:top; }}
th {{ background:#f3f3f3; }} .grade {{ font-size:44px; font-weight:800; }}
.muted {{ color:#666; }} .noprint {{ margin:10px 0 18px; }}
@media print {{ .noprint {{ display:none; }} h2 {{ page-break-after:avoid; }} }}
</style></head><body>
<div class='noprint'><button onclick='window.print()'>Print / Save as PDF</button></div>
<h1>OpenAID — AI agent security report</h1>
<div class='muted'>{pos['industry_label']} &middot; frameworks: {', '.join(pos['frameworks'])}</div>
<h2>Executive summary</h2>
<p><span class='grade'>{pos['grade']}</span> &nbsp; {pos['score']}/100</p>
<p>{pos['headline']}</p>
<p>{inv.get('stats',{}).get('agents',len(agents))} agents discovered &middot;
{tri['totals']['exploitable']} exploitable by prompt injection &middot;
{spr['totals']['flagged']} lifecycle-flagged &middot;
{rt['totals']['tests']} recommended penetration tests</p>
<h2>Compliance framework impact</h2><ul>{fw}</ul>
<h2>Top exposures</h2>
{tbl(['Severity','Title','Rule','Detail'],
     [[e['severity'], e['title'], e['rule'], e['detail'][:110]] for e in pos['top_exposures']])}
<h2>Prompt-injection exposure (lethal trifecta)</h2>
{tbl(['Agent','Environment','Status','Legs','Recommended cut'],
     [[r['name'], r['environment'], r['status'], ', '.join(r['legs_present']),
       (r.get('recommendation') or dict()).get('label','')]
      for r in tri['agents'][:20]])}
<h2>Sprawl &amp; shadow AI</h2>
{tbl(['Agent','Environment','Flags','Priority'],
     [[r['name'], r['environment'], ', '.join(r['flags']), r['priority']]
      for r in spr['rows'][:20]])}
<h2>Recommended penetration tests</h2>
{tbl(['Agent','Severity','Test','OWASP','ATLAS'],
     [[p['agent'], t['severity'], t['title'], t['owasp'], t['atlas']]
      for p in rt['plans'][:12] for t in p['tests'][:3]])}
<p class='muted'>{rt['safety_note']}</p>
</body></html>""")


@app.get("/api/defender")
def api_defender(demo: int = 0):
    """Microsoft Defender for Cloud assessments + alerts on AI-hosting resources."""
    if demo or os.getenv("OPENAID_DEMO") == "1":
        return {"connected": True, "counts": {"total": 2, "assessments": 1, "alerts": 1,
                                              "by_severity": {"critical": 1, "high": 1}},
                "items": [
                    {"rule": "defender_managedIdentity", "resource": "power-2089-resource",
                     "severity": "critical", "detail": "Cognitive Services accounts should use managed identity",
                     "remediation": "Enable system-assigned managed identity",
                     "source": "defender_for_cloud", "portal_url": "https://portal.azure.com/"},
                    {"rule": "defender_alert", "resource": "ca-openaid-graph",
                     "severity": "high", "detail": "Suspicious outbound connection detected",
                     "remediation": "Review egress rules", "source": "defender_alert",
                     "portal_url": "https://portal.azure.com/"}]}
    arm = _arm_token()
    return defender.collect(_fetch, arm, _sub_ids(arm))


@app.get("/api/scan/policy")
def get_policy():
    return {"policy": _POLICY, "auto_actions": list(continuous._AUTO_ACTION.keys())}


@app.post("/api/scan/policy")
async def set_policy(req: Request):
    body = await req.json()
    for k in continuous.DEFAULT_POLICY:
        if k in body:
            _POLICY[k] = body[k]
    return {"policy": _POLICY}


@app.get("/api/scan/history")
def scan_history(n: int = 30):
    return {"history": _SCANS.history(n), "policy": _POLICY}


@app.post("/api/scan/run")
async def scan_run(demo: int = 0, dispatch: int = 1):
    """Run a full scan: discover -> analyze -> diff vs last -> auto-remediate
    (per policy) -> build report -> dispatch to webhook."""
    g = api_graph(demo=demo)
    descriptors = g.get("descriptors", [])
    agents = (g.get("inventory") or {}).get("agents", [])
    tri = trifecta.analyze_fleet(descriptors)
    spr = sprawl.analyze(agents)
    dfn = api_defender(demo=demo)
    snap = continuous.snapshot(g.get("graph_findings", []), tri, spr,
                               dfn.get("items", []))
    prev = _SCANS.latest()
    delta = continuous.diff(prev, snap)

    agent_index = {a["id"]: a for a in agents}
    plan = continuous.plan_auto_remediation(delta["new"], _POLICY, agent_index)

    def _exec(action, org_url, bot_id):
        dv = (connections.ms_token("dataverse")
              or os.getenv("OPENAID_DATAVERSE_TOKEN", "")
              or (auth.get_token(org_url) if org_url else ""))
        return remediation.execute(action, fetch=_fetch, org_url=org_url,
                                   bot_id=bot_id, dataverse_token=dv)

    results = continuous.apply_auto_remediation(plan, _exec)
    pos = posture.build_report(g.get("graph_findings", []), agents, "general")
    report = continuous.build_report(delta, results, pos)
    _SCANS.add(snap, delta, report)

    hook = os.getenv("OPENAID_REPORT_WEBHOOK", "")
    delivery = (continuous.dispatch(report, hook, _fetch)
                if (dispatch and hook) else {"ok": False, "detail": "no webhook configured"})
    return {"report": report, "delta_counts": delta["counts"],
            "auto_remediation": {"planned": plan["planned"], "results": results,
                                 "skipped_count": len(plan["skipped"])},
            "delivery": delivery, "defender": dfn.get("counts", {})}


@app.get("/api/scan/report.html", response_class=HTMLResponse)
def scan_report_html(demo: int = 0):
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    snap = continuous.snapshot(g.get("graph_findings", []),
                               trifecta.analyze_fleet(g.get("descriptors", [])),
                               sprawl.analyze(agents))
    d = continuous.diff(_SCANS.latest(), snap)
    pos = posture.build_report(g.get("graph_findings", []), agents, "general")
    return HTMLResponse(continuous.render_html(continuous.build_report(d, [], pos)))


@app.get("/api/sprawl")
def api_sprawl(demo: int = 0, stale_days: int = 90):
    """Agent sprawl / shadow-AI: orphaned, stale, dormant, duplicate agents."""
    g = api_graph(demo=demo)
    agents = (g.get("inventory") or {}).get("agents", [])
    return sprawl.analyze(agents, stale_days=stale_days)


@app.get("/api/trifecta")
def api_trifecta(demo: int = 0):
    """Fleet-wide lethal-trifecta (indirect prompt injection) audit."""
    g = api_graph(demo=demo)
    return trifecta.analyze_fleet(g.get("descriptors", []))


@app.get("/api/simulate/targets")
def simulate_targets(demo: int = 0):
    """List agents you can run the compromise simulation against."""
    g = api_graph(demo=demo)
    ag = (g.get("inventory") or {}).get("agents", [])
    return {"targets": [{"id": a["id"], "name": a["name"], "platform": a["platform"],
                         "environment": a.get("environment", ""),
                         "blast_score": a.get("blast_score", 0)} for a in ag]}


@app.get("/api/simulate")
def simulate(agent_id: str, demo: int = 0):
    """Interactive blast-radius simulation for one agent, plus the containment
    delta if that agent were isolated (its outbound edges cut)."""
    g = api_graph(demo=demo)
    # rebuild the graph object to run live blast math
    from openaid.graph.trust_graph import TrustGraph
    graph = TrustGraph.from_descriptors(g.get("descriptors", []))
    if agent_id not in graph.nodes:
        # demo fallback: synthesize from the cached blast list
        b = next((x for x in g.get("blast_radius", []) if x["origin"] == agent_id), None)
        if not b:
            return {"error": "agent not found"}
        return {"base": b, "isolated": {**b, "score": 0, "reachable_total": 0},
                "prevented": b.get("reachable_total", 0)}
    base = graph.blast_radius(agent_id)
    # isolate: cut this node's outbound edges, recompute, restore
    saved = graph.out.get(agent_id, [])
    graph.out[agent_id] = []
    isolated = graph.blast_radius(agent_id)
    graph.out[agent_id] = saved
    return {"base": base, "isolated": isolated,
            "prevented": max(0, base["reachable_total"] - isolated["reachable_total"]),
            "sensitive_saved": base.get("sensitive_resources", [])}


@app.get("/api/posture")
def api_posture(industry: str = "general", demo: int = 0):
    g = api_graph(demo=demo)
    findings = g.get("graph_findings", []) or []
    agents = (g.get("inventory") or {}).get("agents", [])
    return posture.build_report(findings, agents, industry)


@app.get("/api/usage")
def api_usage(demo: int = 0):
    """Top agents by sessions (Copilot, 7d) + tokens per Foundry account (7d)."""
    if demo or os.getenv("OPENAID_DEMO") == "1":
        return {"top_agents": [
            {"name": "IT Helpdesk (main)", "environment": "Contoso (default)",
             "platform": "copilot_studio", "sessions": 412, "portal_url": ""},
            {"name": "Sales Assistant", "environment": "prod101",
             "platform": "copilot_studio", "sessions": 178, "portal_url": ""}],
            "environments": [{"environment": "Contoso (default)", "sessions": 412, "tokens": 68000},
                             {"environment": "prod101", "sessions": 178, "tokens": 23243}],
            "foundry_tokens": [{"account": "power-2089-resource", "tokens": 91243,
                                "subscription": "Azure subscription 1"}],
            "top_users": [{"user": "power@powerappsfargo2022.onmicrosoft.com", "sessions": 214},
                          {"user": "kerolos@contoso.com", "sessions": 96},
                          {"user": "hr-team@contoso.com", "sessions": 41}],
            "totals": {"sessions": 590, "tokens": 91243, "agents": 2, "environments": 2},
            "window": "last 7 days"}
    inv_agents = []
    try:
        g = api_graph(demo=0)
        inv_agents = (g.get("inventory") or {}).get("agents", [])
    except Exception:
        pass
    dv_urls = [u for u in os.getenv("OPENAID_DATAVERSE_URLS", "").split(",") if u]
    copilot_rows: list = []
    user_rows: list = []
    for u in dv_urls:
        tok = (connections.ms_token("dataverse")
               or os.getenv("OPENAID_DATAVERSE_TOKEN", "") or auth.get_token(u))
        if not tok:
            continue
        try:
            copilot_rows.extend(usage.copilot_sessions(_fetch, u, tok))
            user_rows.extend(usage.copilot_users(_fetch, u, tok))
        except Exception:
            continue
    arm = (connections.ms_token("arm") or auth.get_token("https://management.azure.com")
           or os.getenv("OPENAID_ARM_TOKEN", ""))
    accounts = []
    if arm:
        try:
            subs = (_fetch("GET", "https://management.azure.com/subscriptions?api-version=2022-12-01",
                           headers={"Authorization": f"Bearer {arm}"}) or {}).get("value", [])
            for s in subs:
                sid = s.get("subscriptionId")
                j = _fetch("GET",
                           f"https://management.azure.com/subscriptions/{sid}/providers/"
                           f"Microsoft.CognitiveServices/accounts?api-version=2024-10-01",
                           headers={"Authorization": f"Bearer {arm}"}) or {}
                for a in j.get("value", []):
                    if (a.get("kind") or "").lower() in ("aiservices", "openai"):
                        accounts.append({"id": a["id"], "name": a["name"],
                                         "subscription": s.get("displayName", sid)})
        except Exception:
            pass
    foundry_rows = usage.foundry_tokens(_fetch, arm, accounts) if arm else []
    return usage.aggregate(copilot_rows, foundry_rows, inv_agents, user_rows)


@app.get("/api/remediate/playbook")
def remediate_playbook(rule: str = ""):
    return remediation.playbook_for(rule)


@app.get("/connect/{platform}", response_class=HTMLResponse)
def connect_popup(platform: str):
    g = connections.CONNECT_GUIDE.get(platform)
    if not g:
        return HTMLResponse("<h3>Unknown platform</h3>", status_code=404)
    steps = "".join(f"<li>{s}</li>" for s in g["steps"])
    color = g.get("color", "#e8c268")
    body_ms = """
      <button class='go' onclick='startMs()'>Open Microsoft sign-in</button>
      <div id='code' class='code'></div>
      <div id='st' class='mut'>Not started.</div>
      <script>
      async function startMs(){
        const r=await(await fetch('/api/auth/signin',{method:'POST'})).json();
        document.getElementById('code').textContent=r.user_code||'';
        window.open(r.verification_uri,'_blank');
        document.getElementById('st').textContent='Waiting for you to approve…';
        const t=setInterval(async()=>{
          const s=await(await fetch('/api/auth/status')).json();
          if(s.signed_in){clearInterval(t);done('Signed in as '+(s.account||''));}
        },2500);
      }
      </script>"""
    body_tok = f"""
      {"<a class='go' target='_blank' href='" + g.get("token_url","#") + "'>Open " + g["name"] + " &rarr;</a>" if g.get("token_url") else ""}
      {"<div class='code'>" + g.get("cmd","") + "</div>" if g.get("cmd") else ""}
      <input id='tok' autocomplete='off' spellcheck='false'
        placeholder="{'AKIA…:SECRET…  or  ACCESS:SECRET:SESSION — NOT a bedrock-api-key' if platform == 'aws' else 'Paste access token here'}"/>
      {"<input id='iurl' placeholder='Instance URL (https://…)'/>" if g.get("needs_url") else ""}
      <button class='go' onclick='val()'>Validate &amp; connect</button>
      <div id='st' class='mut'></div>
      <script>
      async function val(){{
        const token=document.getElementById('tok').value.trim();
        if('{platform}'==='aws' && token.startsWith('bedrock-api-key-')){{
          document.getElementById('st').innerHTML='&#10060; That is the Bedrock API key again — '+
            'it has NO secret inside and can NEVER list agents. Run the CloudShell one-liner above '+
            'and paste ITS output (one line, two colons), or an IAM access key pair.';
          return;
        }}
        const uEl=document.getElementById('iurl');
        const url=uEl?uEl.value.trim():'';
        document.getElementById('st').textContent='Validating…';
        const r=await(await fetch('/api/connections/test',{{method:'POST',
          headers:{{'Content-Type':'application/json'}},
          body:JSON.stringify({{platform:'{platform}',token,url}})}})).json();
        if(r.ok) done(r.detail); else document.getElementById('st').textContent='\u274c '+r.detail;
      }}
      </script>"""
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>Connect {g['name']}</title>
<style>body{{background:#0b0c0f;color:#e6e8ee;font-family:'Segoe UI',sans-serif;padding:26px;max-width:520px}}
h2{{margin:0 0 4px}} .bar{{height:4px;border-radius:2px;background:{color};margin-bottom:16px}}
ol{{color:#aeb3bf;line-height:1.7;padding-left:20px}} input{{width:100%;box-sizing:border-box;background:#14161b;
border:1px solid #23262e;border-radius:6px;color:#e6e8ee;padding:10px;margin:8px 0;font-family:monospace}}
.go{{display:inline-block;background:{color};color:#0b0c0f;font-weight:700;border:0;border-radius:6px;
padding:10px 16px;margin:8px 0;cursor:pointer;text-decoration:none}}
.code{{font-family:monospace;background:#14161b;border:1px solid #23262e;border-radius:6px;padding:10px;
margin:8px 0;font-size:14px;letter-spacing:1px}} .mut{{color:#8a8f9a;font-size:13px;margin-top:8px}}
.ok{{color:#7bd88f}}</style></head><body>
<div class='bar'></div><h2>Connect {g['name']}</h2>
<ol>{steps}</ol>
{body_ms if g.get('device_flow') else body_tok}
<script>
function done(msg){{
  document.getElementById('st').innerHTML="<span class='ok'>\u2713 "+msg+"</span> — closing…";
  if(window.opener) window.opener.postMessage({{openaidConnected:'{platform}'}}, '*');
  setTimeout(()=>window.close(), 1400);
}}
</script></body></html>"""
    # popup windows cache hard in Edge — stale guides mislead (seen live);
    # headers must go on the RETURNED response, not an injected one
    return HTMLResponse(html, headers={"Cache-Control": "no-store, max-age=0"})


# ---- per-platform connections (GUI) ----------------------------------------
@app.get("/api/connections")
def conn_status():
    return connections.status(auth)


@app.post("/api/connections/set")
async def conn_set(req: Request):
    body = await req.json()
    return connections.set_connection(body.get("platform", ""),
                                      body.get("token", ""), body.get("url", ""))


@app.post("/api/connections/clear")
async def conn_clear(req: Request):
    body = await req.json()
    return connections.clear_connection(body.get("platform", ""))


def _tokens():
    return {k: os.getenv(f"OPENAID_{k.upper()}_TOKEN", "")
            for k in ("azure", "gcp", "salesforce", "servicenow", "uipath", "webex")}


def _config():
    return {
        "subscriptions": [s for s in os.getenv("OPENAID_SUBSCRIPTIONS", "").split(",") if s],
        "gcp_projects": [p for p in os.getenv("OPENAID_GCP_PROJECTS", "").split(",") if p],
        "sf_instance": os.getenv("OPENAID_SF_INSTANCE_URL", ""),
        "snow_instance": os.getenv("OPENAID_SNOW_INSTANCE", ""),
        "uipath_url": os.getenv("OPENAID_UIPATH_URL", ""),
    }


def _any_configured(tokens, config) -> bool:
    return any(tokens.values()) or any(config.values())


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "openaid-graph", "version": "1.11.4"}


def _jwt_minutes_left(tok: str) -> int:
    """Minutes until a JWT expires; -1 for non-JWT/undecodable."""
    import base64 as _b64
    import json as _j
    import time as _t
    if not tok or tok.count(".") < 2:
        return -1
    try:
        pl = tok.split(".")[1]
        pl += "=" * (-len(pl) % 4)
        exp = int(_j.loads(_b64.urlsafe_b64decode(pl)).get("exp", 0))
        return int((exp - _t.time()) / 60)
    except Exception:
        return -1


def _alive(tok: str) -> bool:
    """True when the token has >2 minutes of life left."""
    return _jwt_minutes_left(tok) > 2


def _token_expiry_report() -> dict:
    """Decode the exp claim of every deploy-injected token. When these die
    (~1h), collectors silently return zero agents and the console looks
    wiped — this endpoint (and the UI banner it feeds) says so out loud
    instead, with the exact remedy."""
    import base64 as _b64
    import json as _j
    import time as _t
    out = {"tokens": [], "expired": [], "min_minutes_left": None}
    for env_name, label in (
        ("OPENAID_DATAVERSE_TOKEN", "Dataverse (Copilot Studio agents)"),
        ("OPENAID_BAP_TOKEN", "Power Platform environments"),
        ("OPENAID_ARM_TOKEN", "Azure Resource Manager"),
        ("OPENAID_FOUNDRY_TOKEN", "Foundry agents"),
        ("OPENAID_COGSVC_TOKEN", "Cognitive Services"),
        ("OPENAID_ML_TOKEN", "AML hub projects"),
    ):
        tok = os.getenv(env_name, "")
        if not tok or tok.count(".") < 2:
            continue
        try:
            payload = tok.split(".")[1]
            payload += "=" * (-len(payload) % 4)
            exp = int(_j.loads(_b64.urlsafe_b64decode(payload)).get("exp", 0))
        except Exception:
            continue
        mins = int((exp - _t.time()) / 60)
        out["tokens"].append({"scope": label, "minutes_left": mins})
        if mins <= 0:
            out["expired"].append(label)
        if out["min_minutes_left"] is None or mins < out["min_minutes_left"]:
            out["min_minutes_left"] = mins
    return out


@app.post("/api/auth/refresh")
def api_auth_refresh():
    """One-click recovery: silently re-mint every Microsoft token from the
    signed-in session (MSAL refresh token). Reports per resource so 'needs
    admin consent' and 'run DEPLOY.ps1' cases are named, not guessed."""
    out = {}
    targets = [("arm", "arm"), ("bap", "bap"),
               ("foundry", "https://ai.azure.com"),
               ("cognitive services", "https://cognitiveservices.azure.com"),
               ("aml", "https://ml.azure.com"),
               ("power platform", "https://api.powerplatform.com"),
               ("globaldisco", "https://globaldisco.crm.dynamics.com")]
    for u in [x for x in os.getenv("OPENAID_DATAVERSE_URLS", "").split(",") if x]:
        targets.append((f"dataverse {u.split('//')[-1].split('.')[0]}", u))
    signed_in = bool(auth.status().get("signed_in"))
    for label, res in targets:
        tok = auth.get_token(res) if signed_in else ""
        out[label] = {"ok": bool(tok),
                      "minutes_left": _jwt_minutes_left(tok) if tok else 0}
    ok_n = sum(1 for v in out.values() if v["ok"])
    return {"signed_in": signed_in, "refreshed": ok_n, "total": len(targets),
            "resources": out,
            "detail": ("not signed in — use Sign in on the Connections tab, "
                       "or re-run DEPLOY.ps1" if not signed_in else
                       f"{ok_n}/{len(targets)} tokens re-minted from the live "
                       "session; failures usually mean that resource needs "
                       "admin consent — those still need DEPLOY.ps1")}


def _keepalive_loop():
    """Self-healing: while a session exists, silently re-mint the core tokens
    every 10 minutes so MSAL's refresh token stays warm and discovery never
    hits a dead-token wall between deploys."""
    import time as _t
    while True:
        try:
            if auth.status().get("signed_in"):
                for res in ("arm", "bap", "https://ai.azure.com"):
                    auth.get_token(res)
                for u in [x for x in os.getenv("OPENAID_DATAVERSE_URLS", "").split(",") if x][:6]:
                    auth.get_token(u)
        except Exception:
            pass
        _t.sleep(600)


if not globals().get("_KEEPALIVE_STARTED"):
    _KEEPALIVE_STARTED = True
    import threading as _th
    _th.Thread(target=_keepalive_loop, daemon=True, name="openaid-keepalive").start()


@app.get("/api/auth/tokens")
def api_auth_tokens():
    return _token_expiry_report()


@app.get("/api/graph")
def api_graph(demo: int = Query(0)):
    # If the admin is signed in, OR any platform token is set, run live discovery.
    connected_any = any(p["connected"] and p["id"] != "microsoft"
                        for p in connections.status(auth)["platforms"])
    ms_pasted = connections.any_ms_token()
    # Tokens injected by DEPLOY.ps1 (zero-touch: minted from the operator's own
    # az login session, so the console is live on first open with no sign-in).
    env_arm = os.getenv("OPENAID_ARM_TOKEN", "")
    env_bap = os.getenv("OPENAID_BAP_TOKEN", "")
    env_dv = os.getenv("OPENAID_DATAVERSE_TOKEN", "")
    env_fd = os.getenv("OPENAID_FOUNDRY_TOKEN", "")
    env_cs = os.getenv("OPENAID_COGSVC_TOKEN", "")
    env_any = any((env_arm, env_bap, env_dv, env_fd))
    if (auth.status().get("signed_in") or connected_any or ms_pasted or env_any) and not demo:
        # precedence: FRESHEST wins. Deploy-injected env tokens die hourly and
        # a dead env token must never outrank the live signed-in session —
        # that exact ordering bug blanked the whole console with 401s.
        def _pick(*cands):
            for t in cands:
                if t and _alive(t):
                    return t
            for t in cands:          # nothing verifiably alive — best effort
                if t:
                    return t
            return ""
        arm = _pick(connections.ms_token("arm"), env_arm, auth.get_token("arm"))
        bap = _pick(connections.ms_token("bap"), env_bap, auth.get_token("bap"))
        foundry = _pick(connections.ms_token("foundry"), env_fd,
                        auth.get_token("https://ai.azure.com"))
        cogsvc = _pick(env_cs, auth.get_token("https://cognitiveservices.azure.com"))
        mltok = _pick(os.getenv("OPENAID_ML_TOKEN", ""),
                      auth.get_token("https://ml.azure.com"))
        dv_pasted = _pick(connections.ms_token("dataverse"), env_dv)

        def _dv(url):
            # freshest wins: a live per-org session token beats a DEAD
            # injected token (the old ordering caused the 401 wall)
            if dv_pasted and _alive(dv_pasted):
                return dv_pasted
            return auth.get_token(url) or dv_pasted

        disco_token = (dv_pasted if _alive(dv_pasted)
                       else (auth.get_token("https://globaldisco.crm.dynamics.com")
                             or dv_pasted))

        tokens = {
            "azure": arm or bap,
            "gcp": connections.token_for("gcp"),
            "salesforce": connections.token_for("salesforce"),
            "servicenow": connections.token_for("servicenow"),
            "uipath": connections.token_for("uipath"),
            "webex": connections.token_for("webex"),
            "aws": connections.token_for("aws"),
        }
        config = {
            "arm_token": arm, "bap_token": bap, "foundry_token": foundry,
            "dataverse_token": _dv,
            "discovery_token": disco_token,
            "dataverse_urls": [u for u in (
                [connections.ms_url("dataverse")] +
                os.getenv("OPENAID_DATAVERSE_URLS", "").split(",")) if u],
            "subscriptions": [s for s in os.getenv("OPENAID_SUBSCRIPTIONS", "").split(",") if s],
            "gcp_projects": [p for p in os.getenv("OPENAID_GCP_PROJECTS", "").split(",") if p],
            "sf_instance": connections.url_for("salesforce", "OPENAID_SF_INSTANCE_URL"),
            "snow_instance": connections.url_for("servicenow", "OPENAID_SNOW_INSTANCE"),
            "uipath_url": connections.url_for("uipath", "OPENAID_UIPATH_URL"),
            "foundry_endpoints": [e for e in os.getenv("OPENAID_FOUNDRY_ENDPOINTS", "").split(",") if e],
            "cogsvc_token": cogsvc,
            "ml_token": mltok,
            "third_party": connections.active_connections(),
            "tenant_id": os.getenv("OPENAID_TENANT_ID", ""),
            "pp_token": os.getenv("OPENAID_PP_TOKEN", ""),
        }
        result = discover_v2.discover(_fetch, tokens=tokens, config=config)
        result["mode"] = "live"
        result["signed_in_as"] = auth.status().get("account", "")
        drift.record(result.get("inventory", {}))
        result["token_status"] = {
            "arm": bool(arm), "bap": bool(bap), "foundry": bool(foundry),
            "dataverse": bool(dv_pasted or disco_token),
            "discovery": bool(disco_token),
        }
        # LOUD, not silent: dead tokens make agents "disappear" — say so.
        result["token_expiry"] = _token_expiry_report()
        try:
            result["third_party_connected"] = sorted(
                connections.active_connections().keys())
        except Exception:
            result["third_party_connected"] = []
        return result

    tokens, config = _tokens(), _config()
    if demo or not _any_configured(tokens, config):
        result = discover_v2.discover(_fetch, existing_descriptors=sample_descriptors(),
                                      tokens={}, config={})
        result["mode"] = "demo"
        return result
    result = discover_v2.discover(_fetch, tokens=tokens, config=config)
    result["mode"] = "live"
    return result


@app.get("/api/diag")
def diag():
    """Plain diagnostics: which tokens are present and what each scope returned.
    Paste this back if agents don't appear — it says exactly what's missing."""
    st = auth.status()
    present = {
        "signin": st.get("signed_in", False),
        "arm": bool(connections.ms_token("arm") or (st.get("signed_in") and auth.get_token("arm"))),
        "bap": bool(connections.ms_token("bap") or (st.get("signed_in") and auth.get_token("bap"))),
        "dataverse_token": bool(connections.ms_token("dataverse")),
        "dataverse_url": connections.ms_url("dataverse") or "(not set)",
        "foundry": bool(connections.ms_token("foundry")),
    }
    data = api_graph(demo=0)
    scopes = [{"kind": s.get("kind"), "status": s.get("status"),
               "agents": s.get("agents"), "reason": s.get("reason")}
              for s in data.get("scopes", [])]
    return {
        "mode": data.get("mode"),
        "tokens_present": present,
        "agents_found": data.get("inventory", {}).get("stats", {}).get("agents", 0),
        "scopes": scopes,
        "errors": data.get("errors", []),
    }


@app.get("/api/drift")
def api_drift():
    """What changed since the previous scan — shadow agents, privilege growth,
    agents that became anonymous."""
    return drift.diff()


@app.get("/api/debug/foundry")
def debug_foundry():
    """Per-endpoint, per-surface HTTP truth for Foundry agent discovery.
    Paste this back if Foundry agents show zero — it names the exact route
    and status that failed (wrong host, 401 bad token audience, 404, empty)."""
    import os as _os
    tok = (connections.ms_token("foundry")
           or auth.get_token("https://ai.azure.com")
           or _os.getenv("OPENAID_FOUNDRY_TOKEN", ""))
    eps = [e for e in _os.getenv("OPENAID_FOUNDRY_ENDPOINTS", "").split(",") if e]
    out = {"token": bool(tok), "endpoints": []}
    if not tok:
        out["error"] = "no Foundry token (audience https://ai.azure.com)"
        return out
    hdr = {"Authorization": f"Bearer {tok}"}
    cog = (auth.get_token("https://cognitiveservices.azure.com")
           or _os.getenv("OPENAID_COGSVC_TOKEN", ""))
    out["cogsvc_token"] = bool(cog)
    surfaces = ["assistants?api-version=v1", "assistants?api-version=2025-05-01",
                "agents?api-version=v1",
                "agents?api-version=2025-11-15-preview",
                "openai/assistants?api-version=2025-04-01-preview",
                "projects?api-version=v1"]
    out["ml_token"] = bool(auth.get_token("https://ml.azure.com")
                           or _os.getenv("OPENAID_ML_TOKEN", ""))
    import httpx as _hx
    for ep in eps[:6]:
        row = {"endpoint": ep, "surfaces": {}}
        base = ep.rstrip("/")
        acct = base.split("/api/projects")[0]
        for sfc in surfaces:
            url = (f"{acct}/{sfc}" if sfc.startswith(("openai/", "projects?"))
                   else f"{base}/{sfc}")
            if sfc.startswith("projects?"):
                url = f"{acct}/api/{sfc.replace('projects?', 'projects?')}"
                url = f"{acct}/api/projects?api-version=v1"
            h = dict(hdr)
            if sfc.startswith("openai/") and cog:
                h = {"Authorization": f"Bearer {cog}"}
            if "2025-11-15-preview" in sfc and sfc.startswith("agents"):
                h["Foundry-Features"] = "HostedAgents=V1Preview"
            try:
                with _hx.Client(timeout=20) as c:
                    r = c.get(url, headers=h)
                n = 0
                if r.headers.get("content-type", "").startswith("application/json"):
                    j = r.json()
                    n = len(j.get("value", j.get("data", [])) or [])
                row["surfaces"][sfc] = {"status": r.status_code, "agents": n}
            except Exception as e:  # noqa: BLE001
                row["surfaces"][sfc] = {"error": str(e)[:160]}
        out["endpoints"].append(row)
    return out


@app.get("/api/debug/dataverse")
def debug_dataverse():
    """Show EXACTLY what the Copilot component queries return, so child-agent
    detection can be matched to this tenant's real data shape. Returns counts
    and schema shape only — no agent content."""
    dv_pasted = connections.ms_token("dataverse")
    disco = dv_pasted or auth.get_token("https://globaldisco.crm.dynamics.com")
    out = {"environments": []}
    if not disco:
        return {"error": "no Dataverse/discovery token — sign in or paste a dataverse token"}
    # find orgs
    try:
        from openaid.collectors import dataverse_discovery
        _rep, urls, _idx = dataverse_discovery.collect(_fetch, token=disco)
    except Exception as e:  # noqa: BLE001
        return {"error": f"discovery failed: {e}"}
    pasted_url = connections.ms_url("dataverse")
    if pasted_url:
        urls = list({pasted_url, *urls})
    for base in urls[:5]:
        base = base.rstrip("/")
        tok = dv_pasted or auth.get_token(base)
        hdr = {"Authorization": f"Bearer {tok}", "Accept": "application/json",
               "OData-MaxVersion": "4.0", "OData-Version": "4.0"}
        env = {"url": base, "token": bool(tok)}
        # bots
        try:
            bots = (_fetch("GET", f"{base}/api/data/v9.2/bots?$select=botid,name,schemaname",
                           headers=hdr) or {}).get("value", [])
            env["bots"] = len(bots)
            env["bot_schemanames_sample"] = [b.get("schemaname") for b in bots[:5]]
        except Exception as e:  # noqa: BLE001
            env["bots_error"] = str(e)[:300]
        # expand path — try BOTH relationship names
        for rel in ("botcomponent_parent_bot", "bot_botcomponent"):
            try:
                exp = (_fetch("GET", f"{base}/api/data/v9.2/bots?$select=botid&$expand="
                              f"{rel}($select=botcomponentid,name,schemaname,componenttype)",
                              headers=hdr) or {}).get("value", [])
                env[f"expand[{rel}]_bots"] = len(exp)
                env[f"expand[{rel}]_components"] = sum(len(b.get(rel) or []) for b in exp)
            except Exception as e:  # noqa: BLE001
                env[f"expand[{rel}]_error"] = str(e)[:200]
        # direct botcomponents + distinct componenttype values (the key signal)
        try:
            comp = (_fetch("GET", f"{base}/api/data/v9.2/botcomponents?$select="
                           "botcomponentid,name,schemaname,componenttype,_parentbotid_value",
                           headers=hdr) or {}).get("value", [])
            env["botcomponents"] = len(comp)
            types = {}
            for c in comp:
                t = str(c.get("componenttype"))
                types[t] = types.get(t, 0) + 1
            env["componenttype_counts"] = types
            env["component_schemanames_sample"] = [c.get("schemaname") for c in comp[:8]]
            env["components_with_parent"] = sum(1 for c in comp if c.get("_parentbotid_value"))
        except Exception as e:  # noqa: BLE001
            env["botcomponents_error"] = str(e)[:300]
        out["environments"].append(env)
    return out


@app.get("/api/debug/azure")
def debug_azure():
    """Show whether ARM works and what Foundry/Cognitive Services resources exist."""
    arm = connections.ms_token("arm") or auth.get_token("arm")
    if not arm:
        return {"error": "no ARM token — sign in (needs consent) or paste an arm token "
                         "in Connections > Microsoft > Advanced"}
    hdr = {"Authorization": f"Bearer {arm}"}
    out = {"arm_token": True, "subscriptions": [], "cognitive_accounts": []}
    try:
        subs = (_fetch("GET", "https://management.azure.com/subscriptions?api-version=2022-12-01",
                       headers=hdr) or {}).get("value", [])
        out["subscriptions"] = [{"id": s.get("subscriptionId"), "name": s.get("displayName")}
                                for s in subs]
    except Exception as e:  # noqa: BLE001
        out["subscriptions_error"] = str(e)[:300]
        return out
    for s in out["subscriptions"]:
        try:
            accts = (_fetch("GET", f"https://management.azure.com/subscriptions/{s['id']}"
                            "/providers/Microsoft.CognitiveServices/accounts?api-version=2025-06-01",
                            headers=hdr) or {}).get("value", [])
            for a in accts:
                out["cognitive_accounts"].append({"name": a.get("name"), "kind": a.get("kind"),
                                                  "sub": s["name"]})
        except Exception as e:  # noqa: BLE001
            out.setdefault("account_errors", []).append(f"{s['name']}: {str(e)[:200]}")
    out["foundry_candidates"] = [a for a in out["cognitive_accounts"]
                                 if (a.get("kind") or "").lower() in ("aiservices", "openai")]
    return out


@app.get("/api/exports/crowdstrike.ndjson", response_class=PlainTextResponse)
def crowdstrike_events(demo: int = Query(0)):
    """Falcon Next-Gen SIEM / LogScale ingest — one event per agent + attack path."""
    data = api_graph(demo=demo)
    return data.get("exports", {}).get("crowdstrike", {}).get("falcon_ngsiem_ndjson", "")


@app.get("/api/exports/crowdstrike-iocs.json", response_class=PlainTextResponse)
def crowdstrike_iocs(demo: int = Query(0)):
    """Falcon custom IOC indicators for MCP/agent endpoints."""
    import json as _json
    data = api_graph(demo=demo)
    return _json.dumps(data.get("exports", {}).get("crowdstrike", {}).get("falcon_iocs", []), indent=2)


@app.get("/api/exports/ocsf", response_class=PlainTextResponse)
def ocsf(demo: int = Query(0)):
    data = api_graph(demo=demo)
    return data.get("exports", {}).get("ocsf_ndjson", "")


@app.get("/api/exports/agents.csv", response_class=PlainTextResponse)
def agents_csv(demo: int = Query(0)):
    import csv
    import io
    data = api_graph(demo=demo)
    agents = data.get("inventory", {}).get("agents", [])
    buf = io.StringIO()
    cols = ["name", "platform", "type", "environment", "identity_kind", "identity",
            "anonymous", "child_count", "connected_count", "calls_mcp",
            "blast_score", "blast_severity", "resources"]
    w = csv.writer(buf)
    w.writerow(cols)
    for a in agents:
        row = [a.get(c, "") for c in cols[:-1]]
        row.append("; ".join(a.get("resources", [])))
        w.writerow(row)
    return buf.getvalue()


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")

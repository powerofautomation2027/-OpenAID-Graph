# OpenAID — Instagram Reel kit

## The video
`openaid-reel-9x16.html` — a 30-second, 9:16 animated promo. Open it full-screen
and screen-record the phone-shaped box for one loop.
- macOS: Cmd+Shift+5 · Windows: Win+G · Best quality: OBS with a 1080×1920 canvas
- Seven scenes, 4s each: hook → discovery → hidden agents → lethal trifecta →
  one-click fix → board report → CTA
- Silent by design. Add trending audio in the Instagram editor.

## Caption — option A (fear → relief)
Your company has more AI agents than you think. 🤖

Most were built by someone in marketing, connected to a SharePoint site, and
forgotten. They still hold live credentials.

OpenAID finds every one — Copilot Studio, Azure AI Foundry, OpenAI, Slack,
GitHub, Vertex AI — then shows you the child agents hiding inside them that
carry their *own* permissions.

Then it tells you which single change shuts the door. 🔒

#AISecurity #AIAgents #CyberSecurity #CopilotStudio #AzureAI #CISO #InfoSec
#PromptInjection #AIGovernance #CloudSecurity #ShadowAI #SecOps

## Caption — option B (the stat)
98% of AI agents evaluated carry all three: access to private data, exposure to
untrusted content, and a way to send data out.

That combination is a working exploit chain. Break ANY one leg and it collapses.

OpenAID audits your entire agent estate for it automatically — and tells you the
cheapest leg to cut. ⚡

#PromptInjection #AISecurity #LLMSecurity #OWASP #AIAgents #CyberSecurity
#CISO #AIGovernance #RedTeam #InfoSec

## Caption — option C (short + punchy)
Find every AI agent. See what it can reach. Fix it before someone else finds it.

🔍 51 agents discovered
⚠️ 6 exploitable by prompt injection
✅ 1 click to shut the door

#AISecurity #AIAgents #CyberSecurity #ShadowAI #CISO #CopilotStudio #InfoSec

## Hook lines to overlay (first 1.5s matters most)
- "You have 51 AI agents. Do you know what they can reach?"
- "The AI agent nobody owns still has your data."
- "Three capabilities. One open door."
- "Your agents have children. With their own permissions."

## Posting notes
- Reels: 9:16, 1080×1920, ≤90s. This is 30s — ideal for completion rate.
- Put the hook text in the first frame; most viewers decide in 1.5 seconds.
- Add captions/subtitles — most people watch muted.
- Best slots for B2B security: Tue–Thu, 8–10am or 5–7pm local.
- Pin a comment with the CTA link; Reels captions don't render links.

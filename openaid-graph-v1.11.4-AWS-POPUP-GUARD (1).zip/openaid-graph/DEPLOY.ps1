<#
  DEPLOY.ps1  —  OpenAID Graph v0.2  —  ONE zero-touch deployment.

  This is a SELF-CONTAINED app. It does NOT need your v0.1 source. It builds a
  container from the files in this folder, pushes to your existing ACR, and
  deploys a NEW Container App next to your existing one (nothing is overwritten).

  Just run, from this folder:

      Set-ExecutionPolicy Bypass -Scope Process -Force
      az login          # if you aren't already logged in
      .\DEPLOY.ps1

  Everything else is automatic. Defaults target your known infrastructure and
  can be overridden with parameters if anything has changed.

  Local test only (no Azure), runs the app on http://localhost:8000 :
      .\DEPLOY.ps1 -LocalOnly
#>
[CmdletBinding()]
param(
  [string]$ResourceGroup = "rg-openaid-4cde00",
  [string]$Acr           = "acropenaid4cde00",
  [string]$AppName       = "ca-openaid-graph",
  [string]$ExistingApp   = "ca-openaid-4cde00",   # used only to borrow the environment + identity
  [string]$ManagedIdentity = "id-openaid-4cde00",
  [string]$Subscription  = "",                    # optional; auto-detected if omitted
  [string]$Location      = "eastus",
  [string]$Image         = "openaid-graph:v0.2",
  [switch]$LocalOnly,
  [switch]$SkipTests
)

# 'Continue', NOT 'Stop': the operator's az CLI is 32-bit Python and prints a
# harmless warning to stderr on EVERY call. Under Stop, PowerShell 5 converts
# any native stderr into a terminating NativeCommandError and kills the deploy
# at the first az call. Failures are still caught: every critical az call below
# is followed by an explicit exit-code check + throw.
$ErrorActionPreference = "Continue"
function Say($m)  { Write-Host "==> $m" -ForegroundColor Cyan }
function Warn($m) { Write-Host "!!  $m" -ForegroundColor Yellow }
function Ok($m)   { Write-Host "OK  $m" -ForegroundColor Green }
function Head($m) { Write-Host "`n### $m" -ForegroundColor Magenta }

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Here

# --- sanity: the app files must be here --------------------------------------
foreach ($p in @("Dockerfile","requirements.txt","app\server.py","openaid\discover_v2.py")) {
  if (-not (Test-Path (Join-Path $Here $p))) { throw "Missing $p — run this from the unzipped package folder." }
}

# --- tests (fast, offline) ---------------------------------------------------
if (-not $SkipTests) {
  Say "Running tests"
  $py = Get-Command python -ErrorAction SilentlyContinue
  if (-not $py) { $py = Get-Command python3 -ErrorAction SilentlyContinue }
  if ($py) {
    & $py.Source -m pip install pytest --quiet --disable-pip-version-check 2>$null
    & $py.Source -m pytest (Join-Path "tests" "test_v2.py") -q
    if ($LASTEXITCODE -ne 0) { throw "Tests failed — stopping before deploy." }
    Ok "19 tests passed"
  } else { Warn "python not found — skipping tests." }
}

# --- local-only path ---------------------------------------------------------
if ($LocalOnly) {
  Say "Starting locally on http://localhost:8000  (Ctrl+C to stop)"
  $py = (Get-Command python -ErrorAction SilentlyContinue) ?? (Get-Command python3 -ErrorAction SilentlyContinue)
  & $py.Source -m pip install -r requirements.txt --quiet --disable-pip-version-check
  & $py.Source -m uvicorn app.server:app --host 0.0.0.0 --port 8000
  return
}

# --- Azure preflight ---------------------------------------------------------
Say "Checking Azure CLI"
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
  throw "Azure CLI (az) not found. Install it, run 'az login', then re-run."
}
$acct = az account show 2>$null | ConvertFrom-Json
if (-not $acct) { throw "Not logged in. Run 'az login' first, then re-run .\DEPLOY.ps1" }
Ok "Logged in as $($acct.user.name) (sub: $($acct.name))"

az extension add --name containerapp --only-show-errors 2>$null | Out-Null
az provider register -n Microsoft.App --only-show-errors 2>$null | Out-Null

# --- find a subscription with a deployable target -----------------------------
# The old named OpenAID resources may be gone. This app is standalone: it just
# needs (a) a Container Apps ENVIRONMENT to run in and (b) an ACR to push to.
# We probe each subscription and pick the first that has both. Preference order:
#   1. the specific -ResourceGroup if it exists and has an environment
#   2. any resource group that already has a Container Apps environment
# ACR: prefer -Acr, else an ACR in the same RG, else any ACR in the subscription.
function Probe-Subscription($subId) {
  az account set --subscription $subId 2>$null | Out-Null

  # environment: specific RG first, else the first env anywhere in the sub
  $envId = $null; $envRg = $null
  if ((az group exists -n $ResourceGroup 2>$null) -eq "true") {
    $envId = az containerapp env list -g $ResourceGroup --query "[0].id" -o tsv 2>$null
    if ($envId) { $envRg = $ResourceGroup }
  }
  if (-not $envId) {
    $envObj = az containerapp env list --query "[0].{id:id,rg:resourceGroup}" -o json 2>$null | ConvertFrom-Json
    if ($envObj) { $envId = $envObj.id; $envRg = $envObj.rg }
  }
  if (-not $envId) { return $null }   # nothing to run in here

  # acr: specific name, else in the env's RG, else any in the sub
  $acrName = $null; $acrRg = $null
  if ($Acr) {
    $a = az acr list --query "[?name=='$Acr']|[0].{n:name,rg:resourceGroup}" -o json 2>$null | ConvertFrom-Json
    if ($a) { $acrName = $a.n; $acrRg = $a.rg }
  }
  if (-not $acrName) {
    $a = az acr list -g $envRg --query "[0].{n:name,rg:resourceGroup}" -o json 2>$null | ConvertFrom-Json
    if ($a) { $acrName = $a.n; $acrRg = $a.rg }
  }
  if (-not $acrName) {
    $a = az acr list --query "[0].{n:name,rg:resourceGroup}" -o json 2>$null | ConvertFrom-Json
    if ($a) { $acrName = $a.n; $acrRg = $a.rg }
  }
  if (-not $acrName) { return $null }  # no registry to push to here

  return @{ Sub = $subId; EnvId = $envId; EnvRg = $envRg; Acr = $acrName; AcrRg = $acrRg }
}

Say "Finding a subscription with a Container Apps environment + an ACR"
$subIds = if ($Subscription) { @($Subscription) }
          else { az account list --query "[].id" -o tsv 2>$null | Where-Object { $_ } }
$hit = $null
foreach ($sid in $subIds) {
  $r = Probe-Subscription $sid
  if ($r) { $hit = $r; break }
}
if (-not $hit) {
  Head "NO DEPLOYABLE TARGET FOUND (need a Container Apps environment + an ACR)."
  Head "WHAT EXISTS:"
  foreach ($sid in $subIds) {
    az account set --subscription $sid 2>$null | Out-Null
    $sn = az account show --query name -o tsv 2>$null
    Write-Host "  Subscription: $sn ($sid)" -ForegroundColor Gray
    az acr list --query "[].name" -o tsv 2>$null | ForEach-Object { Write-Host "      ACR: $_" -ForegroundColor Gray }
    az containerapp env list --query "[].name" -o tsv 2>$null | ForEach-Object { Write-Host "      Env: $_" -ForegroundColor Gray }
  }
  throw "No environment+ACR pair found. Create a Container Apps environment, or pass -Subscription/-ResourceGroup/-Acr."
}

az account set --subscription $hit.Sub 2>$null | Out-Null
$Acr = $hit.Acr
$AcrRg = $hit.AcrRg
$envId = $hit.EnvId
$DeployRg = $hit.EnvRg   # the app is created in the environment's resource group
$subName = az account show --query name -o tsv 2>$null
Ok "Subscription: $subName ($($hit.Sub))"
Ok "Environment:  $($envId.Split('/')[-1])  (rg: $DeployRg)"
Ok "Registry:     $Acr  (rg: $AcrRg)"

# --- build the image IN Azure (no local Docker needed) -----------------------
Say "Building image in ACR '$Acr' (build runs in Azure — no local Docker needed)"
# Unique tag per deploy. Using a fixed tag (e.g. always ':v0.2') means
# `az containerapp update --image` sees an UNCHANGED image reference, creates no
# new revision, and the app keeps running the OLD code — new builds silently
# never take effect. A timestamped tag guarantees every deploy actually ships.
$BuildTag = Get-Date -Format "yyyyMMdd-HHmmss"
$Image = "$($Image.Split(':')[0]):$BuildTag"
Say "Build tag: $BuildTag"
az acr build --registry $Acr --image $Image . --only-show-errors
if ($LASTEXITCODE -ne 0) { throw "az acr build failed." }
$loginServer = (az acr show -n $Acr --query loginServer -o tsv).Trim()
$fullImage = "$loginServer/$Image"
Ok "Built $fullImage"

# --- ACR pull credentials (enable admin so the app can pull, zero extra setup)-
Say "Preparing registry credentials"
az acr update -n $Acr --admin-enabled true --only-show-errors 2>$null | Out-Null
$acrUser = az acr credential show -n $Acr --query username -o tsv 2>$null
$acrPass = az acr credential show -n $Acr --query "passwords[0].value" -o tsv 2>$null
if (-not $acrUser) { throw "Could not get ACR credentials for '$Acr'." }
Ok "Registry credentials ready"

# --- create or update the container app --------------------------------------
$exists = az containerapp show -n $AppName -g $DeployRg 2>$null
if ($exists) {
  Say "Updating existing '$AppName'"
  az containerapp registry set -n $AppName -g $DeployRg --server $loginServer `
    --username $acrUser --password $acrPass --only-show-errors 2>$null | Out-Null
  az containerapp update -n $AppName -g $DeployRg --image $fullImage `
    --revision-suffix "r$BuildTag".Replace("-","") --only-show-errors | Out-Null
} else {
  Say "Creating '$AppName' in environment '$($envId.Split('/')[-1])'"
  az containerapp create -n $AppName -g $DeployRg `
    --environment $envId `
    --image $fullImage `
    --target-port 8000 --ingress external `
    --min-replicas 1 --max-replicas 1 `
    --registry-server $loginServer `
    --registry-username $acrUser `
    --registry-password $acrPass `
    --only-show-errors | Out-Null
}
if ($LASTEXITCODE -ne 0) { throw "Container app deploy failed." }

# single replica + sticky sessions so the signed-in token (held in memory) is
# always served by the same replica — otherwise sign-in works but discovery
# (a different replica) sees no token and returns 0 agents.
az containerapp update -n $AppName -g $DeployRg --min-replicas 1 --max-replicas 1 --only-show-errors 2>$null | Out-Null
az containerapp ingress sticky-sessions set -n $AppName -g $DeployRg --affinity sticky --only-show-errors 2>$null | Out-Null

$fqdn = az containerapp show -n $AppName -g $DeployRg --query "properties.configuration.ingress.fqdn" -o tsv

# --- create/enable the sign-in app registration (device-code public client) --
Say "Setting up interactive sign-in (Azure AD app registration)"
$appReg = az ad app list --display-name "OpenAID Console" --query "[0]" -o json 2>$null | ConvertFrom-Json
if (-not $appReg) {
  $appReg = az ad app create --display-name "OpenAID Console" `
    --is-fallback-public-client true `
    --only-show-errors -o json 2>$null | ConvertFrom-Json
}
if ($appReg) {
  $clientId = $appReg.appId
  $tenantId = (az account show --query tenantId -o tsv)
  # enable public-client device-code flow
  az ad app update --id $clientId --set isFallbackPublicClient=true --only-show-errors 2>$null | Out-Null

  # Add delegated permissions + grant admin consent so the interactive sign-in
  # can actually acquire ARM + Dataverse tokens (otherwise sign-in works but
  # discovery gets empty tokens -> 0 agents).
  # Azure Service Management (ARM): 797f4846-... / user_impersonation 41094075-...
  # Dataverse (Dynamics CRM):       00000007-... / user_impersonation 78ce3f0f-...
  Say "Granting API permissions (ARM + Dataverse) and admin consent"
  # Remove a Cognitive Services permission added by earlier versions of this
  # script. If the tenant hasn't subscribed to that service, its presence makes
  # admin-consent fail for EVERY permission (Request_BadRequest).
  az ad app permission delete --id $clientId `
    --api a68d1052-8fc8-4c0c-a5d4-8d1b5f60e0e5 --only-show-errors 2>$null | Out-Null
  az ad app permission add --id $clientId `
    --api 797f4846-ba00-4fd7-ba43-dac1f8f63013 `
    --api-permissions 41094075-9dad-400e-a0bd-54e686782033=Scope --only-show-errors 2>$null | Out-Null
  az ad app permission add --id $clientId `
    --api 00000007-0000-0000-c000-000000000000 `
    --api-permissions 78ce3f0f-a1ce-49c2-8cde-64b5c0896db4=Scope --only-show-errors 2>$null | Out-Null
  # NOTE: no Cognitive Services / Foundry permission is requested here. Adding a
  # service principal the tenant hasn't subscribed to makes admin-consent fail
  # with Request_BadRequest for ALL permissions, including ARM and Dataverse.
  # Foundry tokens come from the deploy-time mint below instead.
  Start-Sleep -Seconds 5
  $consent = az ad app permission admin-consent --id $clientId --only-show-errors 2>&1
  if ($LASTEXITCODE -eq 0) {
    Ok "Admin consent granted — interactive sign-in will pull live data."
  } else {
    Warn "Could not auto-grant admin consent (need Global Admin / Privileged Role Admin)."
    Warn "Either grant it in Portal > App registrations > OpenAID Console > API permissions,"
    Warn "OR just use Connections > Microsoft > 'Advanced: paste tokens' — that needs no consent."
  }

  # push client/tenant to the container so the Sign-in button works
  az containerapp update -n $AppName -g $DeployRg `
    --set-env-vars OPENAID_CLIENT_ID=$clientId OPENAID_TENANT_ID=$tenantId `
    --only-show-errors 2>$null | Out-Null
  Ok "Sign-in enabled (client id: $clientId)"
} else {
  Warn "Could not create the sign-in app registration (need Application.ReadWrite). The app still runs in demo mode."
  Warn "You can create it later and set OPENAID_CLIENT_ID / OPENAID_TENANT_ID env vars on the container."
}

# --- ZERO-TOUCH LIVE DATA -----------------------------------------------------
# Everything that used to be a manual step is done here automatically, using the
# `az login` session you already have:
#   1. discover every Dataverse (Power Platform) org URL
#   2. discover Azure AI Foundry project endpoints
#   3. mint ARM / BAP / Dataverse / Foundry tokens
#   4. inject them into the container so the app is LIVE on first open
# Tokens are short-lived by design; re-run this script to refresh them, or use
# the in-app Sign in once admin consent has been granted.
Say "Provisioning live data (auto-discovering environments and minting tokens)"

function Get-Tok($resource) {
  $t = az account get-access-token --resource $resource --query accessToken -o tsv 2>$null
  if ($LASTEXITCODE -ne 0) { return "" }
  return ($t | Out-String).Trim()
}

$armTok  = Get-Tok "https://management.azure.com"
$bapTok  = Get-Tok "https://api.bap.microsoft.com"
$discTok = Get-Tok "https://globaldisco.crm.dynamics.com"

# 1) Dataverse org URLs — try Global Discovery first (works for non-admins),
#    then the BAP admin API.
$dvUrls = @()
if ($discTok) {
  $gd = az rest --method get --resource "https://globaldisco.crm.dynamics.com" `
        --url "https://globaldisco.crm.dynamics.com/api/discovery/v2.0/Instances?`$select=ApiUrl" `
        --query "value[].ApiUrl" -o tsv 2>$null
  if ($LASTEXITCODE -eq 0 -and $gd) { $dvUrls += @($gd -split "`n" | Where-Object { $_ }) }
}
if (-not $dvUrls -and $bapTok) {
  $bp = az rest --method get --resource "https://api.bap.microsoft.com" `
        --url "https://api.bap.microsoft.com/providers/Microsoft.BusinessAppPlatform/scopes/admin/environments?api-version=2016-11-01" `
        --query "value[].properties.linkedEnvironmentMetadata.instanceUrl" -o tsv 2>$null
  if ($LASTEXITCODE -eq 0 -and $bp) { $dvUrls += @($bp -split "`n" | Where-Object { $_ }) }
}
$dvUrls = @($dvUrls | ForEach-Object { $_.Trim().TrimEnd('/') } | Where-Object { $_ } | Select-Object -Unique)
if ($dvUrls.Count) { Ok "Found $($dvUrls.Count) Dataverse environment(s)" }
else { Warn "No Dataverse environments found (Copilot Studio agents may not list)" }

# a Dataverse token is per-org; mint one for the first org (same tenant audience)
$dvTok = ""
if ($dvUrls.Count) { $dvTok = Get-Tok $dvUrls[0] }

# 2) Azure AI Foundry project endpoints — scan EVERY subscription (the default
#    `az cognitiveservices account list` only looks at the current one) and do
#    not filter on kind (Foundry appears as AIServices/OpenAI and newer kinds).
$foundryEps = @()
if ($armTok) {
  $allSubs = @(az account list --query "[].id" -o tsv 2>$null | Where-Object { $_ })
  foreach ($sid in $allSubs) {
    $accts = az cognitiveservices account list --subscription $sid `
             --query "[].{n:name,rg:resourceGroup,ep:properties.endpoint}" -o json 2>$null | ConvertFrom-Json
    foreach ($a in @($accts)) {
      if (-not $a.n) { continue }
      # HOST FIX: ARM's properties.endpoint is the legacy cognitiveservices/
      # openai host, which does NOT serve /api/projects/{p}/agents — using it
      # made every Foundry agents call 404 (zero agents). The agents data plane
      # is ALWAYS on {name}.services.ai.azure.com.
      $baseEp = if ($a.ep -and ([string]$a.ep) -match 'services\.ai\.azure\.com') { ([string]$a.ep).TrimEnd('/') }
                else { "https://$($a.n).services.ai.azure.com" }
      if ($baseEp.EndsWith("/api/projects")) { $baseEp = $baseEp.Substring(0, $baseEp.Length - 13) }
      # real project names under this account
      $projs = az rest --method get --resource "https://management.azure.com" `
               --url "https://management.azure.com/subscriptions/$sid/resourceGroups/$($a.rg)/providers/Microsoft.CognitiveServices/accounts/$($a.n)/projects?api-version=2025-06-01" `
               --query "value[].name" -o tsv 2>$null
      if ($LASTEXITCODE -eq 0 -and $projs) {
        foreach ($p in @($projs -split "`n" | Where-Object { $_ })) {
          $pn = ($p.Trim() -split '/')[-1]
          $foundryEps += "$baseEp/api/projects/$pn"
        }
      } else {
        $foundryEps += "$baseEp/api/projects/$($a.n)"
      }
    }
  }
}
$foundryEps = @($foundryEps | Where-Object { $_ } | Select-Object -Unique)
$fdTok = Get-Tok "https://ai.azure.com"
# The account-level Azure OpenAI data plane needs the Cognitive Services
# audience — the ai.azure.com token 401s on /openai/assistants.
$csTok = Get-Tok "https://cognitiveservices.azure.com"
# Hub-based Foundry projects use the legacy AML data plane (ml.azure.com audience)
$mlTok = Get-Tok "https://ml.azure.com"
# Power Platform API — used by the orphaned-agent reassign remediation
$ppTok = Get-Tok "https://api.powerplatform.com"
# Tenant id — the New Foundry portal needs it as ?tid= on agent links
$tenantId = (az account show --query tenantId -o tsv 2>$null)
if ($foundryEps.Count) { Ok "Found $($foundryEps.Count) Azure AI Foundry account(s)" }
else { Warn "No Azure AI Foundry (AIServices/OpenAI) accounts found in your subscriptions" }

# 3) Inject everything into the container
$envPairs = @()
if ($armTok)          { $envPairs += "OPENAID_ARM_TOKEN=$armTok" }
if ($bapTok)          { $envPairs += "OPENAID_BAP_TOKEN=$bapTok" }
if ($dvTok)           { $envPairs += "OPENAID_DATAVERSE_TOKEN=$dvTok" }
if ($fdTok)           { $envPairs += "OPENAID_FOUNDRY_TOKEN=$fdTok" }
if ($csTok)           { $envPairs += "OPENAID_COGSVC_TOKEN=$csTok" }
if ($mlTok)           { $envPairs += "OPENAID_ML_TOKEN=$mlTok" }
if ($ppTok)           { $envPairs += "OPENAID_PP_TOKEN=$ppTok" }
if ($tenantId)        { $envPairs += "OPENAID_TENANT_ID=$tenantId" }
# Optional: continuous-scan report destination (Teams/Slack incoming webhook)
if ($env:OPENAID_REPORT_WEBHOOK) { $envPairs += "OPENAID_REPORT_WEBHOOK=$($env:OPENAID_REPORT_WEBHOOK)" }
if ($dvUrls.Count)    { $envPairs += "OPENAID_DATAVERSE_URLS=$($dvUrls -join ',')" }
if ($foundryEps.Count){ $envPairs += "OPENAID_FOUNDRY_ENDPOINTS=$($foundryEps -join ',')" }

if ($envPairs.Count) {
  # ROOT-CAUSE FIX: each token is a 2-4KB JWT. Passing ALL of them in ONE
  # az call exceeded the Windows 32,767-char command-line limit — az died,
  # the error was suppressed, and NOTHING was injected (the app showed
  # token:false, endpoints:[]). Inject in chunks of TWO vars per call and
  # then VERIFY by reading the app's env list back.
  for ($i = 0; $i -lt $envPairs.Count; $i += 2) {
    $chunk = @($envPairs[$i..([Math]::Min($i + 1, $envPairs.Count - 1))])
    $names = ($chunk | ForEach-Object { ($_ -split '=', 2)[0] }) -join ', '
    az containerapp update -n $AppName -g $DeployRg --set-env-vars @chunk --only-show-errors 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { Warn "env inject FAILED for: $names" } else { Ok "injected: $names" }
  }
  $setNames = @(az containerapp show -n $AppName -g $DeployRg `
      --query "properties.template.containers[0].env[].name" -o tsv 2>$null)
  $wanted = @($envPairs | ForEach-Object { ($_ -split '=', 2)[0] })
  $missing = @($wanted | Where-Object { $setNames -notcontains $_ })
  if ($missing.Count) {
    Warn ("VARIABLES NOT ON THE APP (Foundry will show zero until fixed): " + ($missing -join ', '))
  } else {
    Ok ("VERIFIED on the app: " + ($wanted -join ', '))
  }
  Ok "Live data provisioned — the console opens with your real agents (no sign-in needed)"
  Warn "Tokens expire in ~1 hour. Re-run .\DEPLOY.ps1 to refresh, or grant admin consent for permanent in-app sign-in."
} else {
  Warn "Could not mint tokens from your az session; the console will open in demo mode."
}

Head "DEPLOYED."
Ok "Open your Attack Path console:"
Write-Host "    https://$fqdn" -ForegroundColor Green
Write-Host "    https://$fqdn/api/graph      (raw JSON)" -ForegroundColor Gray
Write-Host "    https://$fqdn/api/exports/ocsf (Splunk / Cisco XDR)" -ForegroundColor Gray
Head "READY — open the console; it is already live with your agents."
Warn "Optional extras (only if you use them):"
Warn "  GCP / AWS / Cisco / Salesforce / ServiceNow / UiPath -> Connections tab in the app"
Warn "  Permanent in-app sign-in -> have a Global Admin run:"
Warn "     az ad app permission admin-consent --id $clientId"
